const assert=require('assert');const vm=require('vm');const fs=require('fs');
const registry={};
class HTMLElement{
  attachShadow(){this.shadowRoot={innerHTML:'',activeElement:null,querySelectorAll:()=>[],querySelector:()=>null,getElementById:()=>({addEventListener:()=>{}})};return this.shadowRoot;}
}
const document={createElement(name){return new registry[name]();}};
const customElements={get(name){return registry[name];},define(name,klass){registry[name]=klass;}};
const window={customCards:[]};
const context={window,customElements,HTMLElement,document,console,confirm:()=>true};
vm.runInNewContext(fs.readFileSync('custom_components/xzense_full_preview/www/xzense-card.js','utf8'),context);
assert(registry['xzense-card']);assert(registry['xzense-card-editor']);
const card = document.createElement('xzense-card');
const services=[];
card.setConfig({type:'custom:xzense-card',title:'TEST',entities:{temperature_sensor:'switch.exodraft_temp',user_fan_speed:'number.fan_manual'}});
card.hass={states:{'switch.exodraft_temp':{state:'on',attributes:{global_id:'0x56',friendly_name:'Kontroller probe'}}, 'number.fan_manual':{state:'22',attributes:{min:10,max:100,step:1}}, 'number.another_device':{state:'30',attributes:{global_id:'0x50'}}},callService:async (d,s,p)=>{services.push([d,s,p]);}};
assert.strictEqual(card._entity('temperature_sensor'),'switch.exodraft_temp');
assert.strictEqual(card._entity('user_fan_speed'),'number.fan_manual');
card._tab='configuration';card._render();assert(card.shadowRoot.innerHTML.includes('Temperaturføler'));
const editor=document.createElement('xzense-card-editor');editor.setConfig({title:'test',entities:{boost:'switch.xzense_boost'}});editor.hass=card._hass;
assert(editor.shadowRoot.innerHTML.includes('switch.exodraft_temp'));
Promise.resolve(card._doAction('temperature_sensor')).then(()=>{
 assert.strictEqual(services[0][0],'switch');assert.strictEqual(services[0][1],'turn_off');assert.strictEqual(services[0][2].entity_id,'switch.exodraft_temp');
 console.log('Xzense Lovelace card smoke test OK');
}).catch(e=>{console.error(e);process.exit(1)});
