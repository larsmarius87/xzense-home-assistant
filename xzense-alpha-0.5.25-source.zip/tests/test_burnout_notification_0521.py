"""0.5.22 notification behavior without importing Home Assistant or BLE hardware."""
from __future__ import annotations

import ast
import asyncio
import logging
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1] / "custom_components/xzense_full_preview"
SRC = (ROOT / "burnout_notifications.py").read_text(encoding="utf-8")


def _actual_code():
    tree = ast.parse(SRC)
    named = {"BurnoutNotificationManager", "mobile_notification_targets", "normalized_notification_targets"}
    nodes = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in named]
    ns = {
        "CONF_BURNOUT_NOTIFY_ENABLED": "burnout_notification_enabled",
        "CONF_BURNOUT_NOTIFY_TARGET": "burnout_notification_target",
        "_LOGGER": logging.getLogger(__name__),
        "NOTIFY_TITLE": "Xzense: Legg i mer ved",
        "NOTIFY_MESSAGE": "Legg i mer ved.",
        "NO_NOTIFY_TARGET": "none",
    }
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), SRC, "exec"), ns)
    return ns


class FakeServices:
    def __init__(self, fail=False):
        self.calls = []
        self.fail = fail
    async def async_call(self, domain, service, data, **kwargs):
        self.calls.append((domain, service, data, kwargs))
        if self.fail:
            raise ValueError("Simulated notification failure")
    def has_service(self, domain, service):
        return domain == "notify" and service in {"mobile_app_iphone", "mobile_app_pixel"}
    def async_services(self):
        return {"notify": {"mobile_app_iphone": {}, "mobile_app_pixel": {}, "notify": {}, "send_message": {}}}


async def exercise(states, options, *, fail=False, changing_options=None):
    ns = _actual_code()
    services = FakeServices(fail)
    tasks = []
    entry = SimpleNamespace(entry_id="test", options=options)
    def schedule(hass, coro, name):
        task = asyncio.create_task(coro)
        tasks.append(task)
        return task
    entry.async_create_background_task = schedule
    hass = SimpleNamespace(services=services,
                           states=SimpleNamespace(get=lambda entity_id: SimpleNamespace(state="idle") if entity_id in {"notify.iphone", "notify.pixel"} else None))
    mgr = ns["BurnoutNotificationManager"](hass, entry)
    for i, state in enumerate(states):
        if changing_options and i in changing_options:
            entry.options = changing_options[i]
        mgr.observe(state)
    if tasks:
        await asyncio.gather(*tasks)
    return services.calls, mgr, tasks


def test_notifications_disabled_by_default():
    calls, _, tasks = asyncio.run(exercise([4, 5], {}))
    assert calls == [] and tasks == []


def test_notify_once_on_real_transition_and_no_startup_false_positive():
    opts = {"burnout_notification_enabled": True, "burnout_notification_target": "entity:notify.iphone"}
    calls, _, _ = asyncio.run(exercise([5, 5, 4, 4, 5, 5, 6, 5, 4, 5], opts))
    assert len(calls) == 2
    assert all((d, s) == ("notify", "send_message") for d, s, _, _ in calls)
    assert all(kwargs["target"] == {"entity_id": "notify.iphone"} for *_, kwargs in calls)
    assert calls[0][2]["title"] == "Xzense: Legg i mer ved"


def test_legacy_mobile_app_action_and_no_fallback_to_all():
    opts = {"burnout_notification_enabled": True, "burnout_notification_target": "service:mobile_app_iphone"}
    calls, _, _ = asyncio.run(exercise([4, 5], opts))
    assert len(calls) == 1 and calls[0][1] == "mobile_app_iphone"
    assert calls[0][3]["blocking"] is True
    opts["burnout_notification_target"] = "service:notify"  # rejected
    calls, _, tasks = asyncio.run(exercise([4, 5], opts))
    assert calls == [] and tasks == []


def test_multiple_phones_on_one_transition_and_legacy_selection_compatibility():
    opts = {"burnout_notification_enabled": True,
            "burnout_notification_target": ["entity:notify.iphone", "entity:notify.pixel"]}
    calls, _, tasks = asyncio.run(exercise([4, 5, 5], opts))
    assert len(tasks) == 1
    assert len(calls) == 2
    assert {kwargs["target"]["entity_id"] for _, service, _, kwargs in calls
            if service == "send_message"} == {"notify.iphone", "notify.pixel"}
    assert all(data["title"] == "Xzense: Legg i mer ved" for _, _, data, _ in calls)

    # Old options with a single string still work without touching the BLE client.
    opts["burnout_notification_target"] = "entity:notify.iphone"
    calls, _, _ = asyncio.run(exercise([4, 5], opts))
    assert len(calls) == 1


def test_duplicate_and_invalid_phone_selections_are_ignored():
    ns = _actual_code()
    normalized = ns["normalized_notification_targets"]
    assert normalized(["none", "entity:notify.iphone", "entity:notify.iphone",
                       "service:notify", None]) == ["entity:notify.iphone"]


def test_invalid_target_and_missing_phone_safely_skipped():
    opts = {"burnout_notification_enabled": True, "burnout_notification_target": "entity:notify.missing"}
    calls, _, tasks = asyncio.run(exercise([4, 5], opts))
    assert calls == [] and len(tasks) == 1


def test_reconfigure_without_restarting_client():
    enabled = {"burnout_notification_enabled": True, "burnout_notification_target": "entity:notify.iphone"}
    calls, _, _ = asyncio.run(exercise(
        [4, 5, 4, 5], {}, changing_options={2: enabled}
    ))
    assert len(calls) == 1


def test_notifier_errors_do_not_interrupt_event_loop():
    opts = {"burnout_notification_enabled": True, "burnout_notification_target": "entity:notify.iphone"}
    calls, mgr, _ = asyncio.run(exercise([4, 5], opts, fail=True))
    assert len(calls) == 1
    mgr.stop()
    mgr.observe(4)
    mgr.observe(5)
    # New calls aren't queued after unload.


def test_phone_target_inventory_filters_non_mobile_entities():
    ns = _actual_code()
    er = SimpleNamespace(
        async_get=lambda hass: SimpleNamespace(entities={
            "phone": SimpleNamespace(domain="notify", platform="mobile_app", entity_id="notify.iphone", name="iPhone", original_name=None, disabled_by=None),
            "group": SimpleNamespace(domain="notify", platform="other", entity_id="notify.all_phones", name="All", original_name=None, disabled_by=None),
            "disabled": SimpleNamespace(domain="notify", platform="mobile_app", entity_id="notify.disabled", name="Hidden", original_name=None, disabled_by="integration"),
            "other": SimpleNamespace(domain="sensor", platform="mobile_app", entity_id="sensor.iphone", name="Sensor", original_name=None, disabled_by=None),
        })
    )
    ns["er"] = er
    hass = SimpleNamespace(services=FakeServices())
    targets = ns["mobile_notification_targets"](hass)
    assert "none" not in targets
    assert "entity:notify.iphone" in targets
    assert "entity:notify.all_phones" not in targets
    assert "entity:notify.disabled" not in targets
    assert "service:mobile_app_iphone" in targets
    assert "service:notify" not in targets


def test_integration_status_hook_is_only_for_valid_decoded_status():
    src=(ROOT / "client.py").read_text()
    tree=ast.parse(src)
    client=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="XzenseClient")
    notification=next(n for n in client.body if isinstance(n,ast.FunctionDef) and n.name=="_notification")
    calls=[n for n in ast.walk(notification) if isinstance(n,ast.Call)
           and isinstance(n.func,ast.Name) and n.func.id=="observer"]
    assert len(calls)==1
    assert "if status is not None:\n                self.state.status = status\n                for observer" in src
    assert "self._status_listeners" in src
    assert "for observer in tuple(self._status_listeners)" not in (ROOT / "timing.py").read_text()


def test_options_form_is_localized_and_preserves_existing_options():
    import json
    source = (ROOT / "config_flow.py").read_text()
    assert "class XzenseOptionsFlow(OptionsFlow)" in source
    assert "data={**current," in source
    assert "SelectSelectorConfig(" in source
    assert "multiple=True" in source
    for file in ("strings.json", "translations/en.json", "translations/nb.json"):
        locale=json.loads((ROOT / file).read_text())
        assert set(locale["options"]["step"]["init"]["data"]) == {
            "burnout_notification_enabled", "burnout_notification_target"
        }
    nb=json.loads((ROOT / "translations/nb.json").read_text())
    assert nb["options"]["step"]["init"]["title"] == "Varsling ved utbrenning"
