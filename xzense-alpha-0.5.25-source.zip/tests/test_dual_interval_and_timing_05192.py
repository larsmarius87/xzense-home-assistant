"""0.5.19.3: dual BLE schedule + fire-session regression tests."""
from __future__ import annotations
import ast
import asyncio
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]
COMP=ROOT/'custom_components'/'xzense_full_preview'
sp=importlib.util.spec_from_file_location('xzense_timing_05192', COMP/'timing.py')
timing=importlib.util.module_from_spec(sp)
import sys
sys.modules[sp.name]=timing
sp.loader.exec_module(timing)


def test_manifest_and_both_slider_ranges():
    assert json.loads((COMP/'manifest.json').read_text())['version']=='0.5.25'
    src=(COMP/'number.py').read_text()
    assert 'self.client.idle_interval_minutes' in src
    assert 'self.client.active_interval_seconds' in src
    assert '_bluetooth_update_interval' in src # old unique ID preserved
    assert '_bluetooth_active_update_interval' in src
    assert '_attr_native_max_value = 120' in src
    assert '_attr_native_max_value = 600' in src


def test_dynamic_profiles_include_ventilation():
    src=(COMP/'client.py').read_text()
    assert 'ACTIVE_STATES = frozenset({3, 4, 5, 6, 7, 8})' in src
    cls=next(n for n in ast.parse(src).body if isinstance(n,ast.ClassDef) and n.name=='XzenseClient')
    funcs=[n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
    pick=[n for n in funcs if n.name in ('_is_active_state','_update_effective_interval','interval_minutes')]
    ns={'ACTIVE_STATES':frozenset({3,4,5,6,7,8})}
    exec(compile(ast.fix_missing_locations(ast.Module(body=pick,type_ignores=[])), '<profiles>', 'exec'),ns)
    class F:
        idle_interval_minutes=5
        active_interval_seconds=0
        _wake=asyncio.Event()
        _next_poll_monotonic=100
        state=SimpleNamespace(status=None,interval_profile='idle',update_interval_minutes=5,update_interval_seconds=300,next_poll_at=None)
        def current_device_state(self): return self.state.status
    x=F();x._is_active_state=ns['_is_active_state'].__get__(x,F)
    x._update_effective_interval=ns['_update_effective_interval'].__get__(x,F)
    for new_state in (3,4,5,6,7,8):
        x.state.status=new_state
        assert x._is_active_state()
        assert x._update_effective_interval() or x.state.interval_profile=='active'
        assert x.state.update_interval_seconds==0
    x.state.status=2
    assert x._update_effective_interval()
    assert x.state.update_interval_seconds==300
    assert x.state.interval_profile=='idle'


def test_five_minute_polling_ready_to_boosting_backdates_start():
    t=timing.XzenseTiming()
    t.observe(2,200,1000)
    t.observe(3,220,1300)
    assert t.fire_started_epoch==1080
    assert t.fire_duration==220
    assert t.fire_quality=='inferred_ready_boost_timer'


def test_ready_to_operation_only_estimates_operation_start():
    t=timing.XzenseTiming()
    t.observe(2,200,1000)
    t.observe(4,60,1300)
    assert t.fire_started_epoch==1240
    assert t.fire_quality=='estimated_from_operation_timer'


def test_button_timestamp_before_operation_confirmation():
    t=timing.XzenseTiming()
    t.observe(2,200,1000)
    t.note_start_request(1070)
    assert t.fire_started_epoch is None
    t.observe(4,60,1300)
    assert t.fire_started_epoch==1070
    assert t.fire_quality=='confirmed_from_ready_button'


def test_button_timestamp_discarded_after_nack_or_failed_send():
    t=timing.XzenseTiming()
    t.observe(2,10,1000)
    t.note_start_request(1020)
    t.cancel_start_request()
    t.observe(4,10,1030)
    assert t.fire_started_epoch==1020
    assert t.fire_quality=='estimated_from_operation_timer'


def test_no_timer_based_restart_after_operation_afterrun_boost():
    t=timing.XzenseTiming()
    t.observe(2,10,1000)
    t.observe(3,1,1010)
    t.observe(4,30,1050)
    t.observe(6,1,1090)
    start=t.fire_started_epoch
    t.observe(3,0,1390)
    assert t.fire_started_epoch==start
    assert t.last_fire_duration is None
    t.observe(2,10,1600)
    assert t.last_fire_duration==1600-start


def test_ha_start_request_during_afterrun_does_not_reset():
    t=timing.XzenseTiming()
    t.observe(2,10,1000)
    t.observe(3,0,1010)
    t.observe(6,0,1050)
    t.note_start_request(1060) # ignored because not Ready
    assert t.pending_ready_start_epoch is None
    t.observe(3,0,1070)
    assert t.fire_started_epoch==1010


def test_unreliable_timer_does_not_fabricate_pre_ready_fire():
    t=timing.XzenseTiming()
    t.observe(2,100,1000)
    t.observe(3,500,1300) # impossible timer if Ready at t=1000
    assert t.fire_started_epoch==1300
    assert t.fire_quality=='partial_observation'


def test_rapid_mode_changes_have_async_yield_and_wake():
    s=(COMP/'client.py').read_text()
    assert 'await asyncio.sleep(0.05)' in s
    assert 'if self.interval_minutes > 0:\n                    return' in s
    assert 'self._wake.set()' in s
    assert 'await asyncio.sleep(0.25)' in s
    assert 'await asyncio.wait_for(self._wake.wait(), timeout=seconds)' in s


def test_dashboard_contains_both_slider_controls():
    s=(ROOT/'www/xzense-card.js').read_text()
    assert "this._numeric('bluetooth_update_interval',true)" in s
    assert "this._numeric('bluetooth_active_update_interval',true)" in s
    assert '0–600 sekunder' in s and '0–120 min' in s


def _client_method(name: str):
    tree=ast.parse((COMP/'client.py').read_text())
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='XzenseClient')
    fn=next(n for n in cls.body if isinstance(n,ast.AsyncFunctionDef) and n.name==name)
    import time
    from datetime import UTC, datetime
    import logging
    ns={'asyncio':asyncio,'time':time,'TimeoutError':TimeoutError,
        'APPLICATION_AUTH_TIMEOUT':0.2,'SNAPSHOT_WAIT_SECONDS':0.2,
        '_LOGGER':logging.getLogger('test_xzense_05192'), 'datetime':datetime,'UTC':UTC}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])), '<client-method>', 'exec'),ns)
    return ns[name]


def test_active_switch_during_periodic_session_keeps_link():
    """Ready at connection, then STATUS says Boosting: keep current BLE connection."""
    import time
    class Ble:
        is_connected=True
        async def disconnect(self): self.is_connected=False
    class Fake:
        _stopping=False
        _next_poll_monotonic=0
        _connect_requested=False
        _pending_commands=0
        _keep_connected_until=0
        _wake=asyncio.Event()
        _session_ready=asyncio.Event()
        _fresh_status_event=asyncio.Event()
        _planned_disconnects={}
        _client=None
        state=SimpleNamespace(periodic_poll_count=0,local_periodic_disconnect_count=0,
                              next_poll_at=None,connected=True,ble_link_connected=True,
                              notifications_active=True,application_auth_state='connected')
        mode=5
        @property
        def interval_minutes(self):return self.mode
        def _notify_listeners(self):pass
        def _set_phase(self,phase): pass
        async def _connect_once(self,fast=False):
            self._client=Ble();self._session_ready.set();self._fresh_status_event.set()
            self.mode=0 # new live STATUS detected active profile
            return True
    async def exercise():
        fake=Fake()
        await asyncio.wait_for(_client_method('_periodic_connection_loop')(fake),timeout=0.4)
        assert fake._client is not None and fake._client.is_connected
        assert fake.state.local_periodic_disconnect_count==0
    asyncio.run(exercise())


def test_continuous_loop_exits_promptly_after_ready_status():
    """Operation -> Ready: do not leave continuous connection loop sleeping forever."""
    class Ble: is_connected=True
    class Fake:
        _stopping=False
        _client=Ble()
        _wake=asyncio.Event()
        mode=0
        @property
        def interval_minutes(self):return self.mode
    async def exercise():
        fake=Fake()
        coro=_client_method('_continuous_connection_loop')(fake)
        task=asyncio.create_task(coro)
        await asyncio.sleep(0.02)
        assert not task.done()
        fake.mode=5
        fake._wake.set()
        await asyncio.wait_for(task,timeout=0.2)
    asyncio.run(exercise())


def test_periodic_five_minute_timer_end_does_not_split_afterrun():
    t=timing.XzenseTiming()
    t.observe(2, 100, 1000)
    t.observe(3, 120, 1300)    # start t=1180
    t.observe(6, 60, 1600)
    t.observe(3, 30, 1900)     # never creates a second cycle
    assert t.fire_started_epoch==1180
    t.observe(2, 10, 2200)
    assert t.last_fire_duration==1020
    assert t.last_fire_quality=='estimated_end_after_gap'


def test_ready_to_afterrun_does_not_claim_afterrun_stage_timer_is_fire_start():
    t=timing.XzenseTiming()
    t.observe(2,100,1000)
    t.observe(6,20,1300)
    assert t.fire_started_epoch==1300
    assert t.fire_quality=='partial_observation'


def test_ready_button_timing_captured_before_connect_and_committed_only_after_status():
    import time
    src=(COMP/'client.py').read_text()
    cls=next(n for n in ast.parse(src).body if isinstance(n,ast.ClassDef) and n.name=='XzenseClient')
    fn=next(n for n in cls.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='async_control_feature')
    ns={'HomeAssistantError':RuntimeError,'time':time}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])), '<dispatch>', 'exec'),ns)
    class Store:
        def async_delay_save(self, callback, delay):pass
    class Fake:
        def __init__(self):
            self._timing=timing.XzenseTiming()
            self._timing.observe(2,10,time.time()-10)
            self._timing_store=Store()
        def current_device_state(self):return 2
        async def async_run_control(self,action):
            await asyncio.sleep(0.02) # emulate slow connection before command dispatch
            await action()
        async def async_set_boost(self,on):
            assert on
    async def exercise():
        fake=Fake(); before=time.time()
        await ns['async_control_feature'](fake,'start_fire')
        assert fake._timing.pending_ready_start_epoch is not None
        assert before-.01<=fake._timing.pending_ready_start_epoch<before+.01
        assert fake._timing.fire_started_epoch is None
        fake._timing.observe(4,0,time.time()+2)
        assert fake._timing.fire_started_epoch is not None
        assert fake._timing.fire_quality=='confirmed_from_ready_button'
    asyncio.run(exercise())
