"""0.5.25 final contract tests without Home Assistant or BLE dependencies."""

import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "custom_components" / "xzense_full_preview"


def test_release_version_and_preserved_domain():
    manifest = json.loads((APP / "manifest.json").read_text())
    assert manifest["version"] == "0.5.25"
    assert manifest["domain"] == "xzense_full_preview"
    assert (APP / "const.py").read_text().find('VERSION = "0.5.25"') != -1


def test_new_sensor_registers_and_unused_diagnostics():
    source = (APP / "sensor.py").read_text()
    assert '"battery", "Panel battery", lambda s: s.globals.get(0x04)' in source
    assert '"signal_strength", "Power unit signal strength", lambda s: s.globals.get(0x05)' in source
    assert '"raw_global_18"' in source
    assert '"unused_global_values"' in source
    assert "_unused_global_values" in source
    assert '"status_device_state"' in source
    assert '"device_state", "Device state (English)", _operating_state' in source
    assert '"device_state_localized", "Localized device state"' in source


def test_motor_switch_persists_without_automatic_ble_write():
    source = (APP / "switch.py").read_text()
    client = (APP / "client.py").read_text()
    assert "class XzenseRS00941Switch" in source
    assert "self.client.async_set_rs009_41_motor" in source
    segment = client.split("async def async_set_rs009_41_motor", 1)[1].split("def _set_phase", 1)[0]
    assert "async_update_entry" in segment
    assert "async_set_minimum" not in segment
    assert "async_control_feature" not in segment
    assert "validate_raw_setting" in client


def test_dashboard_and_norwegian_strings():
    nb = json.loads((APP / "translations" / "nb.json").read_text())
    assert nb["entity"]["button"]["start_fire"]["name"] == "Start fyring"
    assert nb["entity"]["number"]["wanted_draft"]["name"] == "Pipetrekk"
    assert nb["entity"]["sensor"]["device_state_localized"]["state"]["operation"] == "Drift"
    assert nb["entity"]["switch"]["rs009_41_motor"]["name"] == "Viftetype RS009-41"
    for candidate in (ROOT / "www" / "xzense-card.js", APP / "www" / "xzense-card.js"):
        card = candidate.read_text()
        assert "0.5.25" in card
        assert "Start fyring" in card
        assert "Viftetype RS009-41" in card
        assert "mdi:turbine" in card
    assert (ROOT / "www" / "xzense-card.js").read_bytes() == (APP / "www" / "xzense-card.js").read_bytes()


def test_fan_motor_and_boost_icons_are_approved():
    source = (APP / "switch.py").read_text()
    assert '"mdi:turbine"' in source
    assert '"mdi:engine-outline"' in source
    sensor = (APP / "sensor.py").read_text()
    assert '"mdi:fan"' in sensor
    assert '"mdi:signal-cellular-outline"' in sensor
    assert 'f"mdi:signal-cellular-{raw}"' in sensor


def test_retired_unavailable_diagnostics_are_removed():
    source = (APP / "__init__.py").read_text()
    sensors = (APP / "sensor.py").read_text()
    for key in ("raw_global_35", "status_flags", "fan_probe_baseline_raw", "last_write_probe_result"):
        assert f'"{key}"' in source
    assert 'SensorDescription("raw_global_35"' not in sensors
    assert 'SensorDescription("status_flags"' not in sensors
    assert '"unused_global_values"' in sensors


def test_sources_parse_as_python_and_json():
    for path in APP.rglob("*.py"):
        ast.parse(path.read_text(), filename=str(path))
    for path in APP.rglob("*.json"):
        json.loads(path.read_text())
