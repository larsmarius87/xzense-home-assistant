const assert=require('assert');
const fs=require('fs');
const vm=require('vm');
const registry={};
class HTMLElement {attachShadow(){this.shadowRoot={innerHTML:'',activeElement:null,querySelectorAll:()=>[],querySelector:()=>null,getElementById:()=>({addEventListener:()=>{}})};return this.shadowRoot;}}
const context={window:{customCards:[]},customElements:{get:k=>registry[k],define:(k,v)=>registry[k]=v},HTMLElement,document:{createElement:k=>new registry[k]()},console,confirm:()=>true,Date,Intl};
vm.runInNewContext(fs.readFileSync('custom_components/xzense_full_preview/www/xzense-card.js','utf8'),context);
const card = new registry['xzense-card']();
card.setConfig({type:'custom:xzense-card',entities:{device_state_localized:'sensor.xzense_device_state_localized'}});
const states={'sensor.xzense_device_state_localized':{state:'ready_for_lighting',attributes:{friendly_name:'Xzense Localized device state'}}};
card.hass={states,localize:()=>'',config:{time_zone:'Europe/Oslo'}};
assert.strictEqual(card._format('device_state_localized'),'Klar for fyring');
assert(card.shadowRoot.innerHTML.includes('Klar for fyring'));
const custom = 'Egendefinert tekst fra nb.json';
let requested='';
card.hass={states,localize:(key)=>{requested=key;return custom;},config:{time_zone:'Europe/Oslo'}};
assert.strictEqual(card._format('device_state_localized'),custom);
assert.strictEqual(requested,'component.xzense_full_preview.entity.sensor.device_state_localized.state.ready_for_lighting');
states['sensor.xzense_device_state_localized'].state='afterrun';
card.hass={states,localize:()=>'',config:{time_zone:'Europe/Oslo'}};
assert.strictEqual(card._format('device_state_localized'),'Ettergang');
assert(card._action('start_fire','mdi:fire').includes('Start ny fyring')); // afterrun command still gated on original English wire label
states['sensor.xzense_device_state_localized'].state='unknown_state';
assert.strictEqual(card._format('device_state_localized'),'Ukjent tilstand');
console.log('Xzense Norwegian state translation UI OK');
