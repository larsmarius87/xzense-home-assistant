"""Release-baseline regressions for Xzense Alpha 0.5.7."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).parents[1]
COMPONENT = ROOT / "custom_components" / "xzense_full_preview"


def _function_sha256(path: Path, function_name: str) -> str:
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.col_offset == 4
            and node.name == function_name
        ):
            segment = "\n".join(source.splitlines()[node.lineno - 1 : node.end_lineno]) + "\n"
            return hashlib.sha256(segment.encode()).hexdigest()
    raise AssertionError(f"Function {function_name} not found")


def test_manifest_keeps_domain_and_alpha_identity():
    manifest = json.loads((COMPONENT / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["domain"] == "xzense_full_preview"
    assert manifest["name"] == "Xzense Alpha"
    assert manifest["version"] == "0.5.25-rc1"


def test_unmodified_ble_session_methods_are_unchanged_from_v055():
    # These methods are intentionally unchanged from 0.5.5.
    # Alpha 0.5.15 explicitly refactors _collect_fresh_advertisements,
    # _establish_source_connection and async_stop for proxy diagnostics.
    # Their new behaviours have separate regression tests.
    # 0.5.20 deliberately removes per-advertisement entity notifications,
    # so _record_advertisement is verified in test_optimization_0520 instead.
    expected = {
        "async_start": "e3bf85bb512f3f132139ec7c731b3017e5f28fb2502d61b71ee0ac6e91067c82",
        "_publish_candidates": "8ebd07da0f3f36ca1c7591ab0dea8cc96836a1eb7476a5efc22a1fdf7b0e1d3b",
        "_write_application_frame": "a3c7809ae3e7525fc951a8f94f72f4fb98f9785a43540687be1ea4958f2a89c6",
        "_send_application_connect": "61564afc96b5e88361324f0cf83261725da2683629f3a6895ade0d4ac9976169",
        "_send_status_request": "55098cf97b7e55dbfcaec5189287f780aef0311dfbd216a9abcaff7f0a38f2e6",
        "_is_authorization_error": "94586c948c8e13745d9faf1a55961b4d7b9170ebe31d255bd838dc38e8239729",
    }
    client_path = COMPONENT / "client.py"
    assert {name: _function_sha256(client_path, name) for name in expected} == expected


def test_firmware_version_formatter_remains_unchanged():
    assert hashlib.sha256((COMPONENT / "version.py").read_bytes()).hexdigest() == (
        "7ea97a270dc9df892fcaf629da8e4597c28018c58b77c5ada36e292bc70ec2bb"
    )
