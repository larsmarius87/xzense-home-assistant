"""0.5.12 configuration safety and exposure regressions."""
from pathlib import Path
import ast

ROOT=Path(__file__).resolve().parents[1]
COMP=ROOT / "custom_components/xzense_full_preview"

def source(name):
    return (COMP/name).read_text(encoding="utf-8")

def test_three_new_writable_configuration_numbers():
    src=source("features.py")
    assert '"alarm_setpoint",\n        "Alarm temperature",\n        "number",\n        "write_ready",\n        global_id=0x58' in src
    assert '"refire_time",\n        "Refire / Reboost time",\n        "number",\n        "write_ready",\n        global_id=0x59' in src
    assert '"burnout_time",\n        "Burnout timeout",\n        "number",\n        "write_ready",\n        global_id=0x5B' in src
    assert '"actual_draft",' not in src

def test_firmware_alarm_bounds_and_time_wire_bounds():
    src=source("settings.py")
    assert '"alarm_setpoint": SettingRule(150, 500, 0.1, "celsius", "tenths", 250)' in src
    assert '"refire_time": SettingRule(0, 45, 0.1, "minutes", "seconds_to_minutes", 3)' in src
    assert '"burnout_time": SettingRule(1, 200, 0.1, "minutes", "seconds_to_minutes", 5)' in src

def test_system_control_moves_to_configuration():
    src=source("select.py")
    assert 'self._attr_entity_category = EntityCategory.CONFIG' in src

def test_time_values_are_numbers_not_diagnostic_sensors():
    src=source("sensor.py")
    assert '"refire_time", "Refire / Reboost time"' not in src
    assert '"burnout_time", "Burnout time"' not in src
    assert 'EntityCategory.CONFIG' not in src  # sensors cannot legally be config entities
    assert '"Actual chimney draught (raw)"' not in src
    assert '"raw_global_5b"' not in src
    assert '"refire_time", "Refire / Reboost time"' not in src

def test_cleanup_preserves_promoted_settings_and_removes_draft_sensor():
    src=source("__init__.py")
    assert '"actual_draft"' in src
    assert '"raw_global_5b"' in src
    cleanup=src.split('obsolete_suffixes = (',1)[1].split(')',1)[0]
    assert '"alarm_setpoint"' not in cleanup
    assert '"refire_time"' not in cleanup
