"""0.5.19.3: regression for HA slider display and active seconds migration."""
from __future__ import annotations
import ast
import asyncio
from datetime import UTC
import importlib.util
from pathlib import Path
from types import SimpleNamespace

COMP=Path(__file__).resolve().parents[1]/'custom_components/xzense_full_preview'
SOURCE=(COMP/'client.py').read_text()
NUMBERS=(COMP/'number.py').read_text()


def _method(name, source=SOURCE, cls='XzenseClient', namespace=None):
    tree=ast.parse(source)
    klass=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
    method=next(n for n in klass.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
    ns={'asyncio': asyncio}
    ns.update(namespace or {})
    exec(compile(ast.fix_missing_locations(ast.Module(body=[method], type_ignores=[])), '<method>', 'exec', flags=0x1000000),ns)
    return ns[name]


def test_both_number_entities_display_as_slider_without_overwriting_mode():
    tree=ast.parse(NUMBERS)
    for name in ('XzenseUpdateInterval','XzenseActiveUpdateInterval'):
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name)
        assign=next(n for n in cls.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_attr_mode' for t in n.targets))
        assert ast.unparse(assign.value)=='NumberMode.SLIDER'
        method=_method('extra_state_attributes',NUMBERS,name)
        fake=SimpleNamespace(client=SimpleNamespace(idle_interval_minutes=5,active_interval_seconds=90))
        attrs=method.fget(fake)
        assert 'mode' not in attrs
        assert attrs['bluetooth_connection_mode']=='periodic'
        # HA's mode='slider' comes from NumberEntity, not our custom attributes.
    assert 'UnitOfTime.SECONDS' in NUMBERS
    assert '_attr_native_max_value = 600' in NUMBERS
    assert 'UnitOfTime.MINUTES' in NUMBERS
    assert '_attr_native_max_value = 120' in NUMBERS


def _construct_client_with_options(opts):
    init=_method('__init__', namespace={
        'XzenseState': lambda:SimpleNamespace(update_interval_seconds=300,interval_profile='idle'),
        'XzenseFrameParser': lambda:None,
        'XzenseTiming':lambda:None,
        'Store':lambda *_: None,
        'DEFAULT_UPDATE_INTERVAL_MINUTES':5,
        'DEFAULT_ACTIVE_INTERVAL_SECONDS':0,
    })
    class Fake:
        def current_device_state(self): return self.device_state
        def _update_effective_interval(self):
            self.state.update_interval_seconds=self.active_interval_seconds if self.device_state==4 else self.idle_interval_minutes*60
    fake=Fake();fake.device_state=4
    entry=SimpleNamespace(options=opts,entry_id='test-entry')
    init(fake,SimpleNamespace(),entry,'AB:CD','test','0000')
    return fake


def test_migrate_legacy_minutes_to_seconds_without_losing_existing_setting():
    for old_minutes,expected in ((0,0),(1,60),(2,120),(5,300),(10,600)):
        fake=_construct_client_with_options({'idle_update_interval_minutes':5,'active_update_interval_minutes':old_minutes})
        assert fake.active_interval_seconds==expected
        assert fake.state.active_update_interval_seconds==expected
    # Prefer new seconds option when both exist (old option may still remain).
    fake=_construct_client_with_options({'active_update_interval_minutes':5,'active_update_interval_seconds':45})
    assert fake.active_interval_seconds==45
    assert _construct_client_with_options({}).active_interval_seconds==0
    assert _construct_client_with_options({'active_update_interval_minutes':900}).active_interval_seconds==600


def test_effective_interval_picks_exact_seconds_without_rounding():
    prop=_method('interval_seconds')
    old_prop=_method('interval_minutes')
    for active_seconds in (0,1,10,45,59,60,90,121,599,600):
        fake=SimpleNamespace(active_interval_seconds=active_seconds,idle_interval_minutes=5, _is_active_state=lambda:True)
        assert prop.fget(fake)==active_seconds
        assert round(old_prop.fget(fake)*60)==active_seconds
        fake._is_active_state=lambda:False
        assert prop.fget(fake)==300
        assert old_prop.fget(fake)==5


def test_set_active_seconds_persists_new_option_not_legacy_minutes():
    fn=_method('async_set_interval',namespace={'HomeAssistantError':ValueError})
    async def run():
        options={'idle_update_interval_minutes':5,'active_update_interval_minutes':1}
        changes=[]
        fake=SimpleNamespace(
            active_interval_seconds=60,
            idle_interval_minutes=5,
            state=SimpleNamespace(active_update_interval_seconds=60, active_update_interval_minutes=1, idle_update_interval_minutes=5),
            entry=SimpleNamespace(options=options),
            hass=SimpleNamespace(config_entries=SimpleNamespace(async_update_entry=lambda ent,options:changes.append(options))),
            _update_effective_interval=lambda:True,
            _wake=asyncio.Event(),
            _notify_listeners=lambda:None,
        )
        await fn(fake,45,active=True)
        assert fake.active_interval_seconds==45
        assert fake.state.active_update_interval_seconds==45
        assert changes[-1]['active_update_interval_seconds']==45
        assert changes[-1]['active_update_interval_minutes']==1  # legacy preserved for rollback
        await fn(fake,0,active=True)
        assert fake.active_interval_seconds==0
        assert changes[-1]['active_update_interval_seconds']==0
        await fn(fake,600,active=True)
        assert changes[-1]['active_update_interval_seconds']==600
        try:
            await fn(fake,601,active=True)
        except ValueError:
            pass
        else:
            raise AssertionError('601 seconds must fail')
    asyncio.run(run())


def test_package_dashboard_copies_identical_and_second_range_correct():
    root=COMP.parent.parent
    assert (root/'www/xzense-card.js').read_bytes()==(COMP/'www/xzense-card.js').read_bytes()
    assert '0–600 sekunder' in (root/'www/xzense-card.js').read_text()
    assert 'Xzense Dashboard 0.5.26' in (root/'www/xzense-card.js').read_text()
