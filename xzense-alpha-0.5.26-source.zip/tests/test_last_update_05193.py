"""Existing last_data_at entity remains stable with localized dashboard display."""
from pathlib import Path
import ast

ROOT=Path(__file__).resolve().parents[1]
SENSOR=(ROOT/'custom_components/xzense_full_preview/sensor.py').read_text()
CARD=(ROOT/'custom_components/xzense_full_preview/www/xzense-card.js').read_text()

def test_last_update_is_existing_sensor_not_duplicate():
    assert SENSOR.count('SensorDescription("last_data_at",')==1
    assert 'SensorDescription("last_data_at", "Sist oppdatert (Bluetooth)", lambda s: s.last_data_at)' in SENSOR
    assert 'self._attr_unique_id = f"{client.address}_{description.key}"' in SENSOR
    ast.parse(SENSOR)

def test_dashboard_shows_last_data_update_in_main_and_diagnostics():
    assert 'Sist oppdatert:' in CARD
    assert 'Sist oppdatert (Bluetooth)' in CARD
    assert "_lastUpdatedInfo()" in CARD
    assert "this._state('last_successful_bt_status')?.attributes?.timestamp_iso" in CARD
    assert "last_successful_bt_status" in CARD
    assert (ROOT/'www/xzense-card.js').read_text()==CARD
