"""Run bundled Xzense regression checks with standard Python (no pytest needed).

This is an offline code-level smoke/regression runner, NOT an on-device BLE test.
Historical tests needing separately archived binaries self-skip when absent.
"""

import importlib.util
import inspect
import logging
from pathlib import Path
import sys

logging.disable(logging.CRITICAL)  # Expected simulated BLE failures are exercised.
passed = 0
failed = []
for path in sorted((Path(__file__).parent / "tests").glob("test_*.py")):
    spec = importlib.util.spec_from_file_location("xzense_test_" + path.stem, path)
    try:
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
    except Exception as exc:
        failed.append((path.name, "import", str(exc)))
        continue
    for name, fn in vars(module).items():
        if not name.startswith("test_") or not callable(fn) or inspect.signature(fn).parameters:
            continue
        try:
            fn()
            passed += 1
        except Exception as exc:
            failed.append((path.name, name, str(exc)))

print(f"Tests: {passed} passed, {len(failed)} failed")
for file_name, test_name, error in failed:
    print(f"FAIL {file_name}::{test_name}: {error}")
sys.exit(bool(failed))
