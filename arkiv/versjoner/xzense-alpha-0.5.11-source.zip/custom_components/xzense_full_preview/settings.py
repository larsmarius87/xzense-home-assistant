"""Verified Xzense setting scaling and Home Assistant UI bounds.

GLOBAL IDs and wire scaling are established from the user's live controller
correlations.  Where the Xzense manual publishes a setting range, that range is
used for the Home Assistant number entity.  Boost-stop temperature has no range
stated in the manual; its UI bound is deliberately conservative and is not a
claim about the firmware's internal limit.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Scale = Literal["direct", "tenths", "seconds_to_minutes"]
UnitKind = Literal["percent", "celsius", "minutes", "pascal", "volt", "none"]


@dataclass(frozen=True, slots=True)
class SettingRule:
    minimum: float
    maximum: float
    step: float
    unit: UnitKind
    scale: Scale = "direct"


SETTING_RULES: dict[str, SettingRule] = {
    # Manual: Interface settings 0-100 %.
    "volume_raw": SettingRule(0, 100, 1, "percent"),
    "contrast_raw": SettingRule(0, 100, 1, "percent"),
    "brightness_raw": SettingRule(0, 100, 1, "percent"),
    # Manual service-menu ranges.
    "auto_start_temperature": SettingRule(5, 100, 0.1, "celsius", "tenths"),
    "auto_stop_temperature": SettingRule(0, 95, 0.1, "celsius", "tenths"),
    "boost_time": SettingRule(1, 15, 1, "minutes", "seconds_to_minutes"),
    "afterrun_time": SettingRule(1, 200, 1, "minutes", "seconds_to_minutes"),
    "boost_fan_speed": SettingRule(40, 100, 1, "percent"),
    # 4.10 RC2 Fan Control slider + earlier physical 0x50 write test: direct %.
    "user_fan_speed": SettingRule(10, 100, 1, "percent"),
    "wanted_draft": SettingRule(8, 60, 1, "pascal"),
    "minimum_fan_voltage": SettingRule(80, 120, 1, "volt"),
    # Manual lists the factory value but not an explicit range for this item.
    "boost_stop_temperature": SettingRule(0, 400, 0.1, "celsius", "tenths"),
}


def raw_to_native(key: str, raw: int) -> float:
    """Convert a signed-int16 GLOBAL value to its HA-facing value."""
    rule = SETTING_RULES.get(key)
    if rule is None or rule.scale == "direct":
        return float(raw)
    if rule.scale == "tenths":
        return raw / 10.0
    if rule.scale == "seconds_to_minutes":
        return raw / 60.0
    raise ValueError(f"Unsupported scale for {key}: {rule.scale}")


def native_to_raw(key: str, value: float) -> int:
    """Convert an HA-facing number back to the signed-int16 GLOBAL value."""
    rule = SETTING_RULES.get(key)
    if rule is None or rule.scale == "direct":
        return int(round(value))
    if rule.scale == "tenths":
        return int(round(value * 10.0))
    if rule.scale == "seconds_to_minutes":
        return int(round(value * 60.0))
    raise ValueError(f"Unsupported scale for {key}: {rule.scale}")
