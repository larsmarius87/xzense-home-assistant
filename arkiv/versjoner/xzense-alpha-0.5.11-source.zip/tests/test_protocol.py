import importlib.util
from pathlib import Path
import sys

PROTOCOL_PATH = Path(__file__).parents[1] / "custom_components" / "xzense_full_preview" / "protocol.py"
spec = importlib.util.spec_from_file_location("xzense_protocol_test", PROTOCOL_PATH)
protocol = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = protocol
spec.loader.exec_module(protocol)

XzenseFrameParser = protocol.XzenseFrameParser
build_connect_request = protocol.build_connect_request
build_frame = protocol.build_frame
crc16_ccitt_false = protocol.crc16_ccitt_false


def test_crc_known_vector():
    assert crc16_ccitt_false(b"123456789") == 0x29B1


def test_frame_roundtrip():
    raw = build_frame(0x06, bytes.fromhex("020a0102030405060708"))
    parser = XzenseFrameParser()
    frames = parser.feed(raw)
    assert len(frames) == 1
    frame = frames[0]
    assert frame.outer_type == 0x06
    assert frame.packet_type == 0x02
    assert frame.protocol_type == 0x0A
    assert frame.session_id == 0x04030201
    assert parser.invalid_frames == 0


def test_reserved_bytes_are_escaped_and_roundtrip():
    payload = bytes((0x23, 0x24, 0x27, 0x01))
    raw = build_frame(0x06, payload)
    assert bytes.fromhex("27a3") in raw
    assert bytes.fromhex("27a4") in raw
    assert bytes.fromhex("27a7") in raw
    parser = XzenseFrameParser()
    assert parser.feed(raw)[0].payload == payload


def test_fragmented_notifications():
    raw = build_frame(0x06, b"abcdef")
    parser = XzenseFrameParser()
    assert parser.feed(raw[:4]) == []
    assert parser.feed(raw[4:9]) == []
    frames = parser.feed(raw[9:])
    assert len(frames) == 1
    assert frames[0].payload == b"abcdef"


def test_connect_request_pin_zero_safe_time():
    raw = build_connect_request("0000", "HomeAssistant")
    # body size: network/type (2) + inner packet (22) = 24 = 0x0018
    assert raw == bytes.fromhex(
        "2318000006020b0000000000000d486f6d65417373697374616e74254d24"
    )
    frame = XzenseFrameParser().feed(raw)[0]
    assert frame.payload[:9] == bytes.fromhex("020b0000000000000d")
    assert frame.payload[9:] == b"HomeAssistant"


def test_status_request_matches_public_capture():
    raw = protocol.build_status_request(0xED249437)
    assert raw == bytes.fromhex("2308000006070b379427a4ed398b24")
    frame = XzenseFrameParser().feed(raw)[0]
    assert frame.packet_type == protocol.PACKET_STATUS
    assert frame.protocol_type == protocol.PROTOCOL_REQ
    assert frame.application_payload == bytes.fromhex("379424ed")


def test_decode_status_ack_live_10_percent_49c_snapshot():
    # Synchronized live snapshot: panel showed fan 10 % and chimney 49 C.
    # STATUS payload: state=4, state_timer=579, fan=10, chimney=490,
    # outside=48, inside=213, pressure=1011 hPa, flags=0.
    raw = bytes.fromhex(
        "2312000006070a0443020a00ea013000d500f30300560424"
    )
    frame = XzenseFrameParser().feed(raw)[0]
    status = protocol.decode_status_data(frame)
    assert status is not None
    assert status.raw == bytes.fromhex("0443020a00ea013000d500f30300")
    assert status.device_state == 4
    assert status.state_timer == 579
    assert status.fan_speed == 10
    assert status.chimney_temperature_raw == 490
    assert status.chimney_temperature == 49.0
    assert status.outside_temperature_raw == 48
    assert status.outside_temperature == 4.8
    assert status.inside_temperature_raw == 213
    assert status.inside_temperature == 21.3
    assert status.air_pressure_hpa == 1011
    assert status.air_pressure_hpa == 1011
    assert status.flags == 0


def test_decode_status_ack_live_boosting_100_percent_snapshot():
    # Synchronized live snapshot: panel showed fan 100 %, Boosting and
    # chimney 49 C. This proves device state 3 == Boosting and fan is the
    # first i16 after the state timer.
    raw = bytes.fromhex(
        "2312000006070a0387006400ea013200da00f30300a82024"
    )
    frame = XzenseFrameParser().feed(raw)[0]
    status = protocol.decode_status_data(frame)
    assert status is not None
    assert status.device_state == 3
    assert protocol.device_state_name(status.device_state) == "Boosting"
    assert status.state_timer == 135
    assert status.fan_speed == 100
    assert status.chimney_temperature == 49.0
    assert status.outside_temperature == 5.0
    assert status.inside_temperature == 21.8
    assert status.air_pressure_hpa == 1011
    assert status.flags == 0


def test_unknown_device_state_is_not_guessed():
    assert protocol.device_state_name(99) == "Unknown (99)"

def test_decode_status_data_with_session_prefix_tolerated():
    session_id = 0x0ED123F6
    body = bytes.fromhex("0443020a00ea013000d500f30300")
    raw = build_frame(
        protocol.OUTER_TYPE_APPLICATION,
        bytes((protocol.PACKET_STATUS, protocol.PROTOCOL_DATA))
        + session_id.to_bytes(4, "little")
        + body,
    )
    frame = XzenseFrameParser().feed(raw)[0]
    status = protocol.decode_status_data(frame, session_id)
    assert status is not None
    assert status.device_state == 4
    assert status.fan_speed == 10
    assert status.chimney_temperature == 49.0
    assert status.inside_temperature == 21.3


def test_decode_global_data_three_byte_entries():
    payload = bytes((
        protocol.PACKET_GLOBAL,
        protocol.PROTOCOL_DATA,
        0x1E, 0xEA, 0x01,  # chimney 490 -> 49.0 C
        0x1F, 100, 0,      # fan 100 %
        0x20, 10, 0,       # still unidentified
    ))
    raw = build_frame(protocol.OUTER_TYPE_APPLICATION, payload)
    frame = XzenseFrameParser().feed(raw)[0]
    values = protocol.decode_global_data(frame)
    assert values == {0x1E: 490, 0x1F: 100, 0x20: 10}


def test_short_status_payload_is_not_decoded():
    raw = build_frame(
        protocol.OUTER_TYPE_APPLICATION,
        bytes((protocol.PACKET_STATUS, protocol.PROTOCOL_ACK)) + bytes(13),
    )
    frame = XzenseFrameParser().feed(raw)[0]
    assert protocol.decode_status_data(frame) is None


def test_global_request_matches_public_capture():
    raw = protocol.build_global_request(0xED249437, 0x50, 0x12)
    assert raw == bytes.fromhex("230b000006060b379427a4ed5012005aa424")
    frame = XzenseFrameParser().feed(raw)[0]
    assert frame.packet_type == protocol.PACKET_GLOBAL
    assert frame.protocol_type == protocol.PROTOCOL_REQ
    assert frame.application_payload == bytes.fromhex("379424ed501200")


def test_decode_status_ack_live_afterrun_pressure_snapshot():
    # User-confirmed synchronized snapshot: state 6 == Afterrun and 1011 is air pressure hPa.
    raw = bytes.fromhex("2312000006070a0625000a0086013900e800f30300c04724")
    frame = XzenseFrameParser().feed(raw)[0]
    status = protocol.decode_status_data(frame)
    assert status is not None
    assert status.device_state == 6
    assert protocol.device_state_name(status.device_state) == "Afterrun"
    assert status.state_timer == 37
    assert status.fan_speed == 10
    assert status.chimney_temperature == 39.0
    assert status.outside_temperature == 5.7
    assert status.inside_temperature == 23.2
    assert status.air_pressure_hpa == 1011
    assert status.flags == 0


def test_boost_packet_name_is_recovered_from_firmware():
    raw = protocol.build_boost_request(0xBCCECBC1, True, 218)
    frame = XzenseFrameParser().feed(raw)[0]
    assert frame.packet_type == protocol.PACKET_BOOST == 0x08
    assert frame.packet_type_name == "BOOST"
    assert frame.protocol_type == protocol.PROTOCOL_REQ


def test_build_boost_on_request_payload():
    raw = protocol.build_boost_request(0xBCCECBC1, True, 218)
    frame = XzenseFrameParser().feed(raw)[0]
    assert frame.application_payload == bytes.fromhex("c1cbcebc01da00")


def test_build_boost_off_request_payload():
    raw = protocol.build_boost_request(0xA308D674, False, 232)
    frame = XzenseFrameParser().feed(raw)[0]
    assert frame.application_payload == bytes.fromhex("74d608a300e800")


def test_corrected_global_name_map():
    expected = {
        0x05: "POWER_SOURCE",
        0x32: "SOUND",
        0x33: "CONTRAST",
        0x34: "BRIGHTNESS",
        0x35: "UNKNOWN_35",
        0x36: "UNKNOWN_36",
        0x4B: "START_TEMP",
        0x4C: "STOP_TEMP",
        0x4D: "BOOST_TIME",
        0x4E: "AFTERRUN_TIME",
        0x4F: "BOOST_SPEED",
        0x50: "USER_FAN_SPEED",
        0x51: "ACTUAL_DRAFT",
        0x52: "BOOST_STOP_TEMP",
        0x53: "CHIMNEY_DRAFT_SETPOINT",
        0x54: "MIN_FAN_VOLTAGE",
        0x55: "SYSTEM_CONTROL",
        0x56: "TEMPERATURE_SENSOR",
        0x5B: "BURNOUT_TIMEOUT",
    }
    for global_id, name in expected.items():
        assert protocol.GLOBAL_NAMES[global_id] == name


def test_device_state_names_follow_v410_controller_sequence():
    assert protocol.device_state_name(1) == "Setup"
    assert protocol.device_state_name(2) == "Ready for lighting"
    assert protocol.device_state_name(3) == "Boosting"
    assert protocol.device_state_name(4) == "Operation"
    assert protocol.device_state_name(5) == "Burnout"
    assert protocol.device_state_name(6) == "Afterrun"
    assert protocol.device_state_name(7) == "Refueling"
    assert protocol.device_state_name(8) == "Ventilation"
    assert protocol.device_state_name(9) == "Error"
    assert protocol.device_state_name(10) == "Upgrading"


def test_ventilation_packet_name_and_on_payload():
    raw = protocol.build_ventilation_request(0xBCCECBC1, True)
    frame = XzenseFrameParser().feed(raw)[0]
    assert frame.packet_type == protocol.PACKET_VENTILATION == 0x09
    assert frame.packet_type_name == "VENTILATION"
    assert frame.protocol_type == protocol.PROTOCOL_REQ
    assert frame.application_payload == bytes.fromhex("c1cbcebc01")


def test_ventilation_off_payload():
    raw = protocol.build_ventilation_request(0xA308D674, False)
    frame = XzenseFrameParser().feed(raw)[0]
    assert frame.application_payload == bytes.fromhex("74d608a300")


def test_system_control_firmware_enum():
    assert protocol.SYSTEM_CONTROL_VALUE_TO_NAME == {
        0: "Manual",
        1: "eXotelligence",
        2: "Pressure controlled",
    }
    assert protocol.SYSTEM_CONTROL_NAME_TO_VALUE == {
        "Manual": 0,
        "eXotelligence": 1,
        "Pressure controlled": 2,
    }


def test_unverified_legacy_debug_names_are_not_asserted_as_fact():
    for global_id in range(0x05):
        assert protocol.GLOBAL_NAMES[global_id] == f"UNKNOWN_{global_id:02X}"
    assert 0xFF not in protocol.GLOBAL_NAMES


def test_device_state_debug_label_uses_verified_meaning():
    assert protocol.GLOBAL_NAMES[0x19] == "DEVICE_STATE"
