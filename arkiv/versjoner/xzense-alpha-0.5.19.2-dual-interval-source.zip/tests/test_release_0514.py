"""Alpha 0.5.14: regression guards for the bundled dashboard and probe."""
from pathlib import Path
import ast
import json

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "custom_components" / "xzense_full_preview"


def test_dashboard_bundled_at_served_path_and_not_requiring_local_www():
    init = (COMP / "__init__.py").read_text()
    card = COMP / "www" / "xzense-card.js"
    assert card.exists()
    assert "/api/xzense_full_preview/xzense-card.js" in init
    assert "async_register_static_paths" in init
    assert "StaticPathConfig" in init
    assert "xzense-card-editor" in card.read_text()
    assert "config-changed" in card.read_text()
    assert "data-entity" in card.read_text()


def test_sensor_strings_do_not_exceed_ha_state_limit():
    tree = ast.parse((COMP / "sensor.py").read_text())
    fn = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == "_global_dump")
    assert 'GLOBAL-felt' in ast.get_source_segment((COMP / "sensor.py").read_text(), fn)
    klass = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == "XzenseSensor")
    native = next(x for x in klass.body if isinstance(x, ast.FunctionDef) and x.name == "native_value")
    assert '255' in ast.get_source_segment((COMP / "sensor.py").read_text(), native)
    assert "full_value" in (COMP / "sensor.py").read_text()


def test_temperature_probe_controls_use_direct_boolean_values():
    source = (COMP / "switch.py").read_text()
    assert 'raw = self.client.state.globals.get(0x56)' in source
    assert 'raw in (0, 1)' in source
    assert '1 if self.feature.key == "temperature_sensor" else True' in source
    assert '0 if self.feature.key == "temperature_sensor" else False' in source
    assert '"temperature_sensor", "external_start"' not in (COMP / "__init__.py").read_text()


def test_version_is_numeric_matching_const():
    data = json.loads((COMP / "manifest.json").read_text())
    assert data["version"] in ("0.5.14", "0.5.15", "0.5.16", "0.5.17", "0.5.19", "0.5.19.2")
    assert f'VERSION = "{data["version"]}"' in (COMP / "const.py").read_text()


def test_existing_control_features_preserved():
    sys = (COMP / "features.py").read_text()
    for key in ("start_fire","stop_fire","refuel","boost","ventilation","system_control", "user_fan_speed", "temperature_sensor", "alarm_setpoint", "refire_time", "burnout_time", "volume_raw", "contrast_raw", "brightness_raw"):
        assert f'"{key}"' in sys
