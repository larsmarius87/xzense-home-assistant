"""Regression checks for the bounded, Stue-only cached-device fallback."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "custom_components" / "xzense_full_preview"

def test_reuses_only_stue_cache_if_no_fresh_advertisement():
    source = (COMP / "client.py").read_text()
    assert 'LOCKED_BLUETOOTH_SOURCE = "8C:D0:B2:A9:21:22"' in source
    assert 'str(getattr(item.scanner, "source", "")) != LOCKED_BLUETOOTH_SOURCE' in source
    assert 'scan_budget = (CACHED_STUE_SCAN_SECONDS if cached_on_entry' in source
    assert 'self.state.cached_stue_without_fresh_count += 1' in source
    assert 'rank_proxy_candidates(self._cached_source_candidates())' in source
    assert 'time.monotonic() - last_failure >= RECENT_SOURCE_FAILURE_SECONDS' in source
    assert 'candidates = [c for c in candidates if c.source == LOCKED_BLUETOOTH_SOURCE]' in source
    assert 'if LOCKED_BLUETOOTH_SOURCE:\n            return False' in source

def test_diagnostics_and_version():
    import json
    diag = (COMP / "diagnostics.py").read_text()
    manifest = json.loads((COMP / "manifest.json").read_text())
    assert manifest["version"] == "0.5.23"
    assert '"cached_stue_without_fresh_count": state.cached_stue_without_fresh_count' in diag
    assert '"source_lock_active": True' in diag


def test_cached_stue_attempt_after_missing_fresh_packet():
    """Execute the actual candidate collector with lightweight HA/BLE doubles."""
    import ast
    import asyncio
    import time
    from types import SimpleNamespace
    source = (COMP / "client.py").read_text()
    tree = ast.parse(source)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "XzenseClient")
    method = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "_collect_fresh_advertisements")

    class ImmediateTimeoutEvent:
        async def wait(self):
            raise TimeoutError
        def set(self):
            pass

    class FakeAsyncio:
        Event = ImmediateTimeoutEvent
        timeout = staticmethod(asyncio.timeout)
        sleep = staticmethod(asyncio.sleep)

    async def fake_scan(_seconds):
        await asyncio.sleep(0)

    class FakeClient:
        address = "84:8B:CD:50:36:29"
        _preferred_source = None
        _source_failure_at = {}
        def __init__(self, cache):
            self.cache = cache
            self.hass = SimpleNamespace(async_create_task=lambda coro: asyncio.create_task(coro))
            self.state = SimpleNamespace(advertisement_waits=0, advertisement_timeouts=0,
                source_discovery_method=None, adapter_collection_last_seconds=None,
                cached_stue_without_fresh_count=0)
            self.phases = []
            self.candidates = []
        def _cached_source_candidates(self):
            return self.cache
        def _set_phase(self, phase):
            self.phases.append(phase)
        def _set_error(self, message):
            self.error = message
        def _publish_candidates(self, choices):
            self.candidates = choices

    source_addr = "8C:D0:B2:A9:21:22"
    cached = SimpleNamespace(source=source_addr, rssi=-92, device=object(), origin="per_scanner_cache")
    namespace = {
        'asyncio': FakeAsyncio, 'time': time,
        'ADVERTISEMENT_WAIT_TIMEOUT': 45.0,
        'CACHED_STUE_SCAN_SECONDS': 3.0,
        'ADAPTER_COLLECTION_WINDOW': 3.0,
        'RECENT_SOURCE_FAILURE_SECONDS': 120.0,
        'LOCKED_BLUETOOTH_SOURCE': source_addr,
        'bluetooth': SimpleNamespace(
            BluetoothServiceInfoBleak=object, BluetoothChange=object,
            async_clear_advertisement_history=lambda *args: None,
            async_register_advertisement_callback=lambda *args: lambda: None,
            async_request_active_scan=fake_scan,
        ),
        'callback': lambda fn: fn,
        '_BleSourceCandidate': SimpleNamespace,
        'rank_proxy_candidates': lambda values: list(values),
        '_LOGGER': SimpleNamespace(info=lambda *args: None),
    }
    exec(compile(ast.fix_missing_locations(ast.Module(body=[method], type_ignores=[])), 'test', 'exec'), namespace)
    collector = namespace['_collect_fresh_advertisements']

    async def run():
        f = FakeClient([cached])
        result = await collector(f)
        assert result == [cached]
        assert 'cached_stue_candidate_ready' in f.phases
        assert f.state.cached_stue_without_fresh_count == 1
        assert f.state.source_discovery_method == 'locked_stue_cache_without_fresh_advertisement'
        assert f.state.adapter_collection_last_seconds == 3.0

        blocked = FakeClient([cached])
        blocked._source_failure_at = {source_addr: time.monotonic()}
        result = await collector(blocked)
        assert result == []
        assert blocked.state.cached_stue_without_fresh_count == 0
        assert blocked.state.advertisement_timeouts == 1

        unavailable = FakeClient([])
        result = await collector(unavailable)
        assert result == []
        assert unavailable.state.advertisement_timeouts == 1
    asyncio.run(run())
