"""Static regression checks for the deliberately hard-coded Stue-only test."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "custom_components" / "xzense_full_preview"

def test_stue_lock_wired_at_every_entrypoint():
    client = (COMP / "client.py").read_text()
    diagnostics = (COMP / "diagnostics.py").read_text()
    assert 'LOCKED_BLUETOOTH_SOURCE = "8C:D0:B2:A9:21:22"' in client
    assert 'getattr(item.scanner, "source", "")' in client
    assert 'if self._source_key(service_info) != LOCKED_BLUETOOTH_SOURCE:' in client
    assert 'candidates = [c for c in candidates if c.source == LOCKED_BLUETOOTH_SOURCE]' in client
    assert 'if LOCKED_BLUETOOTH_SOURCE:\n            return False' in client
    assert '"source_lock_active": True' in diagnostics
    assert '"locked_bluetooth_source": LOCKED_BLUETOOTH_SOURCE' in diagnostics
