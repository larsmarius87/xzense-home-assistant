"""Number controls for verified Xzense settings and local test helpers."""

from __future__ import annotations

from homeassistant.components.number import NumberEntity, NumberMode
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import (
    EntityCategory,
    PERCENTAGE,
    UnitOfElectricPotential,
    UnitOfPressure,
    UnitOfTemperature,
    UnitOfTime,
)
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient
from .const import DOMAIN
from .entity import XzenseEntity, XzenseFeatureEntity
from .features import FEATURES, FeatureSpec
from .settings import SETTING_RULES, native_to_raw, raw_to_native

NUMBER_FEATURES = tuple(f for f in FEATURES if f.kind == "number" and f.state == "write_ready")

_UNIT_BY_KIND = {
    "percent": PERCENTAGE,
    "celsius": UnitOfTemperature.CELSIUS,
    "minutes": UnitOfTime.MINUTES,
    "pascal": UnitOfPressure.PA,
    "volt": UnitOfElectricPotential.VOLT,
}


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([*(XzenseNumber(client, feature) for feature in NUMBER_FEATURES), XzenseUpdateInterval(client)])


class XzenseNumber(XzenseFeatureEntity, NumberEntity):
    """A numeric Xzense setting backed by a GLOBAL value."""

    _attr_mode = NumberMode.BOX

    def __init__(self, client: XzenseClient, feature: FeatureSpec) -> None:
        super().__init__(client, feature)
        if feature.key != "user_fan_speed":
            self._attr_entity_category = EntityCategory.CONFIG
        rule = SETTING_RULES.get(feature.key)
        if rule is None:
            raise ValueError(f"Missing verified setting rule for {feature.key}")

        self._attr_native_min_value = rule.minimum
        self._attr_native_max_value = rule.maximum
        self._attr_native_step = rule.step
        unit = _UNIT_BY_KIND.get(rule.unit)
        if unit is not None:
            self._attr_native_unit_of_measurement = unit

    @property
    def native_value(self) -> float | None:
        if self.feature.global_id is None:
            return None
        raw = self.client.state.globals.get(self.feature.global_id)
        return None if raw is None else raw_to_native(self.feature.key, raw)

    async def async_set_native_value(self, value: float) -> None:
        raw = native_to_raw(self.feature.key, value)
        await self.client.async_control_feature(self.feature.key, raw)


class XzenseUpdateInterval(XzenseEntity, NumberEntity):
    """Transport refresh interval: 0 continuous, 1–120 min periodic."""

    _attr_name = "Bluetooth update interval"
    _attr_entity_category = EntityCategory.CONFIG
    _attr_mode = NumberMode.SLIDER
    _attr_native_min_value = 0
    _attr_native_max_value = 120
    _attr_native_step = 1
    _attr_native_unit_of_measurement = UnitOfTime.MINUTES
    _attr_icon = "mdi:bluetooth-connect"

    def __init__(self, client: XzenseClient) -> None:
        super().__init__(client)
        self._attr_unique_id = f"{client.address}_bluetooth_update_interval"

    @property
    def native_value(self) -> float:
        return float(self.client.interval_minutes)

    async def async_set_native_value(self, value: float) -> None:
        await self.client.async_set_interval(int(value))

    @property
    def extra_state_attributes(self) -> dict[str, str]:
        return {"mode": "continuous" if self.client.interval_minutes == 0 else "periodic"}
