# Xzense Alpha 0.5.6 — feature matrix

| Feature | Status | Mapping / notes |
|---|---|---|
| BLE connect + PIN session | Working | DSPS BLE service + Xzense CONNECT; connection methods unchanged from 0.5.5 |
| Temporary BLE release to app | Working / integration-local | Adjustable 1-600 s, no Xzense control packet sent |
| Live status polling | Working | STATUS `0x07` |
| Device state | Verified read | GLOBAL `0x19`; labels 2=Ready for lighting, 3=Boosting, 4=Operation, 5=Refueling, 6=Afterrun |
| State timer | Verified read | GLOBAL `0x1A`, seconds |
| Air pressure | Verified read | GLOBAL `0x1B`, hPa |
| Inside temperature | Strong read mapping | GLOBAL `0x1C`, tenths °C |
| Outside temperature | Strong read mapping | GLOBAL `0x1D`, tenths °C |
| Chimney temperature | Verified read | GLOBAL `0x1E`, tenths °C |
| Actual fan speed | Verified read | GLOBAL `0x1F`, % |
| Power source | Verified read | GLOBAL `0x05`; `2=Battery`, `3=External power` |
| Firmware version | Verified read | CONNECT ACK; `410` -> `4.10` |
| Boost on/off | Verified write | packet `0x08`, start flag 1/0 + inside temperature |
| Start lighting | Firmware-derived / write-ready | In state 2, uses BOOST `0x08` with start=1 |
| Refuel | Firmware-derived / write-ready | In state 4, uses BOOST `0x08` with start=1 |
| Stop firing | Firmware-derived / write-ready | State 3/5 -> BOOST start=0; state 4 -> GLOBAL `0x19=6` |
| Finish firing | Firmware-derived / write-ready | State 4 -> GLOBAL `0x19=6` (Afterrun) |
| Ventilation | Firmware-derived / write-ready | packet `0x09`, session + start flag 1/0; live test pending |
| System control | Firmware-derived / write-ready | GLOBAL `0x56`; `0=Manual`, `1=eXotelligence`, `2=Pressure controlled` |
| Sound | Live-correlated / write-ready | GLOBAL `0x32`, direct %, panel 12→24 matched raw 12→24 |
| Contrast | Live-correlated / write-ready | GLOBAL `0x33`, direct %, panel 75 matched raw 75 |
| Brightness | Live-correlated / write-ready | GLOBAL `0x34`, direct %, panel 68 matched raw 68 |
| Start temperature | Live-correlated / write-ready | GLOBAL `0x4B`, raw / 10 °C; 502 -> 50.2 °C |
| Stop temperature | Live-correlated / write-ready | GLOBAL `0x4C`, raw / 10 °C; 398 -> 39.8 °C |
| Boost time | Live-correlated / write-ready | GLOBAL `0x4D`, seconds on wire / minutes in HA; 900 -> 15 min |
| Afterrun time | Live-correlated / write-ready | GLOBAL `0x4E`, seconds on wire / minutes in HA; 1800 -> 30 min |
| Boost speed | Live-correlated / write-ready | GLOBAL `0x4F`, direct %; 100 -> 100 % |
| Boost stop temperature | Live-correlated / write-ready | GLOBAL `0x52`, raw / 10 °C; 600 -> 60.0 °C |
| Chimney draught setpoint | Live-correlated / write-ready | GLOBAL `0x53`, direct Pa; 26 -> 26 Pa |
| Minimum fan voltage | Live-correlated / write-ready | GLOBAL `0x54`, direct V; 105 -> 105 V |
| GLOBAL `0x35` | Unknown / diagnostic | Raw read only; disabled diagnostic sensor |
| GLOBAL `0x36` | Unknown / diagnostic | Raw read only; disabled diagnostic sensor |
| GLOBAL `0x50` | Unknown / diagnostic | Raw read only; previous 0.5.3 setpoint interpretation is not carried forward |
| GLOBAL `0x51` | Unknown / diagnostic | Raw read only; not presented as actual draught |
| GLOBAL `0x55` | Unknown / diagnostic | Raw read only |
| Temperature sensor | Candidate read | GLOBAL `0x57`; coding not verified for writes |
| External start | Candidate read | GLOBAL `0x58`; not verified for writes |
| Alarm/refire/external fan fields | Candidate read | GLOBAL `0x59`-`0x5B`; labels/scaling still under verification |

The Home Assistant domain remains `xzense_full_preview` for registry compatibility. The user-facing integration name is **Xzense Alpha**.
