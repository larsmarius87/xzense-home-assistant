# Changelog

## 0.5.6 Alpha

- Built directly from the tested 0.5.5 source package.
- Preserved the complete BLE discovery/reconnect/session-acquisition and **Release Bluetooth to app** method implementations byte-for-byte at method level; regression hashes enforce this.
- Promoted **Start lighting** to a state-gated control: state 2 uses BOOST `0x08`, `start=1`.
- Promoted **Refuel** to a state-gated control: state 4 uses the same BOOST `0x08`, `start=1`, matching the controller firmware's Reheating path.
- Added context-aware **Stop firing**: state 3/5 sends BOOST `start=0`; state 4 transitions to Afterrun with GLOBAL `0x19=6`.
- Added explicit **Finish firing** button for Operation -> Afterrun via GLOBAL `0x19=6`.
- Added **Ventilation** switch using firmware-derived packet `0x09` with a one-byte start/stop flag; ACK/NACK diagnostics and last ACK-confirmed switch state are recorded.
- Promoted **System control** GLOBAL `0x56` to a writable select with firmware-derived enum `0=Manual`, `1=eXotelligence`, `2=Pressure controlled`.
- Added protocol/regression tests for Ventilation payloads, System control enum and the 0.5.5 connection-code boundary.
- No writes were enabled for unidentified `0x35`, `0x36`, `0x50`, `0x51`, `0x55` or candidate `0x57`-`0x5B` fields.

## 0.5.5 Alpha

- Built from the preserved 0.5.3 Alpha source baseline; the discarded 0.5.4 regression build is not used.
- Preserved the 0.5.3 BLE connection strategy and **Release Bluetooth to app** helper unchanged.
- Added live-correlated `0x32=Sound`, `0x33=Contrast` and `0x34=Brightness`.
- Corrected the setup block: `0x4B` Start temperature, `0x4C` Stop temperature, `0x4D` Boost time, `0x4E` Afterrun time and `0x4F` Boost speed.
- Corrected `0x52` Boost stop temperature, `0x53` chimney draught setpoint and `0x54` minimum fan voltage.
- Added native HA scaling: tenths °C -> °C and wire seconds -> minutes.
- Added manual-backed UI ranges for the settings whose ranges are published by Exodraft.
- Added verified power-source decoding: `0x05=2` Battery and `0x05=3` External power.
- Preserved firmware formatting from 0.5.3: CONNECT ACK `410` is shown as `4.10`.
- Removed all write access from unidentified `0x35`, `0x36`, `0x50`, `0x51`, `0x55` and from unverified `0x58`-`0x5B` candidates.
- Added disabled raw diagnostic sensors for `0x35`, `0x36`, `0x50`, `0x51` and `0x55`.

## 0.5.3 Alpha

- Added **Release Bluetooth to app** button. It disconnects Home Assistant from the Xzense control panel without sending any Xzense control command.
- Added local **Bluetooth app release time** number entity, adjustable from 1 to 600 seconds (default 60 seconds) for test use.
- While released, the integration suppresses its reconnect loop; when the timer expires it automatically resumes the existing fresh-advertisement connection strategy.
- Added BLE release state/counters to diagnostics.

## 0.5.2 — Xzense Alpha

- Renamed the user-facing integration from **Xzense Full Preview** to **Xzense Alpha** while retaining the `xzense_full_preview` domain for compatibility.
- Corrected GLOBAL `0x50` to **Fan speed setpoint** after a successful physical write test; values are direct percent.
- Rejected the previous `0x52` manual/user fan-speed mapping and returned it to unknown/read-only status.
- Corrected GLOBAL `0x54` to **Minimum fan voltage** after live observations at 80 V and 105 V.
- Returned `0x55` to unknown/read-only status.
- Bounded the verified fan-speed setpoint to 10-100 % and minimum fan-voltage test control to the documented 80-120 V service range.
- Updated protocol labels, feature matrix and tests to match the current live evidence.

## 0.5.1
- Corrected the interface-setting test mappings from a live panel cross-check.
- GLOBAL `0x34` is now treated as **Contrast** with a 0-100 % Home Assistant number control; panel contrast around 70 matched raw `68`.
- GLOBAL `0x33` is no longer labelled Volume and is no longer writable; panel sound was `0` while raw `0x33` was `75`, disproving the previous direct-volume mapping.
- Other experimental numeric GLOBAL controls remain raw signed-int16 until individually calibrated.
- No change to verified BOOST on/off behavior.

## 0.5.0 — experimental raw-write branch
- Branched from 0.4.7; 0.4.7 remains the stable test package.
- Enabled direct signed-int16 GLOBAL writes for selected recovered numeric setting IDs.
- Added raw write entities for Volume `0x33`, Contrast `0x34`, Brightness `0x35`, and Language `0x4B`.
- Opened existing numeric setting globals `0x4C-0x50`, `0x52-0x55`, and `0x59-0x5B` for raw writes.
- Removed guessed percentage scaling from experimental number entities; displayed values are the exact raw wire values.
- Added GLOBAL write request diagnostics (request count, ID, raw value, request/response timestamps).
- Kept System control `0x56`, Temperature sensor `0x57`, External start `0x58`, Ventilation `0x09`, BLE enable `0x36`, runtime/status values and Actual draft `0x51` write-locked.
- Boost On/Off remains separately live-verified.

## 0.4.7
- Firmware version is now read from `connect_ack_version`; observed raw `410` is exposed as `4.10`.
- Renamed device state `2` from `Standby` to `Ready for lighting` based on the Xzense operating sequence.
- Added manual-supported state labels `4 = Operation` and `5 = Refueling`; live verification is still pending for these two states.
- Removed the obsolete `Weather station` binary-sensor placeholder. The manual's Weather page is a presentation of outside temperature, chimney temperature and air pressure, which are already exposed separately.
- Removed the obsolete firmware-update scaffold; the integration now exposes the known firmware value as a read-only sensor.
- Added registry cleanup for stale `Chimney state`, `Weather station` and old `Firmware` placeholder entities from earlier preview builds.
- Kept `0x51 Actual draft` unchanged; raw zero is not hard-coded as “XTP not connected”.
- No new write commands were enabled. Boost On/Off remain the only write-ready controls.
- Retains the Xzense icon assets added in 0.4.6.

## 0.4.6
- Added bundled Xzense icon assets (`icon.png`, `logo.png`, and integration-local `custom_components/xzense_full_preview/icon.png`).
- No functional protocol or control changes from 0.4.5.

## 0.4.5
- Removed the global write lock by setting `CONTROL_WRITES_ENABLED = True`.
- Write access is still limited to features explicitly marked `write_ready`; unknown mappings remain unavailable.
- Added the first state-2 label (`Standby` at the time; corrected to `Ready for lighting` in 0.4.7).
- Kept Boost packet handling enabled.

## 0.4.4

- Removed the v0.4.3 experimental volume/fan write probes and their Afterrun gates.
- Added dedicated **Boost on** and **Boost off** buttons.
- Statically verified controller packet type `0x08` as `BOOST` from the bundled firmware.
- BOOST request uses active session ID + start/stop byte + current raw inside temperature.
- Added BOOST ACK/NACK/request diagnostics and immediate STATUS refresh after a command.
- All non-Boost control writes remain disabled.

## 0.4.3

- Confirms device state `6` as **Afterrun** from a synchronized live capture.
- Reclassifies GLOBAL/STATUS `0x1A` as **time in current state**; the value reset at the state transition and advanced about once per second.
- Confirms GLOBAL/STATUS `0x1B` as **air pressure in hPa**; user confirmed raw `1011` = **1011 hPa**.
- Corrects the 14-byte STATUS layout accordingly.
- Keeps state `3` = **Boosting**, `0x1E` = chimney temperature `/10`, and `0x1F` = actual fan speed `%`.
- Keeps all normal control writes disabled.
- Adds two explicit experimental write-probe buttons:
  - volume no-op: writes the existing `0x33` value back unchanged;
  - fan candidate probe: only in Afterrun below 60 °C with actual fan <=20 %, temporarily changes GLOBAL `0x50` by +10 (max 30), samples STATUS for about five seconds, then restores the original value.
- Records GLOBAL ACK/NACK and probe results in diagnostics.

## 0.4.2

- Calibrated chimney temperature and actual fan speed from synchronized live values.
- Corrected temperature scaling and left GLOBAL `0x20` unidentified.
