"""Feature matrix regression tests without Home Assistant imports."""
from pathlib import Path
import importlib.util
import sys

PATH = Path(__file__).parents[1] / "custom_components" / "xzense_full_preview" / "features.py"
spec = importlib.util.spec_from_file_location("xzense_features_test", PATH)
features = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = features
spec.loader.exec_module(features)


def test_key_app_features_are_scaffolded():
    keys = features.FEATURE_BY_KEY
    for key in (
        "start_fire", "stop_fire", "refuel", "start_afterrun", "boost_on", "boost_off", "ventilation",
        "user_fan_speed", "system_control", "chimney_temperature",
        "inside_temperature", "outside_temperature", "pressure",
        "actual_draft", "burn_count", "operation_time",
        "error_log", "firmware_version", "download_log",
    ):
        assert key in keys


def test_v056_verified_and_firmware_recovered_controls_are_write_ready():
    write_ready = {
        f.key
        for f in features.FEATURES
        if f.kind in {"button", "switch", "number", "select", "update"}
        and f.state == "write_ready"
    }
    assert write_ready == {
        "start_fire", "stop_fire", "refuel", "start_afterrun",
        "boost_on", "boost_off", "ventilation", "system_control",
        "volume_raw", "contrast_raw", "brightness_raw",
        "boost_fan_speed",
        "auto_start_temperature", "auto_stop_temperature",
        "boost_time", "afterrun_time", "boost_stop_temperature",
        "wanted_draft", "minimum_fan_voltage",
    }
    assert features.FEATURE_BY_KEY["boost_on"].packet_type == 0x08
    assert features.FEATURE_BY_KEY["boost_off"].packet_type == 0x08
    assert features.FEATURE_BY_KEY["start_fire"].packet_type == 0x08
    assert features.FEATURE_BY_KEY["refuel"].packet_type == 0x08
    assert features.FEATURE_BY_KEY["start_afterrun"].global_id == 0x19
    assert features.FEATURE_BY_KEY["ventilation"].packet_type == 0x09
    assert features.FEATURE_BY_KEY["system_control"].global_id == 0x56


def test_live_runtime_global_ids_are_unchanged():
    keys = features.FEATURE_BY_KEY
    assert keys["chimney_temperature"].global_id == 0x1E
    assert keys["fan_speed"].global_id == 0x1F
    assert keys["inside_temperature"].global_id == 0x1C
    assert keys["outside_temperature"].global_id == 0x1D
    assert keys["pressure"].global_id == 0x1B
    assert keys["pressure"].state == "verified_read"
    assert keys["state_timer"].global_id == 0x1A
    assert keys["device_state"].global_id == 0x19


def test_power_source_mapping_is_verified_read():
    key = features.FEATURE_BY_KEY["battery"]  # legacy key preserves unique_id
    assert key.name == "Power source"
    assert key.global_id == 0x05
    assert key.state == "verified_read"


def test_interface_setting_ids_match_live_panel_correlation():
    keys = features.FEATURE_BY_KEY
    expected = {
        "volume_raw": ("Sound", 0x32),
        "contrast_raw": ("Contrast", 0x33),
        "brightness_raw": ("Brightness", 0x34),
    }
    for key, (name, global_id) in expected.items():
        assert keys[key].name == name
        assert keys[key].global_id == global_id
        assert keys[key].state == "write_ready"
    assert keys["language_raw"].global_id is None
    assert keys["language_raw"].state == "mapping_pending"


def test_setup_setting_ids_match_live_panel_correlation():
    keys = features.FEATURE_BY_KEY
    expected = {
        "auto_start_temperature": 0x4B,
        "auto_stop_temperature": 0x4C,
        "boost_time": 0x4D,
        "afterrun_time": 0x4E,
        "boost_fan_speed": 0x4F,
        "boost_stop_temperature": 0x52,
        "wanted_draft": 0x53,
        "minimum_fan_voltage": 0x54,
    }
    for key, global_id in expected.items():
        assert keys[key].global_id == global_id
        assert keys[key].state == "write_ready"


def test_disproved_or_unknown_fields_are_not_write_ready():
    keys = features.FEATURE_BY_KEY
    for key in (
        "language_raw", "user_fan_speed", "actual_draft",
        "temperature_sensor", "external_start",
        "alarm_setpoint", "refire_time", "external_fan_speed",
    ):
        assert keys[key].state != "write_ready"

    # The old 0.5.3 fan-setpoint interpretation of GLOBAL 0x50 is not carried
    # forward as a writable feature in 0.5.6.
    assert not any(
        f.state == "write_ready" and f.global_id == 0x50 for f in features.FEATURES
    )


def test_removed_placeholders_stay_removed_and_firmware_sensor_stays_verified():
    keys = features.FEATURE_BY_KEY
    assert "weather_station" not in keys
    assert "chimney_state" not in keys
    assert "firmware" not in keys
    assert keys["firmware_version"].state == "verified_read"
