"""Safety/regression checks for the integration-local BLE release helper."""
from pathlib import Path
import ast

ROOT = Path(__file__).parents[1]
CLIENT = ROOT / "custom_components" / "xzense_full_preview" / "client.py"
BUTTON = ROOT / "custom_components" / "xzense_full_preview" / "button.py"
NUMBER = ROOT / "custom_components" / "xzense_full_preview" / "number.py"


def _method_source(path: Path, class_name: str, method_name: str) -> str:
    source = path.read_text()
    tree = ast.parse(source)
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and child.name == method_name:
                    return ast.get_source_segment(source, child) or ""
    raise AssertionError(f"{class_name}.{method_name} not found")


def test_ble_release_does_not_send_xzense_protocol_command() -> None:
    method = _method_source(CLIENT, "XzenseClient", "async_release_ble")
    assert "disconnect()" in method
    assert "_write_application_frame" not in method
    assert "build_global_request" not in method
    assert "build_boost_request" not in method


def test_connection_loop_honors_release_window_before_connecting() -> None:
    method = _method_source(CLIENT, "XzenseClient", "_connection_loop")
    assert "_wait_for_ble_release_window" in method
    assert method.index("_wait_for_ble_release_window") < method.index("_connect_once")


def test_release_button_and_seconds_number_are_exposed() -> None:
    assert "XzenseReleaseBleButton" in BUTTON.read_text()
    number_source = NUMBER.read_text()
    assert "XzenseBleReleaseSecondsNumber" in number_source
    assert "UnitOfTime.SECONDS" in number_source
