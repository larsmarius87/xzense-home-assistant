"""Scaling and UI-bound regressions for verified Xzense settings."""
from pathlib import Path
import importlib.util
import sys

PATH = Path(__file__).parents[1] / "custom_components" / "xzense_full_preview" / "settings.py"
spec = importlib.util.spec_from_file_location("xzense_settings_test", PATH)
settings = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = settings
spec.loader.exec_module(settings)


def test_live_snapshot_scaling():
    assert settings.raw_to_native("auto_start_temperature", 502) == 50.2
    assert settings.raw_to_native("auto_stop_temperature", 398) == 39.8
    assert settings.raw_to_native("boost_time", 900) == 15.0
    assert settings.raw_to_native("afterrun_time", 1800) == 30.0
    assert settings.raw_to_native("boost_fan_speed", 100) == 100.0
    assert settings.raw_to_native("boost_stop_temperature", 600) == 60.0
    assert settings.raw_to_native("wanted_draft", 26) == 26.0
    assert settings.raw_to_native("minimum_fan_voltage", 105) == 105.0
    assert settings.raw_to_native("volume_raw", 24) == 24.0
    assert settings.raw_to_native("contrast_raw", 75) == 75.0
    assert settings.raw_to_native("brightness_raw", 68) == 68.0


def test_native_values_encode_back_to_wire_values():
    assert settings.native_to_raw("auto_start_temperature", 50.2) == 502
    assert settings.native_to_raw("auto_stop_temperature", 39.8) == 398
    assert settings.native_to_raw("boost_time", 15) == 900
    assert settings.native_to_raw("afterrun_time", 30) == 1800
    assert settings.native_to_raw("boost_stop_temperature", 60.0) == 600
    assert settings.native_to_raw("wanted_draft", 26) == 26
    assert settings.native_to_raw("minimum_fan_voltage", 105) == 105


def test_manual_backed_ui_ranges():
    expected = {
        "volume_raw": (0, 100),
        "contrast_raw": (0, 100),
        "brightness_raw": (0, 100),
        "auto_start_temperature": (5, 100),
        "auto_stop_temperature": (0, 95),
        "boost_time": (1, 15),
        "afterrun_time": (1, 200),
        "boost_fan_speed": (40, 100),
        "wanted_draft": (8, 60),
        "minimum_fan_voltage": (80, 120),
    }
    for key, bounds in expected.items():
        rule = settings.SETTING_RULES[key]
        assert (rule.minimum, rule.maximum) == bounds


def test_boost_stop_uses_tenths_scaling_even_though_manual_range_is_unspecified():
    rule = settings.SETTING_RULES["boost_stop_temperature"]
    assert rule.scale == "tenths"
    assert settings.raw_to_native("boost_stop_temperature", 600) == 60.0
