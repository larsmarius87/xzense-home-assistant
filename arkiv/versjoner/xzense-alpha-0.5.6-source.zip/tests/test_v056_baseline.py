"""Release-baseline regressions for Xzense Alpha 0.5.6."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).parents[1]
COMPONENT = ROOT / "custom_components" / "xzense_full_preview"


def _function_sha256(path: Path, function_name: str) -> str:
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.col_offset == 4
            and node.name == function_name
        ):
            segment = "\n".join(source.splitlines()[node.lineno - 1 : node.end_lineno]) + "\n"
            return hashlib.sha256(segment.encode()).hexdigest()
    raise AssertionError(f"Function {function_name} not found")


def test_manifest_keeps_domain_and_alpha_identity():
    manifest = json.loads((COMPONENT / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["domain"] == "xzense_full_preview"
    assert manifest["name"] == "Xzense Alpha"
    assert manifest["version"] == "0.5.6"


def test_connection_and_ble_release_methods_are_unchanged_from_v055():
    # These exact method hashes are from the tested 0.5.5 package. 0.5.6 adds
    # application-level actions only; it must not rewrite BLE/reconnect/session
    # acquisition behavior while adding those controls.
    expected = {
        "async_start": "e3bf85bb512f3f132139ec7c731b3017e5f28fb2502d61b71ee0ac6e91067c82",
        "async_stop": "da539eb8cb399a2fbc5e4365d2a84126f10bf3d1f3040573bb8ea28585fbbf4a",
        "async_release_ble": "e43505b7ea835abdd0da8cba656c61747f2fa9b4e18b8a2ff80a9bda7121c9aa",
        "_wait_for_ble_release_window": "ef56dda4c72c0aeff73818115b5200ba068e0d5ecf12314ec9afb55f5cf53f3f",
        "_connection_loop": "b14001d451ba1708c2664949b735dadcb1db1e424b8ee47620d64417d3541c88",
        "_record_advertisement": "b391814a7e6323d1d9872eb1145568fbb38ac9502f5334d50b8f9388019980e1",
        "_publish_candidates": "efccbab684c9e1071fa5be21e494529ed820cc83ad79e0a5add917bfeb06c4ae",
        "_collect_fresh_advertisements": "a086cf762fc4b713eac9973cc96e3a9665fe9fb13d7682027508a0901b2a3a2b",
        "_establish_source_connection": "d3c4e86c65f7224a764fb9cccfadd27f0426cd2e0beae77192337166465f5d8f",
        "_write_application_frame": "a3c7809ae3e7525fc951a8f94f72f4fb98f9785a43540687be1ea4958f2a89c6",
        "_send_application_connect": "61564afc96b5e88361324f0cf83261725da2683629f3a6895ade0d4ac9976169",
        "_send_status_request": "55098cf97b7e55dbfcaec5189287f780aef0311dfbd216a9abcaff7f0a38f2e6",
        "_status_loop": "3fe81070456d7c36fc44ccba61d378319b514640e1031e4125c6c0c493279baf",
        "_connect_once": "ec5a11c75a7cbf8de7a5cd8ae57dfff577a8611b966fa69924f7340645cffa4c",
        "_is_authorization_error": "94586c948c8e13745d9faf1a55961b4d7b9170ebe31d255bd838dc38e8239729",
        "_disconnected": "0bc876ddc5671b2b7d77884d1b8b0e9cdcf67d3e84d9b6cc6cd1f5cd41210878",
    }
    client_path = COMPONENT / "client.py"
    assert {name: _function_sha256(client_path, name) for name in expected} == expected


def test_firmware_version_formatter_remains_unchanged():
    assert hashlib.sha256((COMPONENT / "version.py").read_bytes()).hexdigest() == (
        "7ea97a270dc9df892fcaf629da8e4597c28018c58b77c5ada36e292bc70ec2bb"
    )
