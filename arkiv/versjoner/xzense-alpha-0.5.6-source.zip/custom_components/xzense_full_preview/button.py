"""Buttons for app-visible Xzense actions."""

from __future__ import annotations

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient
from .const import DOMAIN
from .entity import XzenseEntity, XzenseFeatureEntity
from .features import FEATURES, FeatureSpec

BUTTON_FEATURES = tuple(f for f in FEATURES if f.kind == "button")


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    entities: list[ButtonEntity] = [XzenseButton(client, feature) for feature in BUTTON_FEATURES]
    entities.append(XzenseReleaseBleButton(client))
    async_add_entities(entities)


class XzenseButton(XzenseFeatureEntity, ButtonEntity):
    """An Xzense action button."""

    def __init__(self, client: XzenseClient, feature: FeatureSpec) -> None:
        super().__init__(client, feature)

    @property
    def available(self) -> bool:
        state = self.client.current_device_state()
        if self.feature.key in {"boost_on", "boost_off"}:
            return self.client.boost_available()
        if self.feature.key == "start_fire":
            return self.client.boost_available() and state == 2
        if self.feature.key == "refuel":
            return self.client.boost_available() and state == 4
        if self.feature.key == "stop_fire":
            if state in {3, 5}:
                return self.client.boost_available()
            return super().available and state == 4
        if self.feature.key == "start_afterrun":
            return super().available and state == 4
        return super().available

    async def async_press(self) -> None:
        if self.feature.key in {"boost_on", "start_fire", "refuel"}:
            await self.client.async_set_boost(True)
            return
        if self.feature.key == "boost_off":
            await self.client.async_set_boost(False)
            return
        if self.feature.key == "stop_fire":
            state = self.client.current_device_state()
            if state in {3, 5}:
                await self.client.async_set_boost(False)
                return
            if state == 4:
                await self.client.async_execute_feature("start_afterrun", 6)
                return
            raise HomeAssistantError("Stop firing is not valid in the current Xzense state")
        if self.feature.key == "start_afterrun":
            await self.client.async_execute_feature(self.feature.key, 6)
            return
        await self.client.async_execute_feature(self.feature.key)


class XzenseReleaseBleButton(XzenseEntity, ButtonEntity):
    """Temporarily release BLE so the official Xzense app can connect."""

    _attr_name = "Release Bluetooth to app"
    _attr_icon = "mdi:bluetooth-off"

    def __init__(self, client: XzenseClient) -> None:
        super().__init__(client)
        self._attr_unique_id = f"{client.address}_release_ble_to_app"

    @property
    def extra_state_attributes(self) -> dict[str, object]:
        return {
            "duration_seconds": self.client.state.ble_release_seconds,
            "active": self.client.state.ble_release_active,
            "release_until": self.client.state.ble_release_until,
        }

    async def async_press(self) -> None:
        await self.client.async_release_ble()
