"""Switches for app-visible Xzense controls."""

from __future__ import annotations

from homeassistant.components.switch import SwitchEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient
from .const import DOMAIN
from .entity import XzenseFeatureEntity
from .features import FEATURES, FeatureSpec

SWITCH_FEATURES = tuple(f for f in FEATURES if f.kind == "switch")


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(XzenseSwitch(client, feature) for feature in SWITCH_FEATURES)


class XzenseSwitch(XzenseFeatureEntity, SwitchEntity):
    """A scaffolded Xzense switch."""

    def __init__(self, client: XzenseClient, feature: FeatureSpec) -> None:
        super().__init__(client, feature)

    @property
    def available(self) -> bool:
        if self.feature.key == "ventilation":
            return self.client.ventilation_available()
        return super().available

    @property
    def is_on(self) -> bool | None:
        if self.feature.key == "ventilation":
            return self.client.state.ventilation_is_on
        if self.feature.global_id is not None:
            value = self.client.state.globals.get(self.feature.global_id)
            return None if value is None else bool(value)
        return None

    async def async_turn_on(self, **kwargs) -> None:
        if self.feature.key == "ventilation":
            await self.client.async_set_ventilation(True)
            return
        await self.client.async_execute_feature(self.feature.key, True)

    async def async_turn_off(self, **kwargs) -> None:
        if self.feature.key == "ventilation":
            await self.client.async_set_ventilation(False)
            return
        await self.client.async_execute_feature(self.feature.key, False)
