"""Feature registry for Xzense Alpha.

The registry separates verified live mappings from candidates.  Only features
marked ``write_ready`` may issue Xzense control writes.  Legacy feature keys are
kept where practical so existing Home Assistant entity unique IDs do not churn
while the underlying protocol map is corrected.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

FeatureState = Literal["verified_read", "write_ready", "id_known", "mapping_pending"]


@dataclass(frozen=True, slots=True)
class FeatureSpec:
    key: str
    name: str
    kind: Literal[
        "sensor",
        "binary_sensor",
        "button",
        "switch",
        "number",
        "select",
        "update",
        "virtual",
    ]
    state: FeatureState
    global_id: int | None = None
    packet_type: int | None = None
    notes: str = ""


FEATURES: tuple[FeatureSpec, ...] = (
    # Live/status reads.
    FeatureSpec(
        "chimney_temperature",
        "Chimney temperature",
        "sensor",
        "verified_read",
        global_id=0x1E,
        notes="Live calibrated: signed tenths of °C.",
    ),
    FeatureSpec(
        "inside_temperature",
        "Inside temperature",
        "sensor",
        "id_known",
        global_id=0x1C,
        notes="Strong live mapping: signed tenths of °C.",
    ),
    FeatureSpec(
        "outside_temperature",
        "Outside temperature",
        "sensor",
        "id_known",
        global_id=0x1D,
        notes="Strong live mapping: signed tenths of °C.",
    ),
    FeatureSpec(
        "fan_speed",
        "Fan speed",
        "sensor",
        "verified_read",
        global_id=0x1F,
        notes="Live A/B verified at 10% and 100%.",
    ),
    FeatureSpec(
        "pressure",
        "Air pressure",
        "sensor",
        "verified_read",
        global_id=0x1B,
        notes="User-confirmed live value: raw 1011 = 1011 hPa.",
    ),
    FeatureSpec(
        "actual_draft",
        "Chimney draught (mapping pending)",
        "sensor",
        "mapping_pending",
        notes="GLOBAL 0x51 is no longer presented as actual draught without further verification.",
    ),
    FeatureSpec(
        "state_timer",
        "Time in current state",
        "sensor",
        "verified_read",
        global_id=0x1A,
        notes="Seconds; observed to increment approximately once per second.",
    ),
    FeatureSpec("signal_strength", "Signal strength", "sensor", "id_known", global_id=0x18),
    FeatureSpec(
        "battery",
        "Power source",
        "sensor",
        "verified_read",
        global_id=0x05,
        notes="Live A/B verified: 2=Battery, 3=External power connected.",
    ),
    FeatureSpec(
        "device_state",
        "Device state",
        "sensor",
        "verified_read",
        global_id=0x19,
        notes=(
            "Operating sequence uses 2=Ready for lighting, 3=Boosting, "
            "4=Operation, 5=Refueling, 6=Afterrun."
        ),
    ),

    # Interface settings.  Legacy keys are retained to preserve entity unique IDs.
    FeatureSpec(
        "volume_raw",
        "Sound",
        "number",
        "write_ready",
        global_id=0x32,
        notes="Live A/B correlation: changing panel Sound 12→24 changed GLOBAL 0x32 12→24.",
    ),
    FeatureSpec(
        "contrast_raw",
        "Contrast",
        "number",
        "write_ready",
        global_id=0x33,
        notes="Live panel correlation: Contrast 75 -> GLOBAL 0x33 value 75.",
    ),
    FeatureSpec(
        "brightness_raw",
        "Brightness",
        "number",
        "write_ready",
        global_id=0x34,
        notes="Live panel correlation: Brightness 68 -> GLOBAL 0x34 value 68.",
    ),
    FeatureSpec(
        "language_raw",
        "Language (mapping pending)",
        "number",
        "mapping_pending",
        notes="Previous GLOBAL 0x4B language mapping was disproved; 0x4B is Start temperature.",
    ),

    # App-visible operating controls.
    FeatureSpec(
        "start_fire",
        "Start lighting",
        "button",
        "write_ready",
        packet_type=0x08,
        notes="Firmware-derived: in Ready for lighting, BOOST/REQ start=1 begins lighting/Boosting.",
    ),
    FeatureSpec(
        "stop_fire",
        "Stop firing",
        "button",
        "write_ready",
        notes=(
            "Context-aware firmware-derived action: BOOST/REQ start=0 in Boosting/Refueling; "
            "Operation transitions to Afterrun via GLOBAL 0x19=6."
        ),
    ),
    FeatureSpec(
        "refuel",
        "Refuel",
        "button",
        "write_ready",
        packet_type=0x08,
        notes="Firmware-derived: in Operation, BOOST/REQ start=1 starts Refueling/Reheating.",
    ),
    FeatureSpec(
        "start_afterrun",
        "Finish firing",
        "button",
        "write_ready",
        global_id=0x19,
        notes="Firmware-derived finish-firing path writes device state 6 (Afterrun).",
    ),
    FeatureSpec(
        "boost_on",
        "Boost on",
        "button",
        "write_ready",
        packet_type=0x08,
        notes="Packet 0x08 BOOST/REQ; start flag=1. Live verified.",
    ),
    FeatureSpec(
        "boost_off",
        "Boost off",
        "button",
        "write_ready",
        packet_type=0x08,
        notes="Packet 0x08 BOOST/REQ; start flag=0. Live verified.",
    ),
    FeatureSpec(
        "ventilation",
        "Ventilation",
        "switch",
        "write_ready",
        packet_type=0x09,
        notes="Firmware-derived VENTILATION/REQ with one-byte start/stop flag; first live write still pending.",
    ),
    FeatureSpec(
        "user_fan_speed",
        "Manual fan speed (mapping pending)",
        "number",
        "mapping_pending",
        notes="Legacy entity key retained; no verified GLOBAL mapping is assigned.",
    ),
    FeatureSpec(
        "boost_fan_speed",
        "Boost speed",
        "number",
        "write_ready",
        global_id=0x4F,
        notes="Live panel correlation: Boost speed 100% -> GLOBAL 0x4F value 100.",
    ),
    FeatureSpec(
        "system_control",
        "System control",
        "select",
        "write_ready",
        global_id=0x56,
        notes="Firmware-derived enum: 0=Manual, 1=eXotelligence, 2=Pressure controlled.",
    ),

    # Setup/service settings directly correlated against the controller.
    FeatureSpec(
        "auto_start_temperature",
        "Start temperature",
        "number",
        "write_ready",
        global_id=0x4B,
        notes="Tenths of °C on wire; 50.2 °C -> raw 502.",
    ),
    FeatureSpec(
        "auto_stop_temperature",
        "Stop temperature",
        "number",
        "write_ready",
        global_id=0x4C,
        notes="Tenths of °C on wire; 39.8 °C -> raw 398.",
    ),
    FeatureSpec(
        "boost_time",
        "Boost time",
        "number",
        "write_ready",
        global_id=0x4D,
        notes="Seconds on wire; 15 min -> raw 900.",
    ),
    FeatureSpec(
        "afterrun_time",
        "Afterrun time",
        "number",
        "write_ready",
        global_id=0x4E,
        notes="Seconds on wire; 30 min -> raw 1800.",
    ),
    FeatureSpec(
        "boost_stop_temperature",
        "Boost stop temperature",
        "number",
        "write_ready",
        global_id=0x52,
        notes="Tenths of °C on wire; 60.0 °C -> raw 600.",
    ),
    FeatureSpec(
        "wanted_draft",
        "Chimney draught setpoint",
        "number",
        "write_ready",
        global_id=0x53,
        notes="Direct Pa value; 26 Pa -> raw 26. Legacy key retained for entity stability.",
    ),
    FeatureSpec(
        "minimum_fan_voltage",
        "Minimum fan voltage",
        "number",
        "write_ready",
        global_id=0x54,
        notes="Direct volts; live value 105 V -> raw 105.",
    ),

    # Remaining candidates are intentionally read-only / unavailable as controls.
    FeatureSpec(
        "temperature_sensor",
        "Temperature sensor (candidate)",
        "select",
        "id_known",
        global_id=0x57,
        notes="Candidate mapping only; value coding not verified for writes.",
    ),
    FeatureSpec(
        "external_start",
        "External start (candidate)",
        "switch",
        "id_known",
        global_id=0x58,
        notes="Candidate mapping only; raw value observed is not treated as a verified boolean.",
    ),
    FeatureSpec(
        "alarm_setpoint",
        "Alarm setpoint (candidate raw)",
        "number",
        "id_known",
        global_id=0x59,
        notes="Candidate only; not writable until mapping/scaling is verified.",
    ),
    FeatureSpec(
        "refire_time",
        "Refire time (candidate raw)",
        "number",
        "id_known",
        global_id=0x5A,
        notes="Candidate only; not writable until mapping/scaling is verified.",
    ),
    FeatureSpec(
        "external_fan_speed",
        "External fan speed (candidate raw)",
        "number",
        "id_known",
        global_id=0x5B,
        notes="Candidate only; not writable until mapping/scaling is verified.",
    ),

    # App-visible information/features without a verified packet/global mapping yet.
    FeatureSpec("burn_count", "Burn count", "sensor", "mapping_pending"),
    FeatureSpec("operation_time", "Operation time", "sensor", "mapping_pending"),
    FeatureSpec("error_log", "Error log", "sensor", "mapping_pending"),
    FeatureSpec(
        "firmware_version",
        "Firmware version",
        "sensor",
        "verified_read",
        notes="CONNECT ACK version; observed raw 410 is rendered as firmware 4.10.",
    ),
    FeatureSpec("download_log", "Download log", "button", "mapping_pending"),
    FeatureSpec(
        "history",
        "History",
        "virtual",
        "mapping_pending",
        notes="Use HA history/statistics from live entities while native history remains unmapped.",
    ),
)

FEATURE_BY_KEY = {feature.key: feature for feature in FEATURES}
