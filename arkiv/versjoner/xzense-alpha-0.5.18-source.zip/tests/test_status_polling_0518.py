"""Static regressions for experimental 0.5.18 polling mode."""
import ast
import json
from pathlib import Path

ROOT = Path(__file__).parents[1] / "custom_components" / "xzense_full_preview"

def test_modified_python_files_parse():
    for name in ("client.py", "sensor.py", "const.py", "config_flow.py", "diagnostics.py"):
        ast.parse((ROOT / name).read_text())

def test_off_default_and_initial_status():
    client = (ROOT / "client.py").read_text()
    assert 'entry.options.get(CONF_STATUS_POLL_INTERVAL, "off")' in client
    assert "await self._send_status_request(client, session_id)" in client
    assert "if self.status_poll_interval == 0:" in client
    assert "await asyncio.sleep(2.0)" in client
    assert "await asyncio.sleep(self.status_poll_interval)" in client

def test_ui_and_freshness():
    flow = (ROOT / "config_flow.py").read_text()
    assert "OptionsFlowWithReload" in flow
    assert "async_get_options_flow" in flow
    assert json.loads((ROOT / "manifest.json").read_text())["version"] == "0.5.18"
    sensor = (ROOT / "sensor.py").read_text()
    assert '"sample_stale"' in sensor
    assert '"last_observed_at"' in sensor
