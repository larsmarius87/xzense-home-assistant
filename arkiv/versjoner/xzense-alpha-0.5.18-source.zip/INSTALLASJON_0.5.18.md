# Xzense Alpha 0.5.18

Basert på hele Alpha 0.5.17; domenet er fortsatt `xzense_full_preview`.

**STATUS-polling er avslått som standard.** Ved hver bekreftede PIN/CONNECT-sesjon sender integrasjonen én STATUS/REQ. Den sender fortsatt ekstra STATUS etter Boost/Ventilation-kommandoer.

Under **Innstillinger → Enheter og tjenester → Xzense Alpha → Konfigurer** kan intervallet velges: Av, hvert 10. sekund, hvert 60. sekund eller hvert 5. minutt. En endring laster integrasjonen på nytt.

Passive `GLOBAL/DATA` behandles. Temperaturen, viften, trykket og driftstilstanden velger nyeste tilgjengelige prøve mellom STATUS og GLOBAL. Sensorattributtene `last_observed_at`, `sample_age_seconds` og `sample_stale` viser hvor gammel data er; stale blir sann etter 120 sekunder. HA oppdaterer lokalt hvert ca. minutt når polling er av. Tidstellere kan ikke beregnes presist etter lange hull uten datameldinger.

## Installasjon

1. Se hvilken integrasjonsmappe du faktisk bruker, og verifiser `manifest.json` før du kopierer.
2. Erstatt hele `/config/custom_components/xzense_full_preview/` med mappen fra ZIP-filen hvis dette er aktiv mappe.
3. Start Home Assistant på nytt.
4. Kontroller `version=0.5.18` og `status_poll_interval_seconds=0` i ny diagnostikk.
5. Når Bluetooth er aktivert på panelet: kontroller at én initial STATUS sendes, og følg `disconnect_history`.

**Advarsel:** Dette er en eksperimentell Alpha, ikke testet på fysisk Xzense. Ved behov kan polling settes tilbake til 10 sekunder. Ingen endringer i Bluetooth-oppsettet eller Xzenses skriveprotokoll er ment.