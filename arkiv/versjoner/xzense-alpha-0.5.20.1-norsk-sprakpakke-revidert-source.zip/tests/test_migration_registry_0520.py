"""0.5.20 registry behavior under a mocked Home Assistant entry lifecycle."""
from __future__ import annotations
import ast
import asyncio
from pathlib import Path
from types import SimpleNamespace

COMP = Path(__file__).resolve().parents[1]/'custom_components/xzense_full_preview'
SRC = (COMP/'__init__.py').read_text()
SENSORS = (COMP/'sensor.py').read_text()


def test_existing_diagnostics_are_disabled_not_removed_and_core_left_alone():
    # Extract actual setup_entry implementation from source; the rest of HA is
    # represented by a fake registry/platform loader.
    tree=ast.parse(SRC)
    fn=next(n for n in tree.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='async_setup_entry')
    removed=[]
    disabled=[]
    settings=SimpleNamespace(INTEGRATION='integration')
    by_uid=lambda suffix: 'AABB_'+suffix
    ents=[
        SimpleNamespace(domain='sensor', unique_id=by_uid('last_data_at'), entity_id='sensor.last_data_at',disabled_by=None),
        SimpleNamespace(domain='sensor', unique_id=by_uid('last_frame'), entity_id='sensor.last_frame',disabled_by=None),
        SimpleNamespace(domain='sensor', unique_id=by_uid('crc_errors'), entity_id='sensor.crc_errors',disabled_by=None),
        SimpleNamespace(domain='sensor', unique_id=by_uid('packet_count'), entity_id='sensor.packet_count',disabled_by='integration'),
        SimpleNamespace(domain='number', unique_id=by_uid('bluetooth_active_update_interval'),entity_id='number.active_interval',disabled_by=None),
    ]
    class Registry:
        def async_remove(self,entity_id):removed.append(entity_id)
        def async_update_entity(self,entity_id,**kw):disabled.append((entity_id,kw.get('disabled_by')))
    er=SimpleNamespace(async_get=lambda hass:Registry(),
                       async_entries_for_config_entry=lambda reg,entry_id:ents,
                       RegistryEntryDisabler=settings)
    async def register_paths(paths):pass
    class Client:
        def __init__(self,*args):self.state=SimpleNamespace();self._notify_listeners=lambda:None
        async def async_initialize_timing(self):pass
        async def async_initialize_cache(self):pass
        async def async_start(self):pass
    # Evaluate the actual 97 keys via source constants/regex. The registry test
    # uses two representative keys but keeps the real whitelist.
    ns={'XzenseClient':Client,'er':er,'DOMAIN':'xzense_full_preview','CONF_NAME':'name',
        'CONF_PIN':'pin','CONF_ADDRESS':'address','DEFAULT_NAME':'Xzense',
        'CORE_DIAGNOSTIC_KEYS':{'last_data_at','crc_errors'},
        'DIAGNOSTIC_SENSORS':[SimpleNamespace(key='last_data_at'),
                              SimpleNamespace(key='last_frame'),
                              SimpleNamespace(key='crc_errors'),
                              SimpleNamespace(key='packet_count')],
        'Path':Path,'__file__':str(COMP/'__init__.py'),'StaticPathConfig':lambda *args:args,'PLATFORMS':(),
        'ConfigEntryAuthFailed':RuntimeError}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'setup','exec'),ns)
    async def exercise():
        config=SimpleNamespace(data={'pin':'0000','address':'AABB'},entry_id='test',title='Xzense')
        hass=SimpleNamespace(data={},http=SimpleNamespace(async_register_static_paths=register_paths),
                             config_entries=SimpleNamespace(async_forward_entry_setups=lambda entry,platforms:asyncio.sleep(0)))
        result=await ns['async_setup_entry'](hass,config)
        assert result is True
    asyncio.run(exercise())
    assert removed==[]
    assert ('sensor.last_frame','integration') in disabled
    assert ('sensor.packet_count','integration') not in disabled # already off
    assert ('sensor.last_data_at','integration') not in disabled
    assert ('sensor.crc_errors','integration') not in disabled
    assert not any(entity=='number.active_interval' for entity,reason in disabled)


def test_rollback_05193_reenables_integration_disabled_entities():
    # Previous 0.5.19.3 installs re-enabled integration-disabled entities.
    # This branch is retained for core diagnostics and controls.
    assert 'elif entity_entry.disabled_by == er.RegistryEntryDisabler.INTEGRATION' in SRC
    assert 'disabled_by=None' in SRC
