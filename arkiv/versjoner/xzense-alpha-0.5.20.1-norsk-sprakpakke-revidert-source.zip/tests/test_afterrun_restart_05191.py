"""Alpha 0.5.19.1: Afterrun start control and continuous fire-cycle regression."""
from __future__ import annotations

import ast
import asyncio
import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / 'custom_components/xzense_full_preview'

spec = importlib.util.spec_from_file_location('xzense_restart_timing_05191', COMP / 'timing.py')
timing = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = timing
spec.loader.exec_module(timing)


def test_start_button_gate_in_ready_and_afterrun_and_no_other_states():
    tree = ast.parse((COMP / 'button.py').read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'XzenseButton')
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'available')
    ns = {}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])), '<button-available>', 'exec'), ns)
    class C:
        controls_available = True
        current_state = 2
        def current_device_state(self): return self.current_state
    c = C()
    proxy = SimpleNamespace(client=c, feature=SimpleNamespace(key='start_fire'))
    assert ns['available'].fget(proxy)
    c.current_state = 6
    assert ns['available'].fget(proxy)
    for state in [1,3,4,5,7,8,9,10]:
        c.current_state = state
        assert not ns['available'].fget(proxy), state
    c.current_state = 6
    c.controls_available = False
    assert not ns['available'].fget(proxy)


def test_dispatch_revalidates_afterrun_state_before_existing_boost_start():
    tree = ast.parse((COMP / 'client.py').read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'XzenseClient')
    fn = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'async_control_feature')
    import time
    ns = {'HomeAssistantError': RuntimeError, 'time': time}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])), '<client-start-fire>', 'exec'), ns)
    class Fake:
        state_id = 6
        sent = []
        def current_device_state(self): return self.state_id
        async def async_set_boost(self, enabled): self.sent.append(('boost', enabled))
        async def async_run_control(self, action): await action()
    async def run():
        x = Fake();x.sent=[]
        await ns['async_control_feature'](x, 'start_fire')
        assert x.sent == [('boost', True)]
        x.state_id=5
        try:
            await ns['async_control_feature'](x, 'start_fire')
        except RuntimeError as exc:
            assert 'not allowed' in str(exc)
        else: raise AssertionError('must reject invalid state')
        assert x.sent == [('boost', True)]
    asyncio.run(run())


def test_afterrun_resumes_same_fire_not_new_session():
    t = timing.XzenseTiming()
    t.observe(2, 100, 1000)
    t.observe(3, 2, 1010)     # started 1008
    t.observe(4, 10, 1040)
    t.observe(6, 2, 1080)
    t.observe(3, 3, 1090)     # restart from Afterrun
    assert t.last_fire_duration is None
    assert t.fire_started_epoch == 1008
    assert t.fire_duration == 82
    t.observe(4, 5, 1100)
    assert t.fire_duration == 92
    t.observe(2, 1, 1200)
    assert t.last_fire_duration == 192
    assert t.fire_started_epoch is None


def test_afterrun_can_resume_operation_or_refuel_without_reset():
    for next_state in (3, 4, 7):
        t = timing.XzenseTiming()
        t.observe(2, 10, 1000)
        t.observe(3, 1, 1010)
        t.observe(6, 1, 1020)
        t.observe(next_state, 1, 1030)
        assert t.last_fire_duration is None
        assert t.fire_started_epoch == 1009


def test_long_gap_afterrun_restart_is_same_fire():
    t = timing.XzenseTiming()
    t.observe(2, 10, 1000)
    t.observe(3, 0, 1010)
    t.observe(6, 10, 1040)
    t.observe(3, 500, 1600)
    assert t.last_fire_duration is None
    assert t.fire_started_epoch == 1010
    assert t.fire_duration == 590


def test_afterrun_resume_preserves_start_across_storage_restore():
    t = timing.XzenseTiming()
    t.observe(2, 10, 1000)
    t.observe(3, 0, 1010)
    t.observe(6, 2, 1040)
    t.observe(3, 1, 1050)
    saved = timing.XzenseTiming.restore(t.snapshot())
    saved.observe(4, 5, 1060)
    assert saved.last_fire_duration is None
    assert saved.fire_started_epoch == 1010
    assert saved.fire_duration == 50


def test_afterrun_control_keeps_transport_frame_builders_unchanged():
    import zipfile
    archive=Path('/mnt/data/xzense-alpha-0.5.19.1-afterrun-source.zip')
    with zipfile.ZipFile(archive) as z:
        assert z.read('custom_components/xzense_full_preview/protocol.py') == (COMP/'protocol.py').read_bytes()
    client = (COMP/'client.py').read_text()
    assert 'state not in ({2, 6} if feature_key == "start_fire" else {4, 5})' in client
    assert 'if self.interval_minutes > 0:' in client
