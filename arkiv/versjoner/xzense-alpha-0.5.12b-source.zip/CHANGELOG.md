## 0.5.12b Alpha — minor Refuel and raw-status label revision

- Refuel button available in state 4 **Operation** and state 5 **Burnout**. Sends the same BOOST/REQ start=1; state-4 controller behavior is not yet live-verified.
- Renamed display titles: `Power source (?)` -> `0x05 status` and `Signal strength` -> `0x18 status`.
- `0x05 status` now returns only the raw integer (not an assumed power-source enum or `Unknown (x)` text).
- Preserved existing Home Assistant unique IDs (`battery`, `signal_strength`) and all BLE communication/session logic.
- No changes to GLOBAL transport, STATUS polling, ChimneyLog research or other controls.

## 0.5.12 — alarm temperature configuration and ChimneyLog research

- Added writable Alarm temperature number (GLOBAL `0x58`, 150–400 °C in 0.1 °C steps, value/10), with on-device confirmation pending.
- System control selector moved into HA Configuration via entity category.
- Added non-writable diagnostic Refire / Reboost time (`0x59`) and Burnout time (`0x5B`); `/60` minutes **candidate** display, raw diagnostics retained. Unknown writing bounds prevent safe exposure as CONFIG number fields.
- Removed visible Actual chimney draught (raw) and redundant Burnout raw sensor; raw globals unchanged in diagnostic JSON.
- Documented firmware / Flutter ChimneyLog evidence (log filenames, fan/temperature/pressure debug format, `burnCount`, `operationTime`, BLE file transfer details). No FILE_TRANSFER writes were added.

## 0.5.10 Alpha — fan-speed setpoint enabled in Ventilation (2026-10-21)

- Verified from live Ventilation (state 8) diagnostics that GLOBAL `0x50` was raised 10→16 in 1% increments; STATUS reported 16% actual fan speed.
- Renamed the existing `user_fan_speed` HA number to **Fan speed** and allowed it in states 4 (Operation) and 8 (Ventilation); a write-time state recheck prevents writes outside these states.
- Renamed the separate `0x1F` read-only sensor to **Actual fan speed**. Both entity feature keys and unique IDs remain stable.
- Preserved 10–100% bounds, GLOBAL wire payload encoding, Bluetooth connection/authentication, Ventilation packet `0x09`, Boost and all other controls. Actual HA speed write while in Ventilation remains to be physically tested.

## 0.5.9 Alpha — defer external start/speed settings (2026-10-21)

- Removed `external_start` (GLOBAL `0x57`) and `external_fan_speed` (GLOBAL `0x5A`) from the active feature registry and feature matrix at user request.
- Kept 0.5.8's entity-registry cleanup for any old copies of those controls; they were already non-exposed in 0.5.8.
- Retained the raw GLOBAL values and labels in protocol diagnostics and the archival protocol manifest for future reverse engineering.
- Preserved the verified Power source sensor (GLOBAL `0x05`), the Ventilation switch (packet `0x09`), and all BLE/controller command behavior unchanged.
- Added regression tests enforcing the deliberate exclusion while retaining raw diagnostic data.

## 0.5.8 Alpha — housekeeping over 0.5.7 (2026-10-21)

- No changes to BLE connection, authentication, polling or confirmed write-frame logic.
- Removed unavailable/never-functional UI entities: Burn count, Operation time, Error log, Language, Download log and duplicate GLOBAL 0x51 raw.
- Candidate setting controls (0x56-0x5A) remain in feature registry and full diagnostics but are no longer created as permanently unavailable HA entities.
- Reclassified legacy debug labels for GLOBAL 0x00-0x04 to UNKNOWN. Removed unobserved 0xFF legacy Burnout alias. All raw numeric GLOBAL data remains intact.
- Dropped the unused shadow PLATFORMS constant with nonexistent update platform.
- Added precise entity-registry cleanup for the nonfunctional placeholders; preserved current working entity IDs and legacy compatibility domain.
- Kept protocol history in CHANGELOG and PROTOCOL_NOTES for reference instead of exposing unimplemented placeholders.

# Changelog

## 0.5.12 Alpha — configuration and ChimneyLog groundwork

- New CONFIG number entities: Alarm temperature (`0x58`, 150–400 °C), Refire/Reboost time (`0x59`, seconds shown as minutes), Burnout timeout (`0x5B`, seconds shown as minutes); panel editability of both timers reported by the user, but HA writes unverified.
- Two time-setting limits are signed 16-bit transport bounds (0–546.1 min, 0.1-min step), not controller-safe recommended ranges.
- Moved System control to Configuration; removed duplicate Actual chimney draught raw sensor while preserving raw protocol values.
- Replaced misleading `0x05=2` Battery / `0x05=3` External power assertions with `Unknown (raw)` until exact enum/power-detection behavior is verified on the hardwired installation.
- Documented ChimneyLog/ErrLog static firmware and app evidence; did not add experimental FILE_TRANSFER requests.


## 0.5.7 Alpha

- Built directly from the tested 0.5.6 source package; BLE discovery/reconnect/PIN/session/BLE-release methods remain hash-locked to the 0.5.5 implementation.
- Re-analysed the controller firmware bundled with official Xzense 5.0.5; the image identifies itself as **v4.10_RC2**.
- Corrected the v4.10 state map: `1=Setup`, `2=Ready/IDLE`, `3=Boosting`, `4=Operation`, `5=Burnout`, `6=Afterrun`, `7=Refueling/Reheating`, `8=Ventilation`, `9=Error`, `10=Upgrading`.
- Corrected **Refuel** gating: state 5 Burnout sends BOOST `0x08 start=1`; Reheating/Refueling is state 7.
- Corrected **Stop firing**: state 3/7 sends BOOST `start=0`; state 4/5 transitions to Afterrun with GLOBAL `0x19=6`.
- Corrected **System control** from the 0.5.6 provisional `0x56` mapping to v4.10 direct binding **GLOBAL `0x55`**. GLOBAL `0x56` is Temperature sensor and remains write-locked.
- Restored **Operation fan speed** as GLOBAL `0x50`, direct 10-100 %, based on direct v4.10 Fan Control UI code plus the earlier physical write probe. The HA number is available only in state 4 Operation.
- Shifted the remaining v4.10 service candidates: `0x57` External start, `0x58` Alarm setpoint, `0x59` Reboost/refire time, `0x5A` External fan speed, `0x5B` Burnout timeout; these remain read-only.
- Reclassified GLOBAL `0x51` as firmware-derived Actual draught but leave it raw/read-only until scaling is live-confirmed.
- Documented that the v4.10 image contains a stale legacy GLOBAL debug-name table; direct v4.10 UI bindings and live correlations take precedence.

## 0.5.6 Alpha

- Built directly from the tested 0.5.5 source package.
- Preserved the complete BLE discovery/reconnect/session-acquisition and **Release Bluetooth to app** method implementations byte-for-byte at method level; regression hashes enforce this.
- Promoted **Start lighting** to a state-gated control: state 2 uses BOOST `0x08`, `start=1`.
- Promoted **Refuel** to a state-gated control: state 4 uses the same BOOST `0x08`, `start=1`, matching the controller firmware's Reheating path.
- Added context-aware **Stop firing**: state 3/5 sends BOOST `start=0`; state 4 transitions to Afterrun with GLOBAL `0x19=6`.
- Added explicit **Finish firing** button for Operation -> Afterrun via GLOBAL `0x19=6`.
- Added **Ventilation** switch using firmware-derived packet `0x09` with a one-byte start/stop flag; ACK/NACK diagnostics and last ACK-confirmed switch state are recorded.
- Promoted **System control** GLOBAL `0x56` to a writable select with firmware-derived enum `0=Manual`, `1=eXotelligence`, `2=Pressure controlled`.
- Added protocol/regression tests for Ventilation payloads, System control enum and the 0.5.5 connection-code boundary.
- No writes were enabled for unidentified `0x35`, `0x36`, `0x50`, `0x51`, `0x55` or candidate `0x57`-`0x5B` fields.

## 0.5.5 Alpha

- Built from the preserved 0.5.3 Alpha source baseline; the discarded 0.5.4 regression build is not used.
- Preserved the 0.5.3 BLE connection strategy and **Release Bluetooth to app** helper unchanged.
- Added live-correlated `0x32=Sound`, `0x33=Contrast` and `0x34=Brightness`.
- Corrected the setup block: `0x4B` Start temperature, `0x4C` Stop temperature, `0x4D` Boost time, `0x4E` Afterrun time and `0x4F` Boost speed.
- Corrected `0x52` Boost stop temperature, `0x53` chimney draught setpoint and `0x54` minimum fan voltage.
- Added native HA scaling: tenths °C -> °C and wire seconds -> minutes.
- Added manual-backed UI ranges for the settings whose ranges are published by Exodraft.
- Added verified power-source decoding: `0x05=2` Battery and `0x05=3` External power.
- Preserved firmware formatting from 0.5.3: CONNECT ACK `410` is shown as `4.10`.
- Removed all write access from unidentified `0x35`, `0x36`, `0x50`, `0x51`, `0x55` and from unverified `0x58`-`0x5B` candidates.
- Added disabled raw diagnostic sensors for `0x35`, `0x36`, `0x50`, `0x51` and `0x55`.

## 0.5.3 Alpha

- Added **Release Bluetooth to app** button. It disconnects Home Assistant from the Xzense control panel without sending any Xzense control command.
- Added local **Bluetooth app release time** number entity, adjustable from 1 to 600 seconds (default 60 seconds) for test use.
- While released, the integration suppresses its reconnect loop; when the timer expires it automatically resumes the existing fresh-advertisement connection strategy.
- Added BLE release state/counters to diagnostics.

## 0.5.2 — Xzense Alpha

- Renamed the user-facing integration from **Xzense Full Preview** to **Xzense Alpha** while retaining the `xzense_full_preview` domain for compatibility.
- Corrected GLOBAL `0x50` to **Fan speed setpoint** after a successful physical write test; values are direct percent.
- Rejected the previous `0x52` manual/user fan-speed mapping and returned it to unknown/read-only status.
- Corrected GLOBAL `0x54` to **Minimum fan voltage** after live observations at 80 V and 105 V.
- Returned `0x55` to unknown/read-only status.
- Bounded the verified fan-speed setpoint to 10-100 % and minimum fan-voltage test control to the documented 80-120 V service range.
- Updated protocol labels, feature matrix and tests to match the current live evidence.

## 0.5.1
- Corrected the interface-setting test mappings from a live panel cross-check.
- GLOBAL `0x34` is now treated as **Contrast** with a 0-100 % Home Assistant number control; panel contrast around 70 matched raw `68`.
- GLOBAL `0x33` is no longer labelled Volume and is no longer writable; panel sound was `0` while raw `0x33` was `75`, disproving the previous direct-volume mapping.
- Other experimental numeric GLOBAL controls remain raw signed-int16 until individually calibrated.
- No change to verified BOOST on/off behavior.

## 0.5.0 — experimental raw-write branch
- Branched from 0.4.7; 0.4.7 remains the stable test package.
- Enabled direct signed-int16 GLOBAL writes for selected recovered numeric setting IDs.
- Added raw write entities for Volume `0x33`, Contrast `0x34`, Brightness `0x35`, and Language `0x4B`.
- Opened existing numeric setting globals `0x4C-0x50`, `0x52-0x55`, and `0x59-0x5B` for raw writes.
- Removed guessed percentage scaling from experimental number entities; displayed values are the exact raw wire values.
- Added GLOBAL write request diagnostics (request count, ID, raw value, request/response timestamps).
- Kept System control `0x56`, Temperature sensor `0x57`, External start `0x58`, Ventilation `0x09`, BLE enable `0x36`, runtime/status values and Actual draft `0x51` write-locked.
- Boost On/Off remains separately live-verified.

## 0.4.7
- Firmware version is now read from `connect_ack_version`; observed raw `410` is exposed as `4.10`.
- Renamed device state `2` from `Standby` to `Ready for lighting` based on the Xzense operating sequence.
- Added manual-supported state labels `4 = Operation` and `5 = Refueling`; live verification is still pending for these two states.
- Removed the obsolete `Weather station` binary-sensor placeholder. The manual's Weather page is a presentation of outside temperature, chimney temperature and air pressure, which are already exposed separately.
- Removed the obsolete firmware-update scaffold; the integration now exposes the known firmware value as a read-only sensor.
- Added registry cleanup for stale `Chimney state`, `Weather station` and old `Firmware` placeholder entities from earlier preview builds.
- Kept `0x51 Actual draft` unchanged; raw zero is not hard-coded as “XTP not connected”.
- No new write commands were enabled. Boost On/Off remain the only write-ready controls.
- Retains the Xzense icon assets added in 0.4.6.

## 0.4.6
- Added bundled Xzense icon assets (`icon.png`, `logo.png`, and integration-local `custom_components/xzense_full_preview/icon.png`).
- No functional protocol or control changes from 0.4.5.

## 0.4.5
- Removed the global write lock by setting `CONTROL_WRITES_ENABLED = True`.
- Write access is still limited to features explicitly marked `write_ready`; unknown mappings remain unavailable.
- Added the first state-2 label (`Standby` at the time; corrected to `Ready for lighting` in 0.4.7).
- Kept Boost packet handling enabled.

## 0.4.4

- Removed the v0.4.3 experimental volume/fan write probes and their Afterrun gates.
- Added dedicated **Boost on** and **Boost off** buttons.
- Statically verified controller packet type `0x08` as `BOOST` from the bundled firmware.
- BOOST request uses active session ID + start/stop byte + current raw inside temperature.
- Added BOOST ACK/NACK/request diagnostics and immediate STATUS refresh after a command.
- All non-Boost control writes remain disabled.

## 0.4.3

- Confirms device state `6` as **Afterrun** from a synchronized live capture.
- Reclassifies GLOBAL/STATUS `0x1A` as **time in current state**; the value reset at the state transition and advanced about once per second.
- Confirms GLOBAL/STATUS `0x1B` as **air pressure in hPa**; user confirmed raw `1011` = **1011 hPa**.
- Corrects the 14-byte STATUS layout accordingly.
- Keeps state `3` = **Boosting**, `0x1E` = chimney temperature `/10`, and `0x1F` = actual fan speed `%`.
- Keeps all normal control writes disabled.
- Adds two explicit experimental write-probe buttons:
  - volume no-op: writes the existing `0x33` value back unchanged;
  - fan candidate probe: only in Afterrun below 60 °C with actual fan <=20 %, temporarily changes GLOBAL `0x50` by +10 (max 30), samples STATUS for about five seconds, then restores the original value.
- Records GLOBAL ACK/NACK and probe results in diagnostics.

## 0.4.2

- Calibrated chimney temperature and actual fan speed from synchronized live values.
- Corrected temperature scaling and left GLOBAL `0x20` unidentified.

## Alpha 0.5.11 update (2026-10-21)

- Removed non-functional Bluetooth release-to-app button, timer and associated BLE pause logic.
- Combined Boost on/off into one Boost switch; removed redundant Finish firing button. Stop firing retains its Afterrun transition through GLOBAL 0x19=6.
- Boost and Ventilation switches follow authenticated STATUS state (Boost state 3; Ventilation state 8). Boost state 7 is unresolved and retains last known value.
- Switch state is restored across HA restarts and retained across BLE reconnects until the first valid fresh STATUS frame. CONNECT/ACK immediately triggers the existing STATUS polling loop; command ACK alone does not determine switch state.
- Fan speed GLOBAL 0x50 is available in all connected states; firmware may still enforce its own restrictions.
- Controls are normal entities, configuration settings categorized CONFIG; device-page display ordering remains Home Assistant controlled.
- GitHub release source zip built from this tree; local tests do not substitute for on-device validation.
