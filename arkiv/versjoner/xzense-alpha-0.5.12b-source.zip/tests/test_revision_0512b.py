"""Alpha 0.5.12b: conservative raw status and Refuel in Operating."""
from pathlib import Path
import ast
import json

ROOT = Path(__file__).resolve().parents[1]
COMPONENT = ROOT / "custom_components/xzense_full_preview"


def test_manifest_version_and_stable_domain():
    m = json.loads((COMPONENT / "manifest.json").read_text())
    assert m["version"] == "0.5.12b"
    assert m["domain"] == "xzense_full_preview"


def test_refuel_available_states_and_unmodified_command():
    source = (COMPONENT / "button.py").read_text()
    assert 'return self.client.boost_available() and state in {4, 5}' in source
    assert 'if self.feature.key in {"start_fire", "refuel"}:' in source
    assert 'await self.client.async_set_boost(True)' in source
    assert 'state in {3, 7}' in source  # Stop firing behavior preserved


def test_status_titles_preserve_sensor_entity_ids_and_raw_values():
    s = (COMPONENT / "sensor.py").read_text()
    assert 'SensorDescription("battery", "0x05 status", _status_0x05' in s
    assert 'SensorDescription("signal_strength", "0x18 status", lambda s: s.globals.get(0x18)' in s
    assert 'return state.globals.get(0x05)' in s
    assert 'Unknown ({raw})' not in s
    assert 'f"{client.address}_{description.key}"' in s


def test_features_registry_titles_match_sensors():
    f = (COMPONENT / "features.py").read_text()
    assert 'FeatureSpec("signal_strength", "0x18 status"' in f
    assert '"battery",\n        "0x05 status",' in f
    assert 'global_id=0x05' in f
    assert 'global_id=0x18' in f
