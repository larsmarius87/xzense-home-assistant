"""Alpha 0.5.18 dependency-free source regressions."""
import ast
import json
from pathlib import Path
ROOT = Path(__file__).parents[1] / "custom_components" / "xzense_full_preview"
def test_syntax():
    for name in ("client.py", "sensor.py", "const.py", "config_flow.py", "diagnostics.py"):
        ast.parse((ROOT / name).read_text(), filename=name)
def test_default_and_options():
    src = (ROOT / "client.py").read_text()
    assert 'entry.options.get(CONF_STATUS_POLL_INTERVAL, "off")' in src
    assert "if self.status_poll_interval == 0:" in src
    assert "await asyncio.sleep(2.0)" in src
    assert "await self._send_status_request(client, session_id)" in src
    assert "await asyncio.sleep(self.status_poll_interval)" in src
    assert "OptionsFlowWithReload" in (ROOT / "config_flow.py").read_text()
    assert json.loads((ROOT / "manifest.json").read_text())["version"] == "0.5.18"
def test_diagnostics_and_write_actions():
    src = (ROOT / "client.py").read_text()
    assert "STATUS/REQ after BOOST" in src
    assert "STATUS/REQ after VENTILATION" in src
    assert '"sample_stale"' in (ROOT / "sensor.py").read_text()
    assert '"status_polling_mode"' in (ROOT / "diagnostics.py").read_text()
