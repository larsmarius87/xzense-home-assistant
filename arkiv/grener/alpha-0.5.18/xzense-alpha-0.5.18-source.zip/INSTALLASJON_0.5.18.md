# Xzense Alpha 0.5.18

Denne Alpha bygger på hele 0.5.17-pakken, og beholder BLE-tilkobling, proxyvalg, PIN og eksisterende skrivekommandoer.

## Endring

- STATUS/REQ én gang ved autentisert oppkobling. Periodisk polling av som standard.
- Konfigurer under **Innstillinger → Enheter og tjenester → Xzense Alpha → Konfigurer**: Av, 10 sek, 60 sek eller 5 minutter.
- STATUS/REQ etter Boost og Ventilation beholdt.
- GLOBAL/DATA mottas passivt og brukes når den er ferskere enn siste STATUS.
- Sensorattributter: last_observed_at, sample_age_seconds, sample_stale (etter 120 sekunder). En lokal oppdatering hvert minutt sender ingen BLE-pakker.
- Time in current state / Fire duration avhenger av mottatte hendelser og oppdateres ikke sekundvis når polling er av.
- Test mot fysisk Xzense gjenstår.

## Installasjon

1. Kontroller at bare én integrasjon bruker Xzense BLE-adressen.
2. Verifiser at aktiv mappe har manifest-domene `xzense_full_preview`.
3. Erstatt hele `custom_components/xzense_full_preview` med mappen fra ZIP-en.
4. Start Home Assistant på nytt og sjekk versjon 0.5.18.
5. Kontroller `status_poll_interval_seconds=0` i diagnostikken. Ved behov kan 10-sekunders polling aktiveres via Konfigurer.

**OBS:** Bluetooth er fortsatt aktivt når polling er av; dette er en test av forespørselsfrekvens, ikke en passiv tilkoblingsmodus.
