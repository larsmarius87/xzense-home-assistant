# Xzense for Home Assistant — alpha 0.2.1

## v0.2.2-alpha.1

- Restores normal BLE connection behavior from v0.2.0.
- Does **not** force pairing before connecting.
- If `start_notify()` returns GATT status 8 / `Insufficient authorization`, the integration attempts Bluetooth pairing at that point and retries notifications.
- Adds diagnostics for pairing attempts, pairing success and authorization retries.
- Xzense application-PIN authentication and control writes are still disabled.


Experimental local Bluetooth integration for Exodraft Xzense, based on static analysis of the supplied Xzense 5.0.2 Android app.

## New in 0.2.1-alpha.1

- BLE connection establishment now requests **pairing/bonding** (`pair=True`) before enabling Xzense notifications.
- This specifically targets the observed `BluetoothGATTErrorResponse: Insufficient authorization (8)` error from `start_notify()`.
- Failed notification setup now disconnects/cleans up the temporary BLE client before retrying, reducing stale connections.
- Diagnostics now include Bluetooth connection-attempt and disconnect counters.
- The four-character Xzense application PIN configuration from 0.2.0 is retained unchanged.

## Important protocol status

The PIN is collected and available to the BLE client, but **the application-level PIN authentication packet is not transmitted yet**. BLE pairing/bonding is separate from the Xzense application PIN. Control writes also remain disabled. The APK proves that Xzense has PIN authentication, sequence numbers, ACK/NACK handling and CRC checking; the exact PIN frame and session semantics still need to be confirmed before the integration should write to a chimney-fan controller.

This build therefore remains a protocol-monitor/test build, but it has the correct Home Assistant configuration model for PIN-protected Xzense devices.

## Installation / upgrade

Copy `custom_components/xzense` to `/config/custom_components/xzense` and restart Home Assistant.

If upgrading from 0.2.0, simply replace the integration files and restart Home Assistant. The stored Xzense PIN is kept. If upgrading directly from 0.1.x, Home Assistant should request reauthentication and ask for the Xzense PIN.

## BLE transport

- Service: `0783b03e-8535-b5a0-7140-a304d2495cb7`
- Device → HA notify: `0783b03e-8535-b5a0-7140-a304d2495cb8`
- HA → device write: `0783b03e-8535-b5a0-7140-a304d2495cba`
