# Xzense Full Preview 0.4.2

Development Home Assistant integration for Exodraft Xzense with the full entity model scaffolded up front. Unverified appliance-control writes remain safety-gated.

## What is functional

- Home Assistant Bluetooth / ESPHome Bluetooth Proxy discovery
- Xzense DSPS GATT transport
- Application PIN `CONNECT/REQ` and `CONNECT/ACK`
- Session ID handling
- CRC-16/CCITT-FALSE and byte escaping
- Notifications and validated frame parsing
- `STATUS/REQ` polling every 10 seconds
- 14-byte live STATUS/ACK decoding
- GLOBAL/DATA decoding and cache
- Generic GLOBAL/REQ frame builder
- Extensive diagnostics and short packet history

## 0.4.2 live calibration

Two synchronized panel snapshots corrected the runtime map:

- `GLOBAL 0x1E` = chimney temperature in tenths of °C. Raw `490` matched **49.0 °C**.
- `GLOBAL 0x1F` = actual fan speed in percent. It tracked **10 % → 100 %**.
- STATUS contains the same fan and chimney values directly.
- device state `3` = **Boosting**.
- `GLOBAL 0x20` is **not** fan speed and is deliberately left unidentified.
- inside/outside temperature candidates are now decoded from `0x1C` / `0x1D` with `/10`; their values are plausible but still await one direct panel confirmation.
- the old `0x1C = pressure` assumption is removed; Air pressure stays present but unavailable until its actual mapping is verified.

See `PROTOCOL_NOTES.md` for the two exact captured STATUS frames and `FEATURE_MATRIX.md` for readiness per feature.

## Full app-style entity set

Sensor, binary_sensor, button, switch, number, select and update platforms are already scaffolded. Unsupported controls remain unavailable because `CONTROL_WRITES_ENABLED = False`.

## Side-integration rule

Domain: `xzense_full_preview`.

It can be installed alongside the other custom-component folders, but it refuses to start its BLE client while `xzense` or `xzense_preview` is loaded. Only one client should own the Xzense BLE session at a time.

## PIN

Setup asks for the current four-character hexadecimal PIN shown by Xzense. Reconfigure asks for a fresh PIN and does not pre-fill the old value.
