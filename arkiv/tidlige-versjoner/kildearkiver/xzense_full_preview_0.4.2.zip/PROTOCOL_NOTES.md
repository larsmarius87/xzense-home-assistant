# Xzense Full Preview 0.4.2 — protocol notes

## BLE transport

Service: `0783b03e-8535-b5a0-7140-a304d2495cb7`

- Notify/TX from Xzense: `0783b03e-8535-b5a0-7140-a304d2495cb8`
- Write/RX to Xzense: `0783b03e-8535-b5a0-7140-a304d2495cba`

The four-character Xzense PIN belongs to the Xzense application protocol, not standard BLE pairing.

## Frame

Unescaped logical frame:

`23 | size_le16 | 00 | outer_type | payload | crc16_le | 24`

CRC is CRC-16/CCITT-FALSE over `00 | outer_type | payload`. Reserved bytes `23`, `24`, `27` are escaped in payload/CRC as `27, byte|80`.

## Application packet

Outer type `06` carries:

`packet_type | protocol_type | application_payload`

Known protocol types: DATA=`08`, NACK=`09`, ACK=`0A`, REQ=`0B`.

## CONNECT

`02 0B | pin_le16 | time_u32 | name_len | ASCII name`

A successful ACK returns a session ID used by subsequent application messages.

## STATUS read — recalibrated in 0.4.2

Request:

`07 0B | session_id_le32`

The controller replies with a 14-byte application payload. Two synchronized measurements fixed the field order.

### Snapshot A — panel fan 10 %, chimney 49 °C

STATUS payload:

`04 43 02 0a 00 ea 01 30 00 d5 00 f3 03 00`

### Snapshot B — panel fan 100 %, Boosting, chimney 49 °C

STATUS payload:

`03 87 00 64 00 ea 01 32 00 da 00 f3 03 00`

The changing fields prove:

| STATUS field | Snapshot A | Snapshot B | Interpretation | Matching GLOBAL |
|---|---:|---:|---|---|
| byte 0 | 4 | 3 | device state; **3 = Boosting** | `0x19` |
| i16 @1 | 579 | 135 | chimney-state/raw runtime field | `0x1A` |
| i16 @3 | 10 | 100 | **fan speed %** | `0x1F` |
| i16 @5 | 490 | 490 | **chimney temp ×10 → 49.0 °C** | `0x1E` |
| i16 @7 | 48 | 50 | candidate outside temp ×10 → 4.8/5.0 °C | `0x1D` |
| i16 @9 | 213 | 218 | candidate inside temp ×10 → 21.3/21.8 °C | `0x1C` |
| i16 @11 | 1011 | 1011 | state timer | `0x1B` |
| byte 13 | 0 | 0 | flags; meaning unknown | — |

The user-confirmed values directly verify fan speed and chimney temperature. The inside/outside labels are a strong live inference from plausible values and field ordering, but are intentionally documented as awaiting one direct panel cross-check.

`GLOBAL 0x20` stayed at `10` while fan speed changed from 10 % to 100 %, proving the previous `0x20 = FAN_SPEED` mapping was wrong. Its meaning remains unknown in 0.4.2.

## GLOBAL read/write transport

GLOBAL/DATA is decoded as repeated entries:

`global_id_u8 | value_i16_le`

The generic GLOBAL/REQ write envelope is:

`06 0B | session_id_le32 | global_id_u8 | value_i16_le`

The encoder is implemented, but individual control semantics/scaling remain safety-gated.

## Current runtime IDs

- `19` MY_STATE — state `3` verified as Boosting
- `1A` CHIMNEY_STATE — raw runtime field
- `1B` STATE_TIMER
- `1C` INSIDE_TEMP candidate, tenths °C
- `1D` OUTSIDE_TEMP candidate, tenths °C
- `1E` CHIMNEY_TEMP — **verified**, tenths °C
- `1F` FAN_SPEED — **verified**, percent
- `20` UNKNOWN — deliberately not assigned

Other previously recovered candidate IDs remain scaffolded for future verification. Packet type `09` is VENTILATION; its application payload is not yet mapped.
