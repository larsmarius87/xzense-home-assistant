# Changelog

## 0.4.2

- Recalibrates the live STATUS/GLOBAL field mapping from two synchronized controller snapshots.
- Verifies `GLOBAL 0x1E` as chimney temperature in tenths of a degree: raw `490` matched **49.0 °C** on the panel.
- Verifies `GLOBAL 0x1F` as actual fan speed: it followed the panel from **10 %** to **100 %**.
- Corrects the 14-byte STATUS layout so fan speed is included directly in STATUS.
- Marks `GLOBAL 0x20` as unknown instead of incorrectly labelling it FAN_SPEED.
- Applies `/10` scaling to live temperature entities.
- Reorders the candidate inside/outside temperature fields to `0x1C` and `0x1D`; their live values now decode as plausible 21.x °C / 4.x-5.x °C, but they remain marked as awaiting direct panel confirmation.
- Removes the disproven `0x1C = pressure` mapping; the Air pressure entity stays present but unavailable until its real source is confirmed.
- Verifies device state `3` as **Boosting** from a synchronized 100 % Boosting snapshot. Other numeric state labels are intentionally not guessed.
- Adds regression tests for both the 10 % / 49 °C snapshot and the 100 % / Boosting / 49 °C snapshot.
- Keeps `CONTROL_WRITES_ENABLED = False`; this release only improves reads and diagnostics.

## 0.4.1

- Corrects STATUS decoding from the earlier 19-byte hypothesis to the **14-byte live STATUS/ACK payload** observed on the real controller.
- Makes live STATUS/ACK replies count as status responses instead of leaving `status_response_count` at zero.
- Adds live-frame regression coverage.

## 0.4.0

- New separate domain: `xzense_full_preview`.
- Preserves authenticated BLE/session/status handling.
- Adds the complete Home Assistant-side entity scaffold for app-visible Xzense functions.
- Keeps unverified physical/control writes safety-gated.
