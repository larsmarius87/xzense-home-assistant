# Xzense Full Preview 0.4.2 — feature matrix

The full Home Assistant entity model remains scaffolded. 0.4.2 concentrates on correcting the live read mappings from synchronized panel/controller measurements.

## Live/read paths

| Function | HA entity | Protocol status |
|---|---|---|
| BLE link | Binary sensor | Implemented |
| Xzense application session | Binary sensor | Implemented |
| Device state | Sensor | GLOBAL `0x19` / STATUS; **state 3 verified = Boosting** |
| Chimney state | Sensor | GLOBAL `0x1A` / STATUS; raw meaning still under study |
| State timer | Sensor | GLOBAL `0x1B` / STATUS |
| Inside temperature | Sensor | Candidate GLOBAL `0x1C`, `/10`; plausible live values, direct panel confirmation pending |
| Outside temperature | Sensor | Candidate GLOBAL `0x1D`, `/10`; plausible live values, direct panel confirmation pending |
| Chimney temperature | Sensor | **Verified** GLOBAL `0x1E`, `/10`: raw `490` = 49.0 °C |
| Fan speed | Sensor | **Verified** GLOBAL `0x1F` / STATUS: tracked 10 % → 100 % |
| GLOBAL `0x20` | Diagnostic raw sensor | Meaning intentionally unknown |
| Air pressure | Sensor | Entity present; mapping pending after old `0x1C` mapping was disproven |
| Chimney draught / actual draft | Sensor | Global `0x51` known; raw semantics/scaling pending |
| Signal strength / battery | Sensors | IDs known; raw |

The final STATUS byte remains exposed as raw `status_flags`; its bit meanings are not mapped yet.

## Control/settings model already scaffolded

These entities remain present but intentionally unavailable until action semantics/scaling are verified.

| Function | HA entity | Known protocol information |
|---|---|---|
| Start fire | Button | App function known; packet mapping pending |
| Stop fire | Button | App function known; packet mapping pending |
| Refueling | Button | App function known; packet mapping pending |
| Boost | Button | App function known; packet mapping pending |
| Ventilation | Switch | Packet type `0x09` known; payload mapping pending |
| Manual fan speed | Number | Global `0x52 USER_FAN_SPEED` candidate mapping retained |
| Boost fan speed | Number | Global `0x50 BOOST_FAN_SPEED` candidate mapping retained |
| System control | Select | Global `0x56`; Manual / Pressure controlled / eXotelligence scaffolded |
| Auto start temperature | Number | Global `0x4C` candidate mapping retained |
| Auto stop temperature | Number | Global `0x4D` candidate mapping retained |
| Boost time | Number | Global `0x4E` candidate mapping retained |
| After-run time | Number | Global `0x4F` candidate mapping retained |
| Boost stop temperature | Number | Global `0x53` candidate mapping retained |
| Wanted draught | Number | Global `0x54` candidate mapping retained |
| Minimum fan voltage | Number | Global `0x55` candidate mapping retained |
| Temperature sensor selection | Select | Global `0x57`; option encoding pending |
| External start | Switch | Global `0x58` candidate mapping retained |
| Alarm setpoint | Number | Global `0x59` candidate mapping retained |
| Refire time | Number | Global `0x5A` candidate mapping retained |
| External fan speed | Number | Global `0x5B` candidate mapping retained |

## Other app features scaffolded

Burn count, operation time, weather station, error log, firmware update, log download, history, and PIN/config-flow handling remain in the entity model.

## Safety rule

`CONTROL_WRITES_ENABLED = False`. 0.4.2 does not enable new physical-control writes.
