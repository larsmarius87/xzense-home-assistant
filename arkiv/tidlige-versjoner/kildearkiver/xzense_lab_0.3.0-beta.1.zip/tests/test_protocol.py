import importlib.util
from pathlib import Path
import sys

P = Path(__file__).parents[1] / "custom_components" / "xzense_lab" / "protocol.py"
spec = importlib.util.spec_from_file_location("xzense_lab_protocol", P)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)


def test_crc_known_status_request():
    frame = mod.build_status_request(0xED249437)
    assert frame.hex() == "2308000006070b379427a4ed398b24"


def test_connect_0000_homeassistantlab_builds():
    frame = mod.build_connect_request("0000", "HomeAssistantLab")
    assert frame[0] == 0x23 and frame[-1] == 0x24


def test_status_decode():
    body = bytes([1]) + (2).to_bytes(2,'little',signed=True) + (120).to_bytes(2,'little',signed=True) + (8).to_bytes(2,'little',signed=True) + (21).to_bytes(2,'little',signed=True) + (30).to_bytes(2,'little',signed=True) + bytes([0]) + (45).to_bytes(2,'little',signed=True) + b'\x00'*5
    frame_bytes = mod.build_frame(mod.OUTER_TYPE_APPLICATION, bytes([mod.PACKET_STATUS, mod.PROTOCOL_DATA]) + body)
    p = mod.XzenseFrameParser()
    frames = p.feed(frame_bytes)
    status = mod.decode_status_data(frames[0])
    assert status.chimney_temperature == 120
    assert status.inside_temperature == 21
    assert status.fan_speed == 45
