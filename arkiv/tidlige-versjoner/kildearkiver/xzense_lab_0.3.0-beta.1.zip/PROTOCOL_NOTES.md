# Xzense Lab protocol notes

The protocol implementation is copied from the tested Xzense 0.3.0 beta work:

- DSPS service `0783b03e-8535-b5a0-7140-a304d2495cb7`
- notify `...5cb8`
- write `...5cba`
- application PIN is four hexadecimal characters and is carried in CONNECT/REQ
- CONNECT/ACK returns a 32-bit session ID
- STATUS/REQ is read-only and uses that session ID
- CRC is CRC-16/CCITT-FALSE

Xzense Lab deliberately implements no physical control writes.
