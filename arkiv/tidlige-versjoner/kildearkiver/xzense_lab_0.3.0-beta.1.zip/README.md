# Xzense Lab 0.3.0 beta 1

A separate, manual one-shot Home Assistant tester for Exodraft Xzense.

## Purpose

This is intentionally separate from the normal `xzense` integration. It does **not** connect in the background and does not poll continuously. It connects only when **Run full test** is pressed, checks the BLE/application path, reads status, then disconnects.

## Important

- Disable the normal **Xzense** integration before running a lab test.
- The lab will refuse to start while the normal `xzense` integration is loaded, to prevent two clients fighting over the controller.
- Setup prompts for the current four-character Xzense PIN.
- To change the PIN later: Settings → Devices & services → Xzense Lab → ⋮ → Reconfigure. The form deliberately does not reveal the old PIN.
- This build is read-only. It does not change fan speed, boost, system control, timers, temperature setpoints or settings.

## Test buttons

- **Test BLE only**: fresh advertisement → BLE connect → notifications → disconnect.
- **Test PIN login**: BLE test + CONNECT/REQ with the PIN you entered → CONNECT/ACK/NACK → disconnect.
- **Run full read test**: PIN test + STATUS/REQ + decoded temperatures/fan → disconnect.
- **Cancel test**: aborts the active one-shot test.

## What the full read test checks

1. Waits for a fresh connectable Xzense advertisement.
2. Tries up to three independent BLE connection rounds; each round uses a fresh advertisement.
3. Enables notifications.
4. Sends the recovered Xzense CONNECT/REQ using the PIN you entered.
5. Confirms CONNECT/ACK and session ID.
6. Sends the official read-only STATUS/REQ.
7. Decodes chimney temperature, inside temperature, outside temperature and fan speed.
8. Listens briefly for passive GLOBAL/DATA updates.
9. Disconnects automatically.

The result sensor ends as `pass_ble`, `pass_pin`, `pass_full`, `pin_rejected_or_connect_nack`, `ble_connect_failed`, `authenticated_but_status_timeout`, etc.
