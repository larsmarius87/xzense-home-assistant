"""Constants for Xzense Lab."""
from __future__ import annotations

import re

DOMAIN = "xzense_lab"
NAME = "Xzense Lab"
SERVICE_UUID = "0783b03e-8535-b5a0-7140-a304d2495cb7"
NOTIFY_UUID = "0783b03e-8535-b5a0-7140-a304d2495cb8"
WRITE_UUID = "0783b03e-8535-b5a0-7140-a304d2495cba"
CONF_PIN = "pin"
CONF_NAME = "name"
DEFAULT_NAME = "Xzense Lab"
PIN_PATTERN = re.compile(r"^[0-9A-F]{4}$")


def normalize_pin(value: str) -> str | None:
    pin = value.strip().upper()
    return pin if PIN_PATTERN.fullmatch(pin) else None
