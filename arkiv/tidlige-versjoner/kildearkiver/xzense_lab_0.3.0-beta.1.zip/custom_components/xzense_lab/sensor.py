"""Sensors for Xzense Lab."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from homeassistant.components.sensor import SensorDeviceClass, SensorEntity, SensorStateClass
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory, PERCENTAGE, UnitOfTemperature
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import DOMAIN
from .entity import XzenseLabEntity
from .probe import LabState, XzenseLabProbe


@dataclass(frozen=True, slots=True)
class Desc:
    key: str
    name: str
    fn: Callable[[LabState], Any]
    diagnostic: bool = True
    unit: str | None = None
    device_class: SensorDeviceClass | None = None
    state_class: SensorStateClass | None = None


def _status(state: LabState, attr: str):
    return getattr(state.status, attr) if state.status is not None else None


def _globals(state: LabState):
    return " | ".join(f"0x{k:02X}={v}" for k, v in sorted(state.globals.items())) or None


SENSORS = (
    Desc("result", "Test result", lambda s: s.result, diagnostic=False),
    Desc("chimney_temperature", "Chimney temperature", lambda s: _status(s, "chimney_temperature"), False, UnitOfTemperature.CELSIUS, SensorDeviceClass.TEMPERATURE, SensorStateClass.MEASUREMENT),
    Desc("inside_temperature", "Inside temperature", lambda s: _status(s, "inside_temperature"), False, UnitOfTemperature.CELSIUS, SensorDeviceClass.TEMPERATURE, SensorStateClass.MEASUREMENT),
    Desc("outside_temperature", "Outside temperature", lambda s: _status(s, "outside_temperature"), False, UnitOfTemperature.CELSIUS, SensorDeviceClass.TEMPERATURE, SensorStateClass.MEASUREMENT),
    Desc("fan_speed", "Fan speed", lambda s: _status(s, "fan_speed"), False, PERCENTAGE, None, SensorStateClass.MEASUREMENT),
    Desc("phase", "Test phase", lambda s: s.phase),
    Desc("running", "Test running", lambda s: s.running),
    Desc("last_test_started_at", "Last test started", lambda s: s.last_test_started_at),
    Desc("last_test_finished_at", "Last test finished", lambda s: s.last_test_finished_at),
    Desc("blocked_by_main_integration", "Blocked by normal Xzense", lambda s: s.blocked_by_main_integration),
    Desc("advertisement_count", "Fresh advertisements", lambda s: s.advertisement_count),
    Desc("connection_attempts", "BLE connection attempts", lambda s: s.connection_attempts),
    Desc("connect_round", "BLE connect round", lambda s: s.connect_round),
    Desc("source", "Bluetooth source", lambda s: s.source),
    Desc("rssi", "Advertisement RSSI", lambda s: s.rssi),
    Desc("ble_connected", "BLE connected", lambda s: s.ble_connected),
    Desc("notifications_active", "Notifications active", lambda s: s.notifications_active),
    Desc("auth_state", "PIN/auth result", lambda s: s.auth_state),
    Desc("auth_ok", "PIN accepted", lambda s: s.auth_ok),
    Desc("session_id", "Session ID", lambda s: f"0x{s.session_id:08X}" if s.session_id is not None else None),
    Desc("connect_ack_version", "CONNECT ACK version", lambda s: s.connect_ack_version),
    Desc("connect_ack_flag", "CONNECT ACK flag", lambda s: s.connect_ack_flag),
    Desc("status_ok", "Status response received", lambda s: s.status_ok),
    Desc("tx_count", "TX frames", lambda s: s.tx_count),
    Desc("notification_count", "BLE notifications", lambda s: s.notification_count),
    Desc("packet_count", "Protocol frames", lambda s: s.packet_count),
    Desc("crc_errors", "CRC errors", lambda s: s.crc_errors),
    Desc("invalid_frames", "Invalid frames", lambda s: s.invalid_frames),
    Desc("last_rx", "Last BLE RX", lambda s: s.last_rx.hex() if s.last_rx else None),
    Desc("last_frame", "Last protocol frame", lambda s: s.last_frame.hex if s.last_frame else None),
    Desc("globals", "Global values", _globals),
    Desc("last_error", "Last error", lambda s: s.last_error),
)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddConfigEntryEntitiesCallback) -> None:
    probe: XzenseLabProbe = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(LabSensor(probe, desc) for desc in SENSORS)


class LabSensor(XzenseLabEntity, SensorEntity):
    def __init__(self, probe: XzenseLabProbe, desc: Desc) -> None:
        super().__init__(probe)
        self.desc = desc
        self._attr_name = desc.name
        self._attr_unique_id = f"{probe.address}_{desc.key}"
        if desc.diagnostic:
            self._attr_entity_category = EntityCategory.DIAGNOSTIC
        if desc.unit is not None:
            self._attr_native_unit_of_measurement = desc.unit
        if desc.device_class is not None:
            self._attr_device_class = desc.device_class
        if desc.state_class is not None:
            self._attr_state_class = desc.state_class

    @property
    def native_value(self):
        return self.desc.fn(self.probe.state)
