"""Xzense Lab one-shot tester."""
from __future__ import annotations

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_ADDRESS, Platform
from homeassistant.core import HomeAssistant

from .const import CONF_NAME, CONF_PIN, DEFAULT_NAME, DOMAIN
from .probe import XzenseLabProbe

PLATFORMS = [Platform.SENSOR, Platform.BUTTON]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    hass.data.setdefault(DOMAIN, {})
    probe = XzenseLabProbe(
        hass,
        entry.data[CONF_ADDRESS],
        entry.data.get(CONF_NAME, entry.title or DEFAULT_NAME),
        entry.data[CONF_PIN],
    )
    hass.data[DOMAIN][entry.entry_id] = probe
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    # Deliberately no BLE connection here. It only runs when the button is pressed.
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    probe: XzenseLabProbe = hass.data[DOMAIN][entry.entry_id]
    await probe.async_stop()
    unloaded = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unloaded:
        hass.data[DOMAIN].pop(entry.entry_id, None)
    return unloaded
