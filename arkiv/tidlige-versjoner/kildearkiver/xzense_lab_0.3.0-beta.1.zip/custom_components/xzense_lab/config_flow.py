"""Config flow for the one-shot Xzense Lab tester."""
from __future__ import annotations

from typing import Any
import voluptuous as vol

from homeassistant.components.bluetooth import async_discovered_service_info
from homeassistant.config_entries import ConfigFlow, ConfigFlowResult
from homeassistant.const import CONF_ADDRESS

from .const import CONF_NAME, CONF_PIN, DEFAULT_NAME, DOMAIN, SERVICE_UUID, normalize_pin


def _looks_like_xzense(info) -> bool:
    name = (info.name or "").lower()
    return "xzense" in name or SERVICE_UUID.lower() in {u.lower() for u in info.service_uuids}


class XzenseLabConfigFlow(ConfigFlow, domain=DOMAIN):
    """Manual-only setup. Adding the integration never opens a BLE link."""

    VERSION = 1

    async def async_step_user(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        errors: dict[str, str] = {}
        discovered = {
            info.address: info
            for info in async_discovered_service_info(self.hass, connectable=True)
            if _looks_like_xzense(info)
        }

        if user_input is not None:
            address = str(user_input[CONF_ADDRESS]).strip()
            pin = normalize_pin(str(user_input[CONF_PIN]))
            if pin is None:
                errors[CONF_PIN] = "invalid_pin"
            else:
                await self.async_set_unique_id(address, raise_on_progress=False)
                self._abort_if_unique_id_configured()
                info = discovered.get(address)
                title = (info.name if info else None) or DEFAULT_NAME
                return self.async_create_entry(
                    title=title,
                    data={CONF_ADDRESS: address, CONF_NAME: title, CONF_PIN: pin},
                )

        if discovered:
            labels = {
                address: f"{(info.name or 'Xzense')} ({address})"
                for address, info in discovered.items()
            }
            schema = vol.Schema(
                {
                    vol.Required(CONF_ADDRESS): vol.In(labels),
                    vol.Required(CONF_PIN): str,
                }
            )
        else:
            schema = vol.Schema(
                {
                    vol.Required(CONF_ADDRESS): str,
                    vol.Required(CONF_PIN): str,
                }
            )

        return self.async_show_form(step_id="user", data_schema=schema, errors=errors)

    async def async_step_reconfigure(self, user_input: dict[str, Any] | None = None) -> ConfigFlowResult:
        """Prompt for a new PIN without deleting the lab entry."""
        entry = self._get_reconfigure_entry()
        errors: dict[str, str] = {}
        if user_input is not None:
            pin = normalize_pin(str(user_input[CONF_PIN]))
            if pin is None:
                errors[CONF_PIN] = "invalid_pin"
            else:
                return self.async_update_reload_and_abort(entry, data_updates={CONF_PIN: pin})

        # Intentionally do not show the stored PIN. This makes reconfigure a real prompt.
        return self.async_show_form(
            step_id="reconfigure",
            data_schema=vol.Schema({vol.Required(CONF_PIN): str}),
            errors=errors,
        )
