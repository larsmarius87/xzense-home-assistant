"""One-shot Xzense protocol probe.

The lab never connects in the background. It opens a BLE/app session only when
Run full test is pressed, performs read-only checks, then disconnects.
"""
from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
import logging

from bleak.backends.characteristic import BleakGATTCharacteristic
from bleak_retry_connector import BleakClientWithServiceCache, establish_connection

from homeassistant.components import bluetooth
from homeassistant.core import HomeAssistant, callback

from .const import NOTIFY_UUID, WRITE_UUID
from .protocol import (
    PACKET_STATUS,
    PROTOCOL_NACK,
    XzenseFrame,
    XzenseFrameParser,
    XzenseStatusData,
    build_connect_request,
    build_status_request,
    decode_global_data,
    decode_status_data,
    global_name,
)

_LOGGER = logging.getLogger(__name__)
Listener = Callable[[], None]

ADVERTISEMENT_TIMEOUT = 20.0
CONNECT_ROUNDS = 3
NOTIFY_TIMEOUT = 8.0
AUTH_TIMEOUT = 5.0
STATUS_TIMEOUT = 5.0
POST_STATUS_LISTEN = 2.0
CLIENT_NAME = "HomeAssistantLab"


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="milliseconds")


@dataclass(slots=True)
class LabState:
    running: bool = False
    result: str = "not_run"
    phase: str = "idle"
    last_test_started_at: str | None = None
    last_test_finished_at: str | None = None
    last_error: str | None = None
    blocked_by_main_integration: bool = False

    advertisement_count: int = 0
    connection_attempts: int = 0
    connect_round: int = 0
    source: str | None = None
    rssi: int | None = None
    ble_connected: bool = False
    notifications_active: bool = False

    tx_count: int = 0
    notification_count: int = 0
    packet_count: int = 0
    crc_errors: int = 0
    invalid_frames: int = 0
    last_rx: bytes = b""
    last_frame: XzenseFrame | None = None
    packet_history: list[dict[str, object]] = field(default_factory=list)

    auth_state: str = "not_started"
    auth_ok: bool = False
    session_id: int | None = None
    connect_ack_version: int | None = None
    connect_ack_flag: int | None = None

    status_ok: bool = False
    status: XzenseStatusData | None = None
    globals: dict[int, int] = field(default_factory=dict)


class XzenseLabProbe:
    def __init__(self, hass: HomeAssistant, address: str, name: str, pin: str) -> None:
        self.hass = hass
        self.address = address
        self.name = name
        self.pin = pin
        self.state = LabState()
        self._listeners: set[Listener] = set()
        self._lock = asyncio.Lock()
        self._parser = XzenseFrameParser()
        self._auth_event = asyncio.Event()
        self._status_event = asyncio.Event()
        self._client: BleakClientWithServiceCache | None = None
        self._task: asyncio.Task[None] | None = None

    @callback
    def async_add_listener(self, listener: Listener) -> Callable[[], None]:
        self._listeners.add(listener)
        @callback
        def remove() -> None:
            self._listeners.discard(listener)
        return remove

    @callback
    def _notify(self) -> None:
        for listener in tuple(self._listeners):
            listener()

    def _phase(self, value: str) -> None:
        self.state.phase = value
        self._notify()

    def async_schedule_test(self, mode: str) -> bool:
        """Schedule one BLE, PIN, or full read test."""
        if mode not in {"ble", "pin", "full"}:
            raise ValueError(f"Unsupported lab test mode: {mode}")
        if self._task and not self._task.done():
            return False
        self._task = self.hass.async_create_task(self.async_run_test(mode))
        return True

    def async_cancel_test(self) -> bool:
        """Cancel the currently running test, if any."""
        if not self._task or self._task.done():
            return False
        self._task.cancel()
        return True

    async def async_stop(self) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        await self._disconnect()

    def _main_integration_loaded(self) -> bool:
        """Prevent this lab from competing with the normal xzense integration."""
        return bool(self.hass.data.get("xzense"))

    def _reset_for_test(self) -> None:
        s = self.state
        s.running = True
        s.result = "running"
        s.phase = "starting"
        s.last_test_started_at = _now()
        s.last_test_finished_at = None
        s.last_error = None
        s.blocked_by_main_integration = False
        s.advertisement_count = 0
        s.connection_attempts = 0
        s.connect_round = 0
        s.source = None
        s.rssi = None
        s.ble_connected = False
        s.notifications_active = False
        s.tx_count = 0
        s.notification_count = 0
        s.packet_count = 0
        s.crc_errors = 0
        s.invalid_frames = 0
        s.last_rx = b""
        s.last_frame = None
        s.packet_history.clear()
        s.auth_state = "not_started"
        s.auth_ok = False
        s.session_id = None
        s.connect_ack_version = None
        s.connect_ack_flag = None
        s.status_ok = False
        s.status = None
        s.globals.clear()
        self._auth_event.clear()
        self._status_event.clear()
        self._parser.reset()
        self._notify()

    async def async_run_test(self, mode: str) -> None:
        async with self._lock:
            self._reset_for_test()
            self.state.result = f"running_{mode}"
            self._notify()
            if self._main_integration_loaded():
                self.state.blocked_by_main_integration = True
                self.state.result = "blocked_main_xzense_loaded"
                self.state.last_error = (
                    "Disable the normal Xzense integration before running Xzense Lab; "
                    "both must not connect to the controller at the same time."
                )
                self._finish()
                return

            try:
                connected = await self._connect_with_fresh_advertisements()
                if not connected:
                    if self.state.result == "running":
                        self.state.result = "ble_connect_failed"
                    return

                client = self._client
                if client is None or not client.is_connected:
                    raise RuntimeError("BLE client disappeared after connect")

                self._phase("enabling_notifications")
                await asyncio.wait_for(
                    client.start_notify(NOTIFY_UUID, self._notification),
                    timeout=NOTIFY_TIMEOUT,
                )
                self.state.notifications_active = True
                self._phase("notifications_active")

                if mode == "ble":
                    self.state.result = "pass_ble"
                    self._phase("passed_ble")
                    return

                self.state.auth_state = "sending_connect"
                self._phase("testing_pin")
                await self._write_frame(client, build_connect_request(self.pin, CLIENT_NAME))
                try:
                    await asyncio.wait_for(self._auth_event.wait(), timeout=AUTH_TIMEOUT)
                except TimeoutError:
                    self.state.auth_state = "timeout"
                    self.state.result = "pin_or_handshake_timeout"
                    self.state.last_error = "No CONNECT/ACK or CONNECT/NACK received"
                    return

                if not self.state.auth_ok or self.state.session_id is None:
                    self.state.result = "pin_rejected_or_connect_nack"
                    if self.state.last_error is None:
                        self.state.last_error = "CONNECT/NACK received"
                    return

                if mode == "pin":
                    self.state.result = "pass_pin"
                    self._phase("passed_pin")
                    return

                self._phase("requesting_status")
                await self._write_frame(client, build_status_request(self.state.session_id))
                try:
                    await asyncio.wait_for(self._status_event.wait(), timeout=STATUS_TIMEOUT)
                except TimeoutError:
                    self.state.result = "authenticated_but_status_timeout"
                    self.state.last_error = "PIN accepted, but STATUS response did not arrive"
                    return

                if not self.state.status_ok:
                    self.state.result = "status_nack"
                    if self.state.last_error is None:
                        self.state.last_error = "STATUS response was not valid status data"
                    return

                await asyncio.sleep(POST_STATUS_LISTEN)
                self.state.result = "pass_full"
                self._phase("passed_full")
            except asyncio.CancelledError:
                self.state.result = "cancelled"
                self._phase("cancelled")
                raise
            except Exception as err:
                self.state.result = "error"
                self.state.last_error = f"{type(err).__name__}: {err}"
                self._phase("error")
                _LOGGER.debug("Xzense Lab test failed", exc_info=True)
            finally:
                await self._disconnect()
                self._finish()

    def _finish(self) -> None:
        self.state.running = False
        self.state.last_test_finished_at = _now()
        if not self.state.phase.startswith("passed") and self.state.phase not in {"error", "cancelled"}:
            self.state.phase = "finished"
        self._notify()

    async def _wait_fresh_advertisement(self):
        self._phase("waiting_for_fresh_advertisement")
        bluetooth.async_clear_advertisement_history(self.hass, self.address)
        event = asyncio.Event()
        holder: dict[str, object] = {}

        @callback
        def cb(service_info, _change) -> None:
            holder["info"] = service_info
            self.state.advertisement_count += 1
            self.state.source = service_info.source
            self.state.rssi = service_info.rssi
            self._notify()
            event.set()

        cancel = bluetooth.async_register_callback(
            self.hass,
            cb,
            {"address": self.address, "connectable": True},
            bluetooth.BluetoothScanningMode.ACTIVE,
            replay=bluetooth.BluetoothCallbackReplay.DISABLED,
        )
        scan_task = self.hass.async_create_task(
            bluetooth.async_request_active_scan(ADVERTISEMENT_TIMEOUT)
        )
        try:
            async with asyncio.timeout(ADVERTISEMENT_TIMEOUT):
                await event.wait()
            return holder.get("info")
        except TimeoutError:
            self.state.last_error = f"No fresh connectable advertisement in {ADVERTISEMENT_TIMEOUT:.0f}s"
            return None
        finally:
            cancel()
            scan_task.cancel()

    async def _connect_with_fresh_advertisements(self) -> bool:
        last_error: Exception | None = None
        for round_no in range(1, CONNECT_ROUNDS + 1):
            self.state.connect_round = round_no
            info = await self._wait_fresh_advertisement()
            if info is None:
                continue
            ble_device = info.device
            if ble_device is None:
                self.state.last_error = "Fresh advertisement had no BLEDevice"
                continue

            self.state.connection_attempts += 1
            self._phase(f"connecting_round_{round_no}")
            try:
                client = await establish_connection(
                    BleakClientWithServiceCache,
                    ble_device,
                    ble_device.name or self.name,
                    self._disconnected,
                    max_attempts=1,
                )
                self._client = client
                self.state.ble_connected = bool(client.is_connected)
                self._phase("ble_connected")
                self._notify()
                return bool(client.is_connected)
            except Exception as err:
                last_error = err
                self.state.last_error = f"{type(err).__name__}: {err}"
                self._phase(f"connect_failed_round_{round_no}")
                bluetooth.async_clear_advertisement_history(self.hass, self.address)
                await asyncio.sleep(0.5)

        if last_error is not None:
            self.state.last_error = f"{type(last_error).__name__}: {last_error}"
        return False

    async def _write_frame(self, client: BleakClientWithServiceCache, frame: bytes) -> None:
        characteristic = client.services.get_characteristic(WRITE_UUID)
        if characteristic is None:
            raise RuntimeError("Xzense write characteristic not found")
        props = set(characteristic.properties or [])
        response = "write-without-response" not in props
        if response and "write" not in props:
            raise RuntimeError(f"Unsupported write properties: {sorted(props)}")
        try:
            size = int(characteristic.max_write_without_response_size) if not response else 512
        except Exception:
            size = 20
        size = max(1, min(size, 512))
        for offset in range(0, len(frame), size):
            await client.write_gatt_char(characteristic, frame[offset:offset+size], response=response)
            if offset + size < len(frame):
                await asyncio.sleep(0.01)
        self.state.tx_count += 1
        self._notify()

    def _disconnected(self, _client) -> None:
        self.state.ble_connected = False
        self.state.notifications_active = False
        self._notify()

    async def _disconnect(self) -> None:
        client = self._client
        self._client = None
        if client and client.is_connected:
            if self.state.notifications_active:
                try:
                    await client.stop_notify(NOTIFY_UUID)
                except Exception:
                    pass
            try:
                await client.disconnect()
            except Exception:
                pass
        self.state.ble_connected = False
        self.state.notifications_active = False
        self._notify()

    def _record_frame(self, frame: XzenseFrame) -> None:
        self.state.packet_history.append(
            {
                "at": _now(),
                "packet": frame.packet_type_name,
                "protocol": frame.protocol_type_name,
                "frame": frame.hex,
                "payload": frame.application_payload.hex(),
            }
        )
        if len(self.state.packet_history) > 20:
            del self.state.packet_history[:-20]

    def _notification(self, _characteristic: BleakGATTCharacteristic, data: bytearray) -> None:
        payload = bytes(data)
        self.state.notification_count += 1
        self.state.last_rx = payload
        frames = self._parser.feed(payload)
        self.state.crc_errors = self._parser.crc_errors
        self.state.invalid_frames = self._parser.invalid_frames
        for frame in frames:
            self.state.packet_count += 1
            self.state.last_frame = frame
            self._record_frame(frame)

            if frame.is_connect_ack:
                self.state.auth_state = "accepted"
                self.state.auth_ok = True
                self.state.session_id = frame.session_id
                self.state.connect_ack_version = frame.connect_version
                self.state.connect_ack_flag = frame.connect_flag
                self._auth_event.set()
            elif frame.is_connect_nack:
                self.state.auth_state = "rejected"
                self.state.auth_ok = False
                self.state.last_error = "CONNECT/NACK: PIN rejected or request invalid"
                self._auth_event.set()

            status = decode_status_data(frame, self.state.session_id)
            if status is not None:
                self.state.status = status
                self.state.status_ok = True
                self._status_event.set()
            elif frame.packet_type == PACKET_STATUS and frame.protocol_type == PROTOCOL_NACK:
                self.state.last_error = "STATUS/NACK received"
                self._status_event.set()

            values = decode_global_data(frame, self.state.session_id)
            if values:
                self.state.globals.update(values)
                _LOGGER.debug(
                    "Xzense Lab globals: %s",
                    {global_name(k): v for k, v in values.items()},
                )
        self._notify()
