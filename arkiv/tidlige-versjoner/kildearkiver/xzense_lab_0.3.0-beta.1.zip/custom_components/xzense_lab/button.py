"""Buttons for Xzense Lab."""
from __future__ import annotations

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .const import DOMAIN
from .entity import XzenseLabEntity
from .probe import XzenseLabProbe


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddConfigEntryEntitiesCallback) -> None:
    probe: XzenseLabProbe = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([
        RunTestButton(probe, "ble", "Test BLE only"),
        RunTestButton(probe, "pin", "Test PIN login"),
        RunTestButton(probe, "full", "Run full read test"),
        CancelTestButton(probe),
    ])


class RunTestButton(XzenseLabEntity, ButtonEntity):
    def __init__(self, probe: XzenseLabProbe, mode: str, name: str) -> None:
        super().__init__(probe)
        self.mode = mode
        self._attr_name = name
        self._attr_unique_id = f"{probe.address}_run_{mode}_test"

    async def async_press(self) -> None:
        self.probe.async_schedule_test(self.mode)


class CancelTestButton(XzenseLabEntity, ButtonEntity):
    _attr_name = "Cancel test"

    def __init__(self, probe: XzenseLabProbe) -> None:
        super().__init__(probe)
        self._attr_unique_id = f"{probe.address}_cancel_test"

    async def async_press(self) -> None:
        self.probe.async_cancel_test()
