"""Shared entity base for Xzense Lab."""
from __future__ import annotations

from homeassistant.helpers.device_registry import CONNECTION_BLUETOOTH, DeviceInfo
from homeassistant.helpers.entity import Entity

from .const import DOMAIN
from .probe import XzenseLabProbe


class XzenseLabEntity(Entity):
    _attr_has_entity_name = True

    def __init__(self, probe: XzenseLabProbe) -> None:
        self.probe = probe
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, probe.address)},
            name=probe.name,
            manufacturer="Exodraft",
            model="Xzense Lab (one-shot tester)",
            connections={(CONNECTION_BLUETOOTH, probe.address)},
        )

    async def async_added_to_hass(self) -> None:
        self.async_on_remove(self.probe.async_add_listener(self.async_write_ha_state))
