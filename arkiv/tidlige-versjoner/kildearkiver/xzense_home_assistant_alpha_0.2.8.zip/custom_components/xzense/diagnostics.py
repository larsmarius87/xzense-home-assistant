"""Diagnostics support for Xzense."""

from __future__ import annotations

from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from .client import XzenseClient
from .const import DOMAIN


async def async_get_config_entry_diagnostics(
    hass: HomeAssistant, entry: ConfigEntry
) -> dict[str, Any]:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    state = client.state
    frame = state.last_frame
    return {
        "address": client.address,
        "connected": state.connected,
        "ble_link_connected": state.ble_link_connected,
        "notifications_active": state.notifications_active,
        "phase": state.phase,
        "phase_changed_at": state.phase_changed_at,
        "ble_connected_at": state.ble_connected_at,
        "notify_started_at": state.notify_started_at,
        "notify_active_at": state.notify_active_at,
        "last_notification_at": state.last_notification_at,
        "last_disconnect_at": state.last_disconnect_at,
        "pin_configured": bool(client.pin),
        "packet_count": state.packet_count,
        "notification_count": state.notification_count,
        "last_notification": state.last_notification.hex(),
        "last_frame": frame.hex if frame else None,
        "last_payload": frame.payload_hex if frame else None,
        "last_outer_type": f"0x{frame.outer_type:02x}" if frame else None,
        "last_packet_type": frame.packet_type_name if frame else None,
        "last_protocol_type": frame.protocol_type_name if frame else None,
        "checksum_little_endian": f"0x{frame.checksum:04x}" if frame else None,
        "discarded_bytes": state.discarded_bytes,
        "invalid_frames": state.invalid_frames,
        "crc_errors": state.crc_errors,
        "connection_attempts": state.connection_attempts,
        "disconnect_count": state.disconnect_count,
        "advertisement_count": state.advertisement_count,
        "advertisement_waits": state.advertisement_waits,
        "advertisement_timeouts": state.advertisement_timeouts,
        "last_advertisement_at": state.last_advertisement_at,
        "last_advertisement_rssi": state.last_advertisement_rssi,
        "last_advertisement_source": state.last_advertisement_source,
        "last_advertisement_name": state.last_advertisement_name,
        "last_advertisement_connectable": state.last_advertisement_connectable,
        "candidate_source_count": state.candidate_source_count,
        "candidate_sources": state.candidate_sources,
        "selected_source": state.selected_source,
        "selected_source_rssi": state.selected_source_rssi,
        "source_connection_attempts": state.source_connection_attempts,
        "source_fallbacks": state.source_fallbacks,
        "last_failed_source": state.last_failed_source,
        "pairing_attempts": state.pairing_attempts,
        "pairing_success": state.pairing_success,
        "pairing_last_error": state.pairing_last_error,
        "authorization_retries": state.authorization_retries,
        "ble_pairing_strategy": "disabled_collect_sources_rank_by_rssi_then_connect_notify",
        "advertisement_wait_timeout_seconds": 45,
        "adapter_collection_window_seconds": 6,
        "source_selection": "strongest_rssi_first_then_fallback",
        "connect_attempts_per_source": 1,
        "notify_timeout_seconds": 10,
        "tx_count": state.tx_count,
        "tx_chunk_count": state.tx_chunk_count,
        "last_tx": state.last_tx.hex(),
        "last_tx_at": state.last_tx_at,
        "tx_write_mode": state.tx_write_mode,
        "tx_chunk_size": state.tx_chunk_size,
        "application_auth_state": state.application_auth_state,
        "application_connect_attempts": state.application_connect_attempts,
        "application_auth_success_count": state.application_auth_success_count,
        "handshake_sent_at": state.handshake_sent_at,
        "handshake_response_at": state.handshake_response_at,
        "handshake_last_error": state.handshake_last_error,
        "session_id": f"0x{state.session_id:08x}" if state.session_id is not None else None,
        "connect_ack_version": state.connect_ack_version,
        "connect_ack_flag": state.connect_ack_flag,
        "last_error": state.last_error,
        "application_pin_auth_enabled": True,
        "application_connect_only": True,
        "application_time_field": 0,
        "application_client_name": "HomeAssistant",
        "control_writes_enabled": False,
        "diagnostic_entities_enabled_by_default": True,
    }
