"""Constants for the Xzense integration."""

from __future__ import annotations

import re

DOMAIN = "xzense"
NAME = "Xzense"

# Dialog/Renesas DSPS (Serial Port Service) UUIDs recovered from Xzense 5.0.2.
SERVICE_UUID = "0783b03e-8535-b5a0-7140-a304d2495cb7"
NOTIFY_UUID = "0783b03e-8535-b5a0-7140-a304d2495cb8"  # Server TX -> phone/HA
WRITE_UUID = "0783b03e-8535-b5a0-7140-a304d2495cba"   # Server RX <- phone/HA

CONF_NAME = "name"
CONF_PIN = "pin"
DEFAULT_NAME = "Xzense"

# The Xzense panel displays the Bluetooth/application PIN as four hexadecimal
# characters, e.g. 5FF0 in Exodraft's manual.
PIN_PATTERN = re.compile(r"^[0-9A-F]{4}$")

PLATFORMS = ["sensor", "binary_sensor"]


def normalize_pin(value: str) -> str | None:
    """Normalize a Xzense PIN, returning None if it is not four hex digits."""
    pin = value.strip().upper()
    return pin if PIN_PATTERN.fullmatch(pin) else None
