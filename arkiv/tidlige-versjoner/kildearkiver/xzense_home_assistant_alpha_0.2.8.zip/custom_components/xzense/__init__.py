"""Xzense Home Assistant integration (experimental protocol monitor)."""

from __future__ import annotations

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_ADDRESS, Platform
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed
from homeassistant.helpers import entity_registry as er

from .client import XzenseClient
from .const import CONF_NAME, CONF_PIN, DEFAULT_NAME, DOMAIN

PLATFORMS = [Platform.SENSOR, Platform.BINARY_SENSOR]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up Xzense from a config entry."""
    if not entry.data.get(CONF_PIN):
        raise ConfigEntryAuthFailed("Xzense PIN is required")

    hass.data.setdefault(DOMAIN, {})

    client = XzenseClient(
        hass,
        entry,
        entry.data[CONF_ADDRESS],
        entry.data.get(CONF_NAME, entry.title or DEFAULT_NAME),
        entry.data[CONF_PIN],
    )
    hass.data[DOMAIN][entry.entry_id] = client

    # v0.2.4 enables every diagnostic entity by default. Migrate registry
    # entries *before* platform setup so sensors disabled by older alpha builds
    # are instantiated immediately on this same reload/restart. Preserve any
    # entity the user explicitly disabled themselves.
    registry = er.async_get(hass)
    for entity_entry in er.async_entries_for_config_entry(registry, entry.entry_id):
        if entity_entry.disabled_by == er.RegistryEntryDisabler.INTEGRATION:
            registry.async_update_entity(entity_entry.entity_id, disabled_by=None)

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    await client.async_start()
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload Xzense."""
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    await client.async_stop()

    unloaded = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unloaded:
        hass.data[DOMAIN].pop(entry.entry_id, None)
    return unloaded
