import importlib.util
from pathlib import Path
import sys

PROTOCOL_PATH = Path(__file__).parents[1] / "custom_components" / "xzense" / "protocol.py"
spec = importlib.util.spec_from_file_location("xzense_protocol_test", PROTOCOL_PATH)
protocol = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = protocol
spec.loader.exec_module(protocol)

XzenseFrameParser = protocol.XzenseFrameParser
build_connect_request = protocol.build_connect_request
build_frame = protocol.build_frame
crc16_ccitt_false = protocol.crc16_ccitt_false


def test_crc_known_vector():
    assert crc16_ccitt_false(b"123456789") == 0x29B1


def test_frame_roundtrip():
    raw = build_frame(0x06, bytes.fromhex("020a0102030405060708"))
    parser = XzenseFrameParser()
    frames = parser.feed(raw)
    assert len(frames) == 1
    frame = frames[0]
    assert frame.outer_type == 0x06
    assert frame.packet_type == 0x02
    assert frame.protocol_type == 0x0A
    assert frame.session_id == 0x04030201
    assert parser.invalid_frames == 0


def test_reserved_bytes_are_escaped_and_roundtrip():
    payload = bytes((0x23, 0x24, 0x27, 0x01))
    raw = build_frame(0x06, payload)
    assert bytes.fromhex("27a3") in raw
    assert bytes.fromhex("27a4") in raw
    assert bytes.fromhex("27a7") in raw
    parser = XzenseFrameParser()
    assert parser.feed(raw)[0].payload == payload


def test_fragmented_notifications():
    raw = build_frame(0x06, b"abcdef")
    parser = XzenseFrameParser()
    assert parser.feed(raw[:4]) == []
    assert parser.feed(raw[4:9]) == []
    frames = parser.feed(raw[9:])
    assert len(frames) == 1
    assert frames[0].payload == b"abcdef"


def test_connect_request_pin_zero_safe_time():
    raw = build_connect_request("0000", "HomeAssistant")
    # body size: network/type (2) + inner packet (22) = 24 = 0x0018
    assert raw == bytes.fromhex(
        "2318000006020b0000000000000d486f6d65417373697374616e74254d24"
    )
    frame = XzenseFrameParser().feed(raw)[0]
    assert frame.payload[:9] == bytes.fromhex("020b0000000000000d")
    assert frame.payload[9:] == b"HomeAssistant"
