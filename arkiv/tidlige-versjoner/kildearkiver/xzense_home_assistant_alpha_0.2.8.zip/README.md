# Xzense Home Assistant – alpha 0.2.7

Experimental local Bluetooth integration for Exodraft Xzense.

## v0.2.8 changes

This build moves from BLE-only discovery to the first verified Xzense application-protocol handshake.

- Keeps the v0.2.6 fresh-advertisement and strongest-source BLE connection strategy.
- Keeps Bluetooth pairing/bonding disabled.
- Enables DSPS notifications on `...5CB8`.
- Immediately sends the recovered **CONNECT/REQ** application frame to `...5CBA` using the configured four-hex-digit Xzense PIN.
- Uses Xzense's recovered CRC-16/CCITT-FALSE framing and byte escaping.
- Sets the CONNECT time field to **zero**, so this test does not change the Xzense controller clock.
- Sends client name `HomeAssistant`.
- Parses CONNECT/ACK and CONNECT/NACK replies.
- Extracts the returned session ID, protocol/version word and ACK flag when CONNECT succeeds.
- Supports BLE notification fragmentation and write fragmentation according to the characteristic's write-without-response size.
- Keeps **all diagnostic entities enabled by default**.
- Still sends **no fan, ventilation, speed, temperature-setting, factory-reset or other control commands**.

## Expected test sequence

1. Wait for a fresh connectable Xzense advertisement.
2. Collect visible Bluetooth sources for 6 seconds and rank by RSSI.
3. Establish GATT connection through the strongest source.
4. Subscribe to Xzense DSPS notifications.
5. Send one application CONNECT/REQ using the stored PIN.
6. If accepted, Xzense should answer CONNECT/ACK and a session ID should appear in diagnostics.
7. If rejected, diagnostics should show CONNECT/NACK or a disconnect-before-ACK state.

## Most useful diagnostics for this build

- `Application authentication state`
- `Application CONNECT attempts`
- `Application authentication successes`
- `Application session ID`
- `CONNECT ACK version`
- `CONNECT ACK flag`
- `Application handshake sent time`
- `Application handshake response time`
- `Application handshake error`
- `Application TX frames`
- `Application TX chunks`
- `Last application TX`
- `BLE notifications`
- `Last BLE notification`
- `Valid protocol frames`
- `Last application packet type`
- `Last application protocol type`
- `Protocol CRC errors`
- `Last Bluetooth error`

## Install / upgrade

Copy `custom_components/xzense` over the existing Xzense custom component and restart Home Assistant. Existing config entries and the stored PIN are retained.

## v0.2.8 connection timing change

Xzense is now connected **immediately on the first fresh connectable BLE advertisement**.
The previous 6-second adapter collection window has been removed. Diagnostics from the
test unit showed only one Bluetooth source, so the delay offered no fallback benefit and
could cause the GATT connection attempt to start too late. The recovered application
CONNECT/PIN handshake from v0.2.7 is unchanged.
