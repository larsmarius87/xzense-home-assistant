# Xzense protocol notes – alpha 0.2.7

These notes are based on reverse engineering the Xzense 5.0.2 Android package and its bundled Silicon Labs controller firmware (`v4.9_RC1`).

## BLE service

- Service: `0783b03e-8535-b5a0-7140-a304d2495cb7`
- Notify / server TX: `0783b03e-8535-b5a0-7140-a304d2495cb8`
- Write / server RX: `0783b03e-8535-b5a0-7140-a304d2495cba`

## Outer serial frame

Logical frame before escaping:

```text
23 | SIZE_LE16 | 00 | OUTER_TYPE | PAYLOAD | CRC16_LE | 24
```

- `0x23` = start marker (`#`)
- `SIZE` = bytes in `network protocol + outer type + payload`
- network protocol = `0x00`
- application/peer outer type = `0x06`
- CRC = CRC-16/CCITT-FALSE, poly `0x1021`, init `0xFFFF`, no reflection, xorout `0`
- CRC covers `00 | OUTER_TYPE | PAYLOAD`
- CRC is serialized little-endian
- `0x24` = end marker (`$`)

Reserved payload/CRC bytes are escaped:

- `23` -> `27 A3`
- `24` -> `27 A4`
- `27` -> `27 A7`

## Inner application packet

The application payload starts with:

```text
PACKET_TYPE | PROTOCOL_TYPE | application payload...
```

Relevant values recovered from firmware:

- packet `0x02` = CONNECT
- protocol `0x09` = NACK
- protocol `0x0A` = ACK
- protocol `0x0B` = REQ

## CONNECT/REQ used in v0.2.8

```text
02 0B
PIN_LE16
00 00 00 00          # time field deliberately disabled
NAME_LEN
NAME_ASCII
```

For PIN `0000` and client name `HomeAssistant`, the exact wire frame is:

```text
23 18 00 00 06 02 0B 00 00 00 00 00 00 0D
48 6F 6D 65 41 73 73 69 73 74 61 6E 74 25 4D 24
```

The final `25 4D` is the little-endian CRC (`0x4D25`).

The zero 32-bit field is intentional. Firmware only invokes its system-time update path when this field is non-zero, so the experimental handshake cannot change controller time.

## CONNECT/ACK

Firmware constructs a 10-byte inner response:

```text
02 0A | SESSION_ID_LE32 | VERSION_OR_PROTOCOL_LE16 | FLAG | 00
```

Alpha 0.2.7 records these values but does not yet use the session for any control command.

## Safety boundary

This build sends only CONNECT/REQ. It does not issue fan, ventilation, speed, configuration, time, file-transfer, factory-reset or other operational commands.


## v0.2.8 BLE timing

The deliberate 6-second post-advertisement adapter collection delay was removed.
The client now attempts GATT connection immediately after the first fresh connectable
advertisement. This does not change the recovered application protocol or CONNECT frame.
