# Xzense Full Preview 0.4.1 — feature matrix

The Home Assistant-side entity model is created up front. Features can move from pending to active as their wire mapping is confirmed.

## Live/read paths

| Function | HA entity | Protocol status |
|---|---|---|
| BLE link | Binary sensor | Implemented |
| Xzense application session | Binary sensor | Implemented |
| Device state | Sensor | **Verified read**: STATUS + GLOBAL `0x19` match |
| Chimney state | Sensor | **Verified read**: STATUS + GLOBAL `0x1A` match |
| State timer | Sensor | **Verified read**: STATUS + GLOBAL `0x1B` match |
| Air pressure | Sensor | **Verified read**: STATUS + GLOBAL `0x1C` match |
| Inside temperature | Sensor | **Verified read**: STATUS + GLOBAL `0x1D` match |
| Outside temperature | Sensor | **Verified read**: STATUS + GLOBAL `0x1E` match |
| Chimney temperature | Sensor | **Verified read**: STATUS + GLOBAL `0x1F` match |
| Fan speed | Sensor | **Verified read** from GLOBAL `0x20` |
| Chimney draught / actual draft | Sensor | Global ID `0x51` known; raw |
| Signal strength / battery | Sensors | Global IDs known; raw |

The final byte of STATUS is exposed in diagnostics as raw `status_flags`; its bit meanings are not mapped yet.

## Control/settings model already scaffolded

These entities are present but intentionally unavailable until their action semantics/scaling are verified.

| Function | HA entity | Known protocol information |
|---|---|---|
| Start fire | Button | App function known; packet mapping pending |
| Stop fire | Button | App function known; packet mapping pending |
| Refueling | Button | App function known; packet mapping pending |
| Boost | Button | App function known; packet mapping pending |
| Ventilation | Switch | Packet type `0x09` known; payload mapping pending |
| Manual fan speed | Number | Global `0x52 USER_FAN_SPEED` known |
| Boost fan speed | Number | Global `0x50 BOOST_FAN_SPEED` known |
| System control | Select | Global `0x56`; Manual / Pressure controlled / eXotelligence exposed |
| Auto start temperature | Number | Global `0x4C` known |
| Auto stop temperature | Number | Global `0x4D` known |
| Boost time | Number | Global `0x4E` known |
| After-run time | Number | Global `0x4F` known |
| Boost stop temperature | Number | Global `0x53` known |
| Wanted draught | Number | Global `0x54` known |
| Minimum fan voltage | Number | Global `0x55` known |
| Temperature sensor selection | Select | Global `0x57` known; option encoding pending |
| External start | Switch | Global `0x58` known |
| Alarm setpoint | Number | Global `0x59` known |
| Refire time | Number | Global `0x5A` known |
| External fan speed | Number | Global `0x5B` known |

## Other app features scaffolded

- Burn count — sensor placeholder
- Operation time — sensor placeholder
- Weather station — binary-sensor placeholder
- Error log — sensor placeholder
- Firmware update — `update` entity placeholder
- Log download — button placeholder
- History — intended to use Home Assistant's native history/statistics
- PIN — config-flow/reauth/reconfigure support

## Safety rule

`CONTROL_WRITES_ENABLED = False`. 0.4.1 changes the read decoder only and does not enable new physical-control writes.
