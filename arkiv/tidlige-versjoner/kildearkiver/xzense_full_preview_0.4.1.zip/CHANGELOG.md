# Changelog

## 0.4.1

- Corrects STATUS decoding from the earlier 19-byte hypothesis to the **14-byte live STATUS/ACK payload** observed on the real controller.
- Verifies the STATUS field order by matching one STATUS/ACK byte-for-byte against the GLOBAL/DATA packet received immediately beforehand.
- STATUS now decodes: device state, chimney state, chimney temperature, outside temperature, inside temperature, pressure, state timer and one final flags byte.
- Fan speed is no longer incorrectly read from STATUS; it remains sourced from verified GLOBAL `0x20 FAN_SPEED`.
- `status_response_count`, `last_status_response_at`, `last_status_payload` and `decoded_status` now update for the live STATUS/ACK frames seen in diagnostics.
- Pressure, device state, chimney state and state timer are promoted to `verified_read` because the live STATUS values matched their corresponding GLOBAL values.
- Adds a regression test using the exact captured STATUS/ACK frame from the controller.
- Keeps `CONTROL_WRITES_ENABLED = False`; this release changes read/diagnostic decoding only.

## 0.4.0

- New separate domain: `xzense_full_preview`.
- Preserves the authenticated BLE/session/status implementation from the working 0.3 branch.
- Adds complete Home Assistant platform scaffolding for app-visible Xzense functions.
- Adds buttons for Start fire, Stop fire, Refueling, Boost and Download log.
- Adds switches for Ventilation and External start.
- Adds number entities for fan/draft/temperature/time settings whose firmware global IDs are known.
- Adds System control select with Manual, Pressure controlled and eXotelligence options.
- Adds weather-station, burn-count, operation-time, error-log and firmware placeholders.
- Adds firmware `update` entity scaffold.
- Adds a generic GLOBAL/REQ encoder verified against the public BLE capture.
- Keeps all unverified control writes globally safety-gated (`CONTROL_WRITES_ENABLED = False`).
- Reconfigure PIN form no longer pre-fills the stored PIN.
