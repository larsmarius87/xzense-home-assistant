# Xzense Full Preview 0.4.1

A development Home Assistant integration for Exodraft Xzense that builds the **full entity model up front** while keeping unverified appliance-control writes safety-gated.

## What is functional

- Bluetooth discovery through Home Assistant Bluetooth / ESPHome Bluetooth Proxy
- Xzense DSPS GATT transport
- Application PIN `CONNECT/REQ` and `CONNECT/ACK` session handling
- Session ID handling
- CRC-16/CCITT-FALSE and Xzense byte escaping
- Notifications and validated frame parsing
- `STATUS/REQ` polling every 10 seconds after an authenticated session
- **Live-verified 14-byte STATUS/ACK decoding** for device state, chimney state, chimney temperature, outside temperature, inside temperature, pressure and state timer
- Fan speed from `GLOBAL 0x20`
- GLOBAL/DATA decoding and cache
- Generic GLOBAL/REQ frame builder
- Extensive diagnostics and short packet history

## 0.4.1 STATUS correction

0.4.0 expected a 19-byte status body, so the controller's valid STATUS/ACK replies were visible in packet history but `status_response_count` remained zero. 0.4.1 uses the 14-byte layout proven by the live STATUS and GLOBAL packets from the same controller.

Raw values are deliberately retained; no additional scaling is guessed in this release.

## Full app-style entity set

The integration contains sensor, binary_sensor, button, switch, number, select and update platforms. See `FEATURE_MATRIX.md` for every feature and its protocol readiness.

Unverified controls remain unavailable because `CONTROL_WRITES_ENABLED = False`. The entity/UI plumbing is in place, while this release concentrates on making the live read path correct.

## Side-integration rule

Domain: `xzense_full_preview`.

It can be installed alongside other Xzense custom-component folders, but it refuses to start its BLE client while `xzense` or `xzense_preview` is loaded. Disable/unload the other Xzense integration before reloading Full Preview.

## PIN

Setup asks for the current four-character hexadecimal PIN shown by Xzense. Reconfigure asks for a fresh PIN and does not pre-fill the old value.
