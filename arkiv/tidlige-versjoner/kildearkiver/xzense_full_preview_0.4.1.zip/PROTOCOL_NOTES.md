# Xzense Full Preview 0.4.1 — protocol notes

## BLE transport

Service: `0783b03e-8535-b5a0-7140-a304d2495cb7`

- Notify/TX from Xzense: `0783b03e-8535-b5a0-7140-a304d2495cb8`
- Write/RX to Xzense: `0783b03e-8535-b5a0-7140-a304d2495cba`

The four-character Xzense PIN is part of the Xzense application protocol, not standard BLE pairing.

## Frame

Unescaped logical frame:

`23 | size_le16 | 00 | outer_type | payload | crc16_le | 24`

CRC is CRC-16/CCITT-FALSE over `00 | outer_type | payload`. Reserved bytes `23`, `24`, `27` are escaped in payload/CRC as `27, byte|80`.

## Application packet

Outer type `06` carries:

`packet_type | protocol_type | application_payload`

Known protocol types: DATA=`08`, NACK=`09`, ACK=`0A`, REQ=`0B`.

## CONNECT

`02 0B | pin_le16 | time_u32 | name_len | ASCII name`

A successful ACK returns a session ID used by subsequent application messages.

## STATUS read — live verified in 0.4.1

Request:

`07 0B | session_id_le32`

The real controller replied with `STATUS/ACK` and a **14-byte** application payload. One observed payload was:

`04 b3 04 64 00 36 01 35 00 d4 00 f3 03 00`

A GLOBAL/DATA packet received immediately beforehand exposed the matching values, allowing the layout to be verified without guessing:

| STATUS bytes | Decoded value | Matching GLOBAL |
|---|---:|---|
| `04` | 4 | `0x19 MY_STATE` |
| `b3 04` | 1203 | `0x1A CHIMNEY_STATE` |
| `64 00` | 100 | `0x1F CHIMNEY_TEMP` |
| `36 01` | 310 | `0x1E OUTSIDE_TEMP` |
| `35 00` | 53 | `0x1D INSIDE_TEMP` |
| `d4 00` | 212 | `0x1C PRESSURE` |
| `f3 03` | 1011 | `0x1B STATE_TIMER` |
| `00` | 0 | final flags byte; meaning not yet mapped |

Fan speed is **not present** in this 14-byte STATUS payload. It remains read from `GLOBAL 0x20 FAN_SPEED`. Raw numeric scaling is preserved until separately verified.

## GLOBAL read/write transport

GLOBAL/DATA is decoded as repeated entries:

`global_id_u8 | value_i16_le`

The generic GLOBAL/REQ write envelope is:

`06 0B | session_id_le32 | global_id_u8 | value_i16_le`

The encoder is implemented, but individual control semantics/scaling remain safety-gated.

## Known global IDs used by the feature scaffold

- `18` SIGNAL_STRENGTH
- `19` MY_STATE — live matched to STATUS
- `1A` CHIMNEY_STATE — live matched to STATUS
- `1B` STATE_TIMER — live matched to STATUS
- `1C` PRESSURE — live matched to STATUS
- `1D` INSIDE_TEMP — live matched to STATUS
- `1E` OUTSIDE_TEMP — live matched to STATUS
- `1F` CHIMNEY_TEMP — live matched to STATUS
- `20` FAN_SPEED — live GLOBAL read
- `4C` AUTO_START_TEMP
- `4D` AUTO_STOP_TEMP
- `4E` BOOST_TIME
- `4F` AFTERRUN_TIME
- `50` BOOST_FAN_SPEED
- `51` ACTUAL_DRAFT
- `52` USER_FAN_SPEED
- `53` BOOST_STOP_TEMP
- `54` WANTED_DRAFT
- `55` MIN_FAN_VOLTAGE
- `56` SYSTEM_CONTROL
- `57` TEMPERATURE_SENSOR
- `58` EXTERN_START
- `59` ALARM_SETPOINT
- `5A` REBOOST_TIME
- `5B` EXTERN_FAN_SPEED

Packet type `09` is VENTILATION; its application payload is not yet mapped.
