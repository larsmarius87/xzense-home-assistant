# Xzense Home Assistant – alpha 0.2.4

Experimental local Bluetooth integration for Exodraft Xzense.

## v0.2.4 changes

- Removed explicit BLE `pair()` / bonding from the connection sequence.
- Connects normally and enables notifications immediately.
- Keeps the Xzense application PIN in the config entry, but does **not** send it yet.
- Adds raw RX timing and application-TX diagnostic counters for protocol discovery.
- Enables **all diagnostic entities by default**.
- On upgrade, entities that older alpha builds disabled by the integration are automatically enabled. Entities explicitly disabled by the user remain untouched.

## Current connection sequence

1. Discover connectable Xzense advertisement.
2. Establish normal BLE/GATT connection.
3. Subscribe to DSPS TX notifications (`...5CB8`).
4. Wait for protocol traffic.

No application-protocol writes or fan-control commands are sent in this build.
