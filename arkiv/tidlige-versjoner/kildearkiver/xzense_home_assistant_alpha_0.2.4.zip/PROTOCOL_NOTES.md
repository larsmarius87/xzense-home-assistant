# Xzense protocol discovery notes – 0.2.4

Known Dialog/Renesas DSPS UUIDs recovered from Xzense 5.0.2:

- Service: `0783b03e-8535-b5a0-7140-a304d2495cb7`
- Notify / server TX: `0783b03e-8535-b5a0-7140-a304d2495cb8`
- Write / server RX: `0783b03e-8535-b5a0-7140-a304d2495cba`

Real-device testing with 0.2.3 showed:

- ordinary BLE/GATT connect succeeds;
- explicit `client.pair()` times out after 12 s;
- notification subscription can still succeed after that timeout;
- the peripheral then remains connected for roughly 20 s while sending zero notifications before disconnecting.

Therefore 0.2.4 removes explicit BLE pairing and subscribes immediately. It still sends no application frames. The next protocol step is to identify the official app's first write to `...5CBA`, including any PIN/authentication, SEQ and checksum semantics.
