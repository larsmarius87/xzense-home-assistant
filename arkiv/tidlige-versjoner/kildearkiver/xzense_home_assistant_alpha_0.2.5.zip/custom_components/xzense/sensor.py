"""Diagnostic sensors for Xzense protocol discovery."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from homeassistant.components.sensor import SensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient, XzenseState
from .const import DOMAIN
from .entity import XzenseEntity


@dataclass(frozen=True, slots=True)
class SensorDescription:
    key: str
    name: str
    value_fn: Callable[[XzenseState], Any]
    enabled_default: bool = True


SENSORS = (
    SensorDescription("phase", "Bluetooth setup phase", lambda s: s.phase),
    SensorDescription("ble_link_connected", "BLE link connected", lambda s: s.ble_link_connected),
    SensorDescription("notifications_active", "BLE notifications active", lambda s: s.notifications_active),
    SensorDescription("packet_count", "Valid protocol frames", lambda s: s.packet_count),
    SensorDescription(
        "last_payload",
        "Last protocol payload",
        lambda s: s.last_frame.payload_hex if s.last_frame else None,
    ),
    SensorDescription(
        "last_frame",
        "Last protocol frame",
        lambda s: s.last_frame.hex if s.last_frame else None,
    ),
    SensorDescription(
        "last_notification",
        "Last BLE notification",
        lambda s: s.last_notification.hex() if s.last_notification else None,
    ),
    SensorDescription("last_notification_at", "Last BLE notification time", lambda s: s.last_notification_at),
    SensorDescription("notification_count", "BLE notifications", lambda s: s.notification_count),
    SensorDescription("discarded_bytes", "Discarded protocol bytes", lambda s: s.discarded_bytes),
    SensorDescription("invalid_frames", "Invalid protocol frames", lambda s: s.invalid_frames),
    SensorDescription("connection_attempts", "Bluetooth connection attempts", lambda s: s.connection_attempts),
    SensorDescription("disconnect_count", "Bluetooth disconnects", lambda s: s.disconnect_count),
    SensorDescription("advertisement_count", "Fresh BLE advertisements", lambda s: s.advertisement_count),
    SensorDescription("advertisement_waits", "Advertisement waits", lambda s: s.advertisement_waits),
    SensorDescription("advertisement_timeouts", "Advertisement wait timeouts", lambda s: s.advertisement_timeouts),
    SensorDescription("last_advertisement_at", "Last fresh advertisement time", lambda s: s.last_advertisement_at),
    SensorDescription("last_advertisement_rssi", "Last advertisement RSSI", lambda s: s.last_advertisement_rssi),
    SensorDescription("last_advertisement_source", "Last advertisement adapter", lambda s: s.last_advertisement_source),
    SensorDescription("last_advertisement_name", "Last advertisement name", lambda s: s.last_advertisement_name),
    SensorDescription("last_advertisement_connectable", "Last advertisement connectable", lambda s: s.last_advertisement_connectable),
    SensorDescription("pairing_attempts", "Bluetooth pairing attempts", lambda s: s.pairing_attempts),
    SensorDescription("pairing_success", "Bluetooth pairing succeeded", lambda s: s.pairing_success),
    SensorDescription("pairing_last_error", "Last Bluetooth pairing error", lambda s: s.pairing_last_error),
    SensorDescription("authorization_retries", "GATT authorization retries", lambda s: s.authorization_retries),
    SensorDescription("tx_count", "Application TX frames", lambda s: s.tx_count),
    SensorDescription("last_tx", "Last application TX", lambda s: s.last_tx.hex() if s.last_tx else None),
    SensorDescription("last_tx_at", "Last application TX time", lambda s: s.last_tx_at),
    SensorDescription("last_error", "Last Bluetooth error", lambda s: s.last_error),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(XzenseDiagnosticSensor(client, description) for description in SENSORS)


class XzenseDiagnosticSensor(XzenseEntity, SensorEntity):
    """A read-only diagnostic value from the protocol monitor."""

    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, client: XzenseClient, description: SensorDescription) -> None:
        super().__init__(client)
        self.description = description
        self._attr_name = description.name
        self._attr_unique_id = f"{client.address}_{description.key}"
        self._attr_entity_registry_enabled_default = description.enabled_default

    @property
    def native_value(self) -> Any:
        return self.description.value_fn(self.client.state)
