"""Bluetooth client for Xzense."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
import logging

from bleak.backends.characteristic import BleakGATTCharacteristic
from bleak_retry_connector import BleakClientWithServiceCache, establish_connection

from homeassistant.components import bluetooth
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback

from .const import NOTIFY_UUID
from .protocol import XzenseFrame, XzenseFrameParser

_LOGGER = logging.getLogger(__name__)

Listener = Callable[[], None]

NOTIFY_TIMEOUT = 10.0
ADVERTISEMENT_WAIT_TIMEOUT = 45.0


def _utc_now() -> str:
    """Return an ISO-8601 UTC timestamp for diagnostics."""
    return datetime.now(UTC).isoformat(timespec="milliseconds")


@dataclass(slots=True)
class XzenseState:
    """Runtime state exposed by the experimental read-only integration."""

    connected: bool = False
    ble_link_connected: bool = False
    notifications_active: bool = False
    phase: str = "idle"
    phase_changed_at: str | None = None
    ble_connected_at: str | None = None
    notify_started_at: str | None = None
    notify_active_at: str | None = None
    last_notification_at: str | None = None
    last_disconnect_at: str | None = None
    packet_count: int = 0
    notification_count: int = 0
    last_notification: bytes = b""
    last_frame: XzenseFrame | None = None
    last_error: str | None = None
    discarded_bytes: int = 0
    invalid_frames: int = 0
    connection_attempts: int = 0
    disconnect_count: int = 0

    # Fresh-advertisement connection diagnostics (v0.2.5).
    advertisement_count: int = 0
    advertisement_waits: int = 0
    advertisement_timeouts: int = 0
    last_advertisement_at: str | None = None
    last_advertisement_rssi: int | None = None
    last_advertisement_source: str | None = None
    last_advertisement_name: str | None = None
    last_advertisement_connectable: bool | None = None

    # Kept for backwards-compatible diagnostics while BLE pairing is disabled.
    pairing_attempts: int = 0
    pairing_success: bool = False
    pairing_last_error: str | None = None
    authorization_retries: int = 0

    # TX discovery diagnostics. v0.2.5 does not transmit application frames yet.
    tx_count: int = 0
    last_tx: bytes = b""
    last_tx_at: str | None = None


class XzenseClient:
    """Maintain a BLE connection and parse Xzense notifications.

    v0.2.5 deliberately does not request Bluetooth pairing/bonding. It also
    avoids connecting from a stale cached BLEDevice. Before every connection
    attempt it clears Home Assistant's advertisement de-duplication history,
    waits for a new connectable advertisement from this exact Xzense address,
    and immediately connects using the BLEDevice carried by that advertisement.
    Only one GATT connection attempt is made per advertisement; a failure sends
    us back to waiting for the next fresh advertisement instead of retrying a
    stale device object for ~60 seconds.

    No Xzense application-protocol PIN or control writes are sent yet. The PIN
    stored in the config entry is retained for the later application-auth layer
    once the first app->Xzense frame and its framing/CRC/sequence semantics are
    proven.
    """

    def __init__(
        self,
        hass: HomeAssistant,
        entry: ConfigEntry,
        address: str,
        name: str,
        pin: str,
    ) -> None:
        self.hass = hass
        self.entry = entry
        self.address = address
        self.name = name
        self.pin = pin
        self.state = XzenseState()
        self._parser = XzenseFrameParser()
        self._listeners: set[Listener] = set()
        self._client: BleakClientWithServiceCache | None = None
        self._runner: asyncio.Task[None] | None = None
        self._wake = asyncio.Event()
        self._stopping = False

    @callback
    def async_add_listener(self, listener: Listener) -> Callable[[], None]:
        self._listeners.add(listener)

        @callback
        def remove_listener() -> None:
            self._listeners.discard(listener)

        return remove_listener

    @callback
    def _notify_listeners(self) -> None:
        for listener in tuple(self._listeners):
            listener()

    def _set_phase(self, phase: str) -> None:
        """Update the connection phase and expose it immediately."""
        if self.state.phase == phase:
            return
        self.state.phase = phase
        self.state.phase_changed_at = _utc_now()
        _LOGGER.debug("Xzense %s phase: %s", self.address, phase)
        self._notify_listeners()

    async def async_start(self) -> None:
        """Start the connection manager without blocking config-entry setup."""
        if self._runner and not self._runner.done():
            return
        self._stopping = False
        self._set_phase("starting")
        self._runner = self.entry.async_create_background_task(
            self.hass, self._connection_loop(), f"xzense-{self.address}"
        )

    async def async_stop(self) -> None:
        """Stop reconnects, notifications and the BLE connection."""
        self._stopping = True
        self._wake.set()

        runner = self._runner
        self._runner = None
        if runner:
            runner.cancel()
            try:
                await runner
            except asyncio.CancelledError:
                pass

        client = self._client
        self._client = None
        if client and client.is_connected:
            if self.state.notifications_active:
                try:
                    await client.stop_notify(NOTIFY_UUID)
                except Exception:  # best-effort during unload
                    pass
            try:
                await client.disconnect()
            except Exception:  # best-effort during unload
                pass

        self.state.connected = False
        self.state.ble_link_connected = False
        self.state.notifications_active = False
        self._set_phase("stopped")
        self._notify_listeners()

    async def _connection_loop(self) -> None:
        """Wait for fresh advertisements and reconnect while loaded."""
        try:
            while not self._stopping:
                if not self._client or not self._client.is_connected:
                    connected = await self._connect_once()
                    if not connected:
                        # _connect_once() already waited for a fresh advertisement.
                        # Yield briefly, then wait for the *next* advertisement.
                        self._wake.clear()
                        try:
                            await asyncio.wait_for(self._wake.wait(), timeout=1.0)
                        except TimeoutError:
                            pass
                        continue

                self._wake.clear()
                await self._wake.wait()
        except asyncio.CancelledError:
            raise

    def _record_advertisement(
        self, service_info: bluetooth.BluetoothServiceInfoBleak
    ) -> bool:
        """Record a live Xzense advertisement and accept it immediately."""
        self.state.advertisement_count += 1
        self.state.last_advertisement_at = _utc_now()
        self.state.last_advertisement_rssi = service_info.rssi
        self.state.last_advertisement_source = service_info.source
        self.state.last_advertisement_name = service_info.name
        self.state.last_advertisement_connectable = service_info.connectable
        self._set_phase("fresh_advertisement")
        _LOGGER.debug(
            "Fresh Xzense advertisement #%d from %s: RSSI=%s source=%s connectable=%s",
            self.state.advertisement_count,
            self.address,
            service_info.rssi,
            service_info.source,
            service_info.connectable,
        )
        self._notify_listeners()
        return True

    async def _wait_for_fresh_advertisement(
        self,
    ) -> bluetooth.BluetoothServiceInfoBleak | None:
        """Wait for a *live* connectable advertisement, never cached replay."""
        self.state.advertisement_waits += 1
        self._set_phase("waiting_for_fresh_advertisement")

        # Xzense appears to repeat identical advertisements. Clearing HA's
        # de-duplication state makes the next identical packet observable.
        bluetooth.async_clear_advertisement_history(self.hass, self.address)

        done: asyncio.Future[bluetooth.BluetoothServiceInfoBleak] = (
            self.hass.loop.create_future()
        )

        @callback
        def _async_fresh_advertisement(
            service_info: bluetooth.BluetoothServiceInfoBleak,
            _change: bluetooth.BluetoothChange,
        ) -> None:
            if done.done():
                return
            self._record_advertisement(service_info)
            done.set_result(service_info)

        cancel_callback = bluetooth.async_register_callback(
            self.hass,
            _async_fresh_advertisement,
            {"address": self.address, "connectable": True},
            bluetooth.BluetoothScanningMode.ACTIVE,
            replay=bluetooth.BluetoothCallbackReplay.DISABLED,
        )

        # Force an immediate active scan on AUTO scanners/proxies. This mirrors
        # Home Assistant's async_process_advertisements behavior but combines it
        # with replay=DISABLED so a cached discovery cannot satisfy our wait.
        scan_task = self.hass.async_create_task(
            bluetooth.async_request_active_scan(ADVERTISEMENT_WAIT_TIMEOUT)
        )

        try:
            async with asyncio.timeout(ADVERTISEMENT_WAIT_TIMEOUT):
                return await done
        except TimeoutError:
            self.state.advertisement_timeouts += 1
            self._set_phase("advertisement_timeout")
            self._set_error(
                f"Timed out after {ADVERTISEMENT_WAIT_TIMEOUT:.0f}s waiting for a fresh "
                "connectable Xzense advertisement"
            )
            return None
        finally:
            cancel_callback()
            scan_task.cancel()

    async def _establish_fresh_connection(self, ble_device):
        """Connect once, immediately after a live advertisement."""
        self._set_phase("connecting_fresh_advertisement")
        client = await establish_connection(
            BleakClientWithServiceCache,
            ble_device,
            ble_device.name or self.name,
            self._disconnected,
            max_attempts=1,
        )
        self._client = client
        self.state.ble_link_connected = bool(client.is_connected)
        self.state.ble_connected_at = _utc_now()
        self._set_phase("ble_connected")
        return client

    async def _connect_once(self) -> bool:
        service_info = await self._wait_for_fresh_advertisement()
        if service_info is None or self._stopping:
            return False

        ble_device = service_info.device
        if ble_device is None:
            self._set_phase("advertisement_without_device")
            self._set_error("Fresh Xzense advertisement did not include a BLEDevice")
            return False

        self.state.connection_attempts += 1
        client: BleakClientWithServiceCache | None = None

        try:
            # One connection attempt against the BLEDevice from the *live* packet.
            # A failure returns us to advertisement waiting instead of retrying a
            # cached device object three times.
            client = await self._establish_fresh_connection(ble_device)

            self.state.notify_started_at = _utc_now()
            self._set_phase("enabling_notifications")
            try:
                await asyncio.wait_for(
                    client.start_notify(NOTIFY_UUID, self._notification),
                    timeout=NOTIFY_TIMEOUT,
                )
            except Exception as notify_err:
                if self._is_authorization_error(notify_err):
                    self.state.authorization_retries += 1
                raise

            self.state.notifications_active = True
            self.state.notify_active_at = _utc_now()
            self.state.connected = True
            self.state.ble_link_connected = bool(client.is_connected)
            self.state.last_error = None
            self._set_phase("notifications_active")
            _LOGGER.info(
                "Connected Xzense protocol monitor to %s after fresh advertisement",
                self.address,
            )
            self._notify_listeners()
            return True

        except Exception as err:
            if client and client.is_connected:
                try:
                    await client.disconnect()
                except Exception:  # best-effort cleanup after failed setup
                    pass

            self._client = None
            self.state.connected = False
            self.state.ble_link_connected = False
            self.state.notifications_active = False
            self._set_phase("error")
            self._set_error(f"{type(err).__name__}: {err}")
            _LOGGER.debug(
                "Unable to connect/subscribe Xzense %s from fresh advertisement",
                self.address,
                exc_info=True,
            )

            # Ensure an identical next Xzense advertisement can wake the next wait.
            bluetooth.async_clear_advertisement_history(self.hass, self.address)
            return False

    @staticmethod
    def _is_authorization_error(err: Exception) -> bool:
        """Return True for the GATT authorization failure seen on Xzense."""
        message = str(err).lower()
        return (
            "insufficient authorization" in message
            or "authorization (8)" in message
            or "gatterrorresponse: insufficient authorization" in message
        )

    def _disconnected(self, _client: BleakClientWithServiceCache) -> None:
        """Bleak disconnected callback."""
        self._client = None
        self.state.connected = False
        self.state.ble_link_connected = False
        self.state.notifications_active = False
        self.state.disconnect_count += 1
        self.state.last_disconnect_at = _utc_now()
        self._set_phase("disconnected")
        self._notify_listeners()
        self._wake.set()

    def _notification(
        self, _characteristic: BleakGATTCharacteristic, data: bytearray
    ) -> None:
        payload = bytes(data)
        self.state.notification_count += 1
        self.state.last_notification = payload
        self.state.last_notification_at = _utc_now()

        _LOGGER.debug(
            "Xzense raw RX notification #%d: %s",
            self.state.notification_count,
            payload.hex(),
        )

        frames = self._parser.feed(payload)
        self.state.discarded_bytes = self._parser.discarded_bytes
        self.state.invalid_frames = self._parser.invalid_frames

        for frame in frames:
            self.state.packet_count += 1
            self.state.last_frame = frame
            _LOGGER.debug(
                "Xzense RX frame #%d: %s payload=%s peer=%s checksum=%04x",
                self.state.packet_count,
                frame.hex,
                frame.payload_hex or "<empty>",
                frame.peer_id_hex,
                frame.checksum,
            )

        self._notify_listeners()

    def _set_error(self, message: str) -> None:
        if self.state.last_error != message:
            self.state.last_error = message
            self.state.connected = False
            self._notify_listeners()
