"""Diagnostics support for Xzense."""

from __future__ import annotations

from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from .client import XzenseClient
from .const import DOMAIN


async def async_get_config_entry_diagnostics(
    hass: HomeAssistant, entry: ConfigEntry
) -> dict[str, Any]:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    state = client.state
    frame = state.last_frame
    return {
        "address": client.address,
        "connected": state.connected,
        "ble_link_connected": state.ble_link_connected,
        "notifications_active": state.notifications_active,
        "phase": state.phase,
        "phase_changed_at": state.phase_changed_at,
        "ble_connected_at": state.ble_connected_at,
        "notify_started_at": state.notify_started_at,
        "notify_active_at": state.notify_active_at,
        "last_notification_at": state.last_notification_at,
        "last_disconnect_at": state.last_disconnect_at,
        "pin_configured": bool(client.pin),
        "packet_count": state.packet_count,
        "notification_count": state.notification_count,
        "last_notification": state.last_notification.hex(),
        "last_frame": frame.hex if frame else None,
        "last_payload": frame.payload_hex if frame else None,
        "peer_id": frame.peer_id_hex if frame else None,
        "checksum_little_endian": f"0x{frame.checksum:04x}" if frame else None,
        "discarded_bytes": state.discarded_bytes,
        "invalid_frames": state.invalid_frames,
        "connection_attempts": state.connection_attempts,
        "disconnect_count": state.disconnect_count,
        "advertisement_count": state.advertisement_count,
        "advertisement_waits": state.advertisement_waits,
        "advertisement_timeouts": state.advertisement_timeouts,
        "last_advertisement_at": state.last_advertisement_at,
        "last_advertisement_rssi": state.last_advertisement_rssi,
        "last_advertisement_source": state.last_advertisement_source,
        "last_advertisement_name": state.last_advertisement_name,
        "last_advertisement_connectable": state.last_advertisement_connectable,
        "pairing_attempts": state.pairing_attempts,
        "pairing_success": state.pairing_success,
        "pairing_last_error": state.pairing_last_error,
        "authorization_retries": state.authorization_retries,
        "ble_pairing_strategy": "disabled_fresh_advertisement_then_connect_then_notify",
        "advertisement_wait_timeout_seconds": 45,
        "connect_attempts_per_advertisement": 1,
        "notify_timeout_seconds": 10,
        "tx_count": state.tx_count,
        "last_tx": state.last_tx.hex(),
        "last_tx_at": state.last_tx_at,
        "last_error": state.last_error,
        "application_pin_auth_enabled": False,
        "control_writes_enabled": False,
        "diagnostic_entities_enabled_by_default": True,
    }
