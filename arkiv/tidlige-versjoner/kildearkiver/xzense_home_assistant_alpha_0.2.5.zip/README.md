# Xzense Home Assistant – alpha 0.2.5

Experimental local Bluetooth integration for Exodraft Xzense.

## v0.2.5 changes

- Keeps explicit BLE pairing/bonding disabled.
- Does **not** connect from the cached Xzense `BLEDevice` anymore.
- Clears Home Assistant's advertisement de-duplication state before each attempt.
- Waits for a **new live connectable advertisement** from the configured Xzense address.
- Cached advertisement replay is explicitly disabled while waiting.
- Requests an immediate active Bluetooth scan while waiting.
- Makes exactly **one** GATT connection attempt per fresh advertisement; on failure it waits for the next fresh advertisement instead of retrying the stale device object three times.
- Adds diagnostics for advertisement count, wait count/timeouts, RSSI, source/adapter, timestamp, name and connectable status.
- Keeps all diagnostic entities enabled by default.
- Keeps the Xzense application PIN in the config entry, but still does **not** send application-protocol PIN/control frames yet.

## Current connection sequence

1. Clear advertisement de-duplication history for the configured Xzense address.
2. Wait for a **live** connectable Xzense advertisement (cached replay disabled).
3. Immediately use the `BLEDevice` from that advertisement for one GATT connection attempt.
4. Subscribe to DSPS TX notifications (`...5CB8`).
5. Wait for protocol traffic.
6. If connect/subscribe fails or the device disconnects, return to step 1 and wait for the next fresh advertisement.

No application-protocol writes or fan-control commands are sent in this build.

## Install / upgrade

Copy `custom_components/xzense` over the existing Xzense custom component and restart Home Assistant. Existing config entries and the stored Xzense PIN are retained.
