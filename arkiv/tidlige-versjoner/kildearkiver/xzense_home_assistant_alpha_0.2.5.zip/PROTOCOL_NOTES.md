# Xzense protocol discovery notes – 0.2.4

Known Dialog/Renesas DSPS UUIDs recovered from Xzense 5.0.2:

- Service: `0783b03e-8535-b5a0-7140-a304d2495cb7`
- Notify / server TX: `0783b03e-8535-b5a0-7140-a304d2495cb8`
- Write / server RX: `0783b03e-8535-b5a0-7140-a304d2495cba`

Real-device testing with 0.2.3 showed:

- ordinary BLE/GATT connect succeeds;
- explicit `client.pair()` times out after 12 s;
- notification subscription can still succeed after that timeout;
- the peripheral then remains connected for roughly 20 s while sending zero notifications before disconnecting.

Therefore 0.2.4 removes explicit BLE pairing and subscribes immediately. It still sends no application frames. The next protocol step is to identify the official app's first write to `...5CBA`, including any PIN/authentication, SEQ and checksum semantics.

## v0.2.5 fresh-advertisement connection strategy

Real-device testing showed repeated connection failures when reusing a cached BLEDevice. v0.2.5 clears Home Assistant's advertisement de-duplication state, waits for a new connectable advertisement from the configured Xzense address, and makes exactly one GATT connection attempt using the BLEDevice attached to that live advertisement. On failure it goes back to waiting for the next advertisement instead of retrying the same stale object.

New diagnostics include fresh advertisement count, wait count/timeouts, timestamp, RSSI, source/adapter, name and connectable flag. BLE pairing remains disabled and no application PIN/control frames are transmitted yet.
