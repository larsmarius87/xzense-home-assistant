"""Bluetooth client for Xzense."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
import logging

from bleak.backends.characteristic import BleakGATTCharacteristic
from bleak_retry_connector import BleakClientWithServiceCache, establish_connection

from homeassistant.components import bluetooth
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback

from .const import NOTIFY_UUID
from .protocol import XzenseFrame, XzenseFrameParser

_LOGGER = logging.getLogger(__name__)

Listener = Callable[[], None]

PAIR_TIMEOUT = 12.0
NOTIFY_TIMEOUT = 10.0


def _utc_now() -> str:
    """Return an ISO-8601 UTC timestamp for diagnostics."""
    return datetime.now(UTC).isoformat(timespec="milliseconds")


@dataclass(slots=True)
class XzenseState:
    """Runtime state exposed by the experimental read-only integration."""

    connected: bool = False
    ble_link_connected: bool = False
    notifications_active: bool = False
    phase: str = "idle"
    phase_changed_at: str | None = None
    ble_connected_at: str | None = None
    pair_started_at: str | None = None
    pair_completed_at: str | None = None
    notify_started_at: str | None = None
    notify_active_at: str | None = None
    last_disconnect_at: str | None = None
    packet_count: int = 0
    notification_count: int = 0
    last_notification: bytes = b""
    last_frame: XzenseFrame | None = None
    last_error: str | None = None
    pairing_last_error: str | None = None
    discarded_bytes: int = 0
    invalid_frames: int = 0
    connection_attempts: int = 0
    disconnect_count: int = 0
    pairing_attempts: int = 0
    pairing_success: bool = False
    authorization_retries: int = 0


class XzenseClient:
    """Maintain a BLE connection and parse Xzense notifications.

    v0.2.3 establishes the normal BLE link first, then explicitly requests
    Bluetooth pairing/bonding on that already-established link, and only after
    that enables notifications. This is intentionally different from v0.2.1,
    which forced pairing as part of connection establishment and could make the
    Xzense device unreachable.

    No Xzense application-protocol PIN or control writes are sent yet. The PIN
    stored in the config entry is retained for the later, separate application
    authentication layer once its framing/CRC/sequence semantics are proven.
    """

    def __init__(
        self,
        hass: HomeAssistant,
        entry: ConfigEntry,
        address: str,
        name: str,
        pin: str,
    ) -> None:
        self.hass = hass
        self.entry = entry
        self.address = address
        self.name = name
        self.pin = pin
        self.state = XzenseState()
        self._parser = XzenseFrameParser()
        self._listeners: set[Listener] = set()
        self._client: BleakClientWithServiceCache | None = None
        self._runner: asyncio.Task[None] | None = None
        self._wake = asyncio.Event()
        self._stopping = False

    @callback
    def async_add_listener(self, listener: Listener) -> Callable[[], None]:
        self._listeners.add(listener)

        @callback
        def remove_listener() -> None:
            self._listeners.discard(listener)

        return remove_listener

    @callback
    def _notify_listeners(self) -> None:
        for listener in tuple(self._listeners):
            listener()

    def _set_phase(self, phase: str) -> None:
        """Update the connection phase and expose it immediately."""
        if self.state.phase == phase:
            return
        self.state.phase = phase
        self.state.phase_changed_at = _utc_now()
        _LOGGER.debug("Xzense %s phase: %s", self.address, phase)
        self._notify_listeners()

    async def async_start(self) -> None:
        """Start the connection manager without blocking config-entry setup."""
        if self._runner and not self._runner.done():
            return
        self._stopping = False
        self._set_phase("starting")
        self._runner = self.entry.async_create_background_task(
            self.hass, self._connection_loop(), f"xzense-{self.address}"
        )

    async def async_stop(self) -> None:
        """Stop reconnects, notifications and the BLE connection."""
        self._stopping = True
        self._wake.set()

        runner = self._runner
        self._runner = None
        if runner:
            runner.cancel()
            try:
                await runner
            except asyncio.CancelledError:
                pass

        client = self._client
        self._client = None
        if client and client.is_connected:
            if self.state.notifications_active:
                try:
                    await client.stop_notify(NOTIFY_UUID)
                except Exception:  # best-effort during unload
                    pass
            try:
                await client.disconnect()
            except Exception:  # best-effort during unload
                pass

        self.state.connected = False
        self.state.ble_link_connected = False
        self.state.notifications_active = False
        self._set_phase("stopped")
        self._notify_listeners()

    async def _connection_loop(self) -> None:
        """Connect and reconnect while the config entry is loaded."""
        try:
            while not self._stopping:
                if not self._client or not self._client.is_connected:
                    await self._connect_once()

                self._wake.clear()
                try:
                    # A disconnect callback wakes this immediately. The timeout also
                    # lets us retry when the device was initially out of range.
                    await asyncio.wait_for(self._wake.wait(), timeout=30.0)
                except TimeoutError:
                    pass
        except asyncio.CancelledError:
            raise

    async def _establish_normal_connection(self, ble_device):
        """Connect without forcing pairing during the connection attempt."""
        self._set_phase("connecting")
        client = await establish_connection(
            BleakClientWithServiceCache,
            ble_device,
            ble_device.name or self.name,
            self._disconnected,
            max_attempts=3,
        )
        self._client = client
        self.state.ble_link_connected = bool(client.is_connected)
        self.state.ble_connected_at = _utc_now()
        self._set_phase("ble_connected")
        return client

    async def _pair_connected_client(
        self, client: BleakClientWithServiceCache
    ) -> None:
        """Request a bond only after the ordinary GATT link is established."""
        self.state.pairing_attempts += 1
        self.state.pairing_success = False
        self.state.pairing_last_error = None
        self.state.pair_started_at = _utc_now()
        self._set_phase("pairing")

        try:
            result = await asyncio.wait_for(client.pair(), timeout=PAIR_TIMEOUT)
        except TimeoutError:
            self.state.pairing_last_error = (
                f"Pairing timed out after {PAIR_TIMEOUT:.0f}s"
            )
            self._set_phase("pairing_timeout")
            _LOGGER.warning(
                "Xzense %s pairing timed out after %.0fs",
                self.address,
                PAIR_TIMEOUT,
            )
            return
        except Exception as err:
            self.state.pairing_last_error = f"{type(err).__name__}: {err}"
            self._set_phase("pairing_failed")
            _LOGGER.debug(
                "Xzense %s pairing attempt failed", self.address, exc_info=True
            )
            return

        self.state.pair_completed_at = _utc_now()
        # Bleak pair() normally returns bool. Treat None as success as well for
        # backend compatibility when no exception was raised.
        self.state.pairing_success = result is not False
        if self.state.pairing_success:
            self._set_phase("paired")
        else:
            self.state.pairing_last_error = "Bluetooth backend returned False"
            self._set_phase("pairing_failed")

    async def _connect_once(self) -> None:
        ble_device = bluetooth.async_ble_device_from_address(
            self.hass, self.address, connectable=True
        )
        if ble_device is None:
            self._set_phase("unreachable")
            self._set_error(
                "Device is not currently reachable by a connectable Bluetooth adapter"
            )
            return

        self.state.connection_attempts += 1
        client: BleakClientWithServiceCache | None = None

        try:
            # Step 1: ordinary BLE/GATT connection. This is the path that was
            # proven to reach the Xzense in v0.2.0/v0.2.2.
            client = await self._establish_normal_connection(ble_device)

            # Step 2: pair/bond *after* the GATT link exists. Pairing failure is
            # recorded, but we still try notifications because an already-bonded
            # BlueZ device may report a harmless pairing error.
            await self._pair_connected_client(client)

            # Some devices/backends briefly disconnect while creating a bond.
            # Reconnect normally if needed before touching the CCCD.
            if not client.is_connected:
                self.state.ble_link_connected = False
                self._set_phase("reconnecting_after_pair")
                client = await self._establish_normal_connection(ble_device)

            # Step 3: now enable notifications. The previous build could sit here
            # until the Xzense's ~20 s disconnect; cap it so diagnostics clearly
            # identify a notification-stage timeout.
            self.state.notify_started_at = _utc_now()
            self._set_phase("enabling_notifications")
            try:
                await asyncio.wait_for(
                    client.start_notify(NOTIFY_UUID, self._notification),
                    timeout=NOTIFY_TIMEOUT,
                )
            except Exception as notify_err:
                if self._is_authorization_error(notify_err):
                    self.state.authorization_retries += 1
                raise

            self.state.notifications_active = True
            self.state.notify_active_at = _utc_now()
            self.state.connected = True
            self.state.ble_link_connected = bool(client.is_connected)
            self.state.last_error = None
            self._set_phase("notifications_active")
            _LOGGER.info("Connected Xzense protocol monitor to %s", self.address)
            self._notify_listeners()

        except Exception as err:
            if client and client.is_connected:
                try:
                    await client.disconnect()
                except Exception:  # best-effort cleanup after failed setup
                    pass

            self._client = None
            self.state.connected = False
            self.state.ble_link_connected = False
            self.state.notifications_active = False
            self._set_phase("error")
            self._set_error(f"{type(err).__name__}: {err}")
            _LOGGER.debug(
                "Unable to connect/pair/subscribe Xzense %s",
                self.address,
                exc_info=True,
            )
            return

    @staticmethod
    def _is_authorization_error(err: Exception) -> bool:
        """Return True for the GATT authorization failure seen on Xzense."""
        message = str(err).lower()
        return (
            "insufficient authorization" in message
            or "authorization (8)" in message
            or "gatterrorresponse: insufficient authorization" in message
        )

    def _disconnected(self, _client: BleakClientWithServiceCache) -> None:
        """Bleak disconnected callback."""
        self._client = None
        self.state.connected = False
        self.state.ble_link_connected = False
        self.state.notifications_active = False
        self.state.disconnect_count += 1
        self.state.last_disconnect_at = _utc_now()
        self._set_phase("disconnected")
        self._notify_listeners()
        self._wake.set()

    def _notification(
        self, _characteristic: BleakGATTCharacteristic, data: bytearray
    ) -> None:
        payload = bytes(data)
        self.state.notification_count += 1
        self.state.last_notification = payload

        frames = self._parser.feed(payload)
        self.state.discarded_bytes = self._parser.discarded_bytes
        self.state.invalid_frames = self._parser.invalid_frames

        for frame in frames:
            self.state.packet_count += 1
            self.state.last_frame = frame
            _LOGGER.debug(
                "Xzense RX frame #%d: %s payload=%s peer=%s checksum=%04x",
                self.state.packet_count,
                frame.hex,
                frame.payload_hex or "<empty>",
                frame.peer_id_hex,
                frame.checksum,
            )

        self._notify_listeners()

    def _set_error(self, message: str) -> None:
        if self.state.last_error != message:
            self.state.last_error = message
            self.state.connected = False
            self._notify_listeners()
