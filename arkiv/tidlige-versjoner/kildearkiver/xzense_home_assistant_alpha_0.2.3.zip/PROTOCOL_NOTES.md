# Xzense protocol notes – v0.2.3-alpha.1

Observed on the test device:

- Normal BLE connect can succeed.
- Enabling the DSPS notification characteristic has previously returned GATT `Insufficient authorization (8)`.
- A later build could establish the BLE link but remained in notification setup and the panel disconnected after roughly 20 seconds.
- For v0.2.3 the sequence is therefore: **normal connect -> explicit pair/bond -> reconnect if needed -> start notifications**.

No application-protocol PIN packet or control packet is transmitted by this build.
