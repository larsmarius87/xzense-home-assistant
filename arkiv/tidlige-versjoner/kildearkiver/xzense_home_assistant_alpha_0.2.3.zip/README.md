# Xzense Home Assistant – v0.2.3-alpha.1

Experimental local Bluetooth integration for Exodraft Xzense.

## What changed in 0.2.3

This build changes the BLE setup sequence based on the observed ~20 second disconnect:

1. Make a normal BLE/GATT connection first.
2. With that link already established, explicitly request Bluetooth pairing/bonding.
3. If pairing temporarily drops the GATT link, reconnect normally.
4. Only then enable the Xzense notification characteristic.

This is intentionally different from v0.2.1, which forced pairing during connection establishment and could make the device unreachable.

New diagnostics expose the exact setup phase and timestamps, including `ble_connected`, `pairing`, `paired`, `enabling_notifications`, `notifications_active`, `pairing_failed`, `pairing_timeout`, `disconnected`, and `error`.

Pairing is capped at 12 seconds and notification setup at 10 seconds so a failure is visible instead of silently waiting for the panel to disconnect.

## Important

The stored four-character Xzense PIN is **not transmitted yet**. This build only tests the Bluetooth authorization/bonding layer. Application-protocol authentication and control writes remain disabled until the Xzense framing, sequence and checksum behavior is confirmed.

## Install

Copy `custom_components/xzense` over the existing Xzense integration and restart Home Assistant. Existing config entries and the configured PIN are retained.
