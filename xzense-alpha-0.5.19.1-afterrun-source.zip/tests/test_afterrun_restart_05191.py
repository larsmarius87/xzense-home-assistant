"""Alpha 0.5.19.1: Afterrun start control and distinct fire-cycle regression."""
from __future__ import annotations

import ast
import asyncio
import importlib.util
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / 'custom_components/xzense_full_preview'

spec = importlib.util.spec_from_file_location('xzense_restart_timing_05191', COMP / 'timing.py')
timing = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = timing
spec.loader.exec_module(timing)


def test_start_button_gate_in_ready_and_afterrun_and_no_other_states():
    tree = ast.parse((COMP / 'button.py').read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'XzenseButton')
    fn = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'available')
    ns = {}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])), '<button-available>', 'exec'), ns)
    class C:
        controls_available = True
        current_state = 2
        def current_device_state(self): return self.current_state
    c = C()
    proxy = SimpleNamespace(client=c, feature=SimpleNamespace(key='start_fire'))
    assert ns['available'].fget(proxy)
    c.current_state = 6
    assert ns['available'].fget(proxy)
    for state in [1,3,4,5,7,8,9,10]:
        c.current_state = state
        assert not ns['available'].fget(proxy), state
    c.current_state = 6
    c.controls_available = False
    assert not ns['available'].fget(proxy)


def test_dispatch_revalidates_afterrun_state_before_existing_boost_start():
    tree = ast.parse((COMP / 'client.py').read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'XzenseClient')
    fn = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'async_control_feature')
    ns = {'HomeAssistantError': RuntimeError}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])), '<client-start-fire>', 'exec'), ns)
    class Fake:
        state_id = 6
        sent = []
        def current_device_state(self): return self.state_id
        async def async_set_boost(self, enabled): self.sent.append(('boost', enabled))
        async def async_run_control(self, action): await action()
    async def run():
        x = Fake();x.sent=[]
        await ns['async_control_feature'](x, 'start_fire')
        assert x.sent == [('boost', True)]
        x.state_id=5
        try:
            await ns['async_control_feature'](x, 'start_fire')
        except RuntimeError as exc:
            assert 'not allowed' in str(exc)
        else: raise AssertionError('must reject invalid state')
        assert x.sent == [('boost', True)]
    asyncio.run(run())


def test_afterrun_into_boost_splits_fire_sessions_with_observed_transition():
    t = timing.XzenseTiming()
    t.observe(2, 100, 1000)
    t.observe(3, 2, 1010)  # fire start 1008
    t.observe(4, 10, 1040)
    t.observe(6, 2, 1080)
    assert t.last_fire_duration is None
    t.observe(3, 3, 1090)  # restarted at 1087
    assert t.last_fire_duration == 79
    assert t.last_fire_end_epoch == 1087
    assert t.fire_started_epoch == 1087
    assert t.fire_duration == 3
    assert t.fire_quality == 'observed_restart'
    t.observe(4, 5, 1100)
    assert t.fire_duration == 13
    t.observe(2, 1, 1200)
    assert t.last_fire_duration == 113


def test_same_afterrun_does_not_split_even_when_no_command_was_sent():
    t=timing.XzenseTiming()
    t.observe(2, 10, 1000)
    t.observe(3, 0, 1010)
    t.observe(6, 0, 1020)
    t.observe(6, 10, 1030)
    assert t.last_fire_duration is None
    assert t.fire_started_epoch == 1010


def test_afterrun_to_reheating_or_operation_also_starts_new_fire():
    for next_state in (4, 7):
        t=timing.XzenseTiming()
        t.observe(2, 10, 1000)
        t.observe(3, 1, 1010)
        t.observe(6, 1, 1020)
        t.observe(next_state, 1, 1030)
        assert t.last_fire_duration == 20
        assert t.fire_started_epoch == 1029


def test_long_gap_start_is_partial_not_fabricated_exact_start():
    t=timing.XzenseTiming()
    t.observe(2, 10, 1000)
    t.observe(3, 0, 1010)
    t.observe(6, 10, 1040)
    t.observe(3, 500, 1600)
    assert t.last_fire_quality == 'estimated_end_after_gap'
    assert t.fire_quality == 'partial_observation'
    assert t.fire_started_epoch == 1600
    assert t.last_fire_end_epoch == 1600
    assert t.fire_duration == 0


def test_afterrun_restart_restores_persisted_last_fire_and_new_start():
    t=timing.XzenseTiming()
    t.observe(2, 10, 1000)
    t.observe(3, 0, 1010)
    t.observe(6, 2, 1040)
    t.observe(3, 1, 1050)
    previous=t.last_fire_duration
    restored=timing.XzenseTiming.restore(t.snapshot())
    assert restored.last_fire_duration == previous
    restored.observe(4, 5, 1060)
    assert restored.last_fire_duration == previous
    assert restored.fire_duration == 11


def test_no_transport_changes_to_previous_hybrid_package():
    import zipfile
    archive=Path('/mnt/data/xzense-alpha-0.5.19-hybrid-source.zip')
    assert archive.exists()
    with zipfile.ZipFile(archive) as z:
        original=z.read('custom_components/xzense_full_preview/client.py').decode()
    new=(COMP/'client.py').read_text()
    target='state not in ({2} if feature_key == "start_fire" else {4, 5})'
    assert original.count(target)==1
    assert new==original.replace(target, 'state not in ({2, 6} if feature_key == "start_fire" else {4, 5})')
    with zipfile.ZipFile(archive) as z:
        assert z.read('custom_components/xzense_full_preview/protocol.py')==(COMP/'protocol.py').read_bytes()
