"""Alpha 0.5.15 regression checks for multi-proxy BLE selection."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import importlib.util
import ast

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / "custom_components" / "xzense_full_preview"

spec = importlib.util.spec_from_file_location("xzense_proxy_selection_0515", COMP / "proxy_selection.py")
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)

@dataclass
class Adv:
    source: str
    rssi: int


def test_strong_new_proxy_beats_old_sticky_weak_proxy():
    adverts = [Adv("old", -100), Adv("stue", -64)]
    assert module.rank_proxy_candidates(adverts, preferred_source="old")[0].source == "stue"


def test_strict_rssi_ignores_previous_preference():
    adverts = [Adv("a", -70), Adv("b", -65)]
    assert module.rank_proxy_candidates(adverts, preferred_source="a")[0].source == "b"
    adverts[0].rssi = -81
    assert module.rank_proxy_candidates(adverts, preferred_source="a")[0].source == "b"


def test_strict_rssi_ignores_failure_penalty():
    adverts = [Adv("a", -65), Adv("b", -68)]
    assert module.rank_proxy_candidates(adverts, recent_failed_sources={"a"})[0].source == "a"


def test_selection_stable_and_single_candidate_still_used():
    adverts = [Adv("b", -70), Adv("a", -70)]
    assert [x.source for x in module.rank_proxy_candidates(adverts)] == ["a", "b"]
    assert module.rank_proxy_candidates([Adv("old", -100)])[0].source == "old"


def test_transport_protocol_and_status_interval_are_not_changed():
    client = (COMP / "client.py").read_text()
    assert "STATUS_POLL_INTERVAL = 10.0" in client
    assert "max_attempts=1" in client
    assert "build_connect_request(self.pin, APPLICATION_CLIENT_NAME)" in client
    assert "build_status_request(session_id)" in client
    assert "ADAPTER_COLLECTION_WINDOW = 3.0" in client


def test_disconnect_classification_does_not_claim_controller_initiated():
    client = (COMP / "client.py").read_text()
    assert "unexpected_ble_callback" in client
    assert "local_setup_failure_cleanup" in client
    assert "local_shutdown" in client
    assert "initiator/reason not provided by Bleak callback" in client
    ast.parse(client)


def test_no_entity_id_migrations_and_diagnostics_have_history():
    client = (COMP / "client.py").read_text()
    diag = (COMP / "diagnostics.py").read_text()
    assert '"disconnect_history": state.disconnect_history' in diag
    assert '"active_session_source": state.active_session_source' in diag
    assert "DISCONNECT_HISTORY_LIMIT = 20" in client
