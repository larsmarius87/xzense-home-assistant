"""Exercise the actual disconnect callback without depending on HA at import time."""
from __future__ import annotations

import ast
from datetime import datetime, timezone
import logging
from pathlib import Path
from types import SimpleNamespace
import time

ROOT = Path(__file__).resolve().parents[1]
CODE = (ROOT / 'custom_components/xzense_full_preview/client.py').read_text()


def _callback():
    tree = ast.parse(CODE)
    klass = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'XzenseClient')
    method = next(n for n in klass.body if isinstance(n, ast.FunctionDef) and n.name == '_disconnected')
    module = ast.Module(body=[method], type_ignores=[])
    ast.fix_missing_locations(module)
    scope = {
        '__name__':'testing',
        'time':time,
        '_utc_now':lambda:datetime.now(timezone.utc).isoformat(),
        '_LOGGER':logging.getLogger('testing'),
        'DISCONNECT_HISTORY_LIMIT':20,
    }
    exec(compile(module, '<disconnect>', 'exec'), scope)
    return scope['_disconnected']


def _fake_state():
    return SimpleNamespace(
        active_session_source='proxy-new',
        active_session_rssi=-62,
        selected_source='proxy-new',
        application_auth_state='connected',
        last_status_request_at='now',
        last_status_response_at='earlier',
        last_notification_at='earlier',
        disconnect_history=[],
        connected=True,
        ble_link_connected=True,
        notifications_active=True,
        status_polling_active=True,
        disconnect_count=0,
    )


def _fake_self(client):
    fake=SimpleNamespace(
        _client=client,
        _planned_disconnects={},
        _stopping=False,
        _active_ble_started_monotonic=time.monotonic()-30,
        _source_failure_at={},
        state=_fake_state(),
        _session_ready=SimpleNamespace(clear=lambda:None),
        _set_phase=lambda x:None,
        _notify_listeners=lambda:None,
        _wake=SimpleNamespace(set=lambda:None),
    )
    return fake


def test_unexpected_disconnect_captures_session_source_duration_and_request_timing():
    cb=_callback()
    client=object()
    s=_fake_self(client)
    cb(s,client)
    assert s.state.last_disconnect_kind=='unexpected_ble_callback'
    assert s.state.last_disconnect_source=='proxy-new'
    assert 29 <= s.state.last_disconnect_session_seconds <= 32
    assert s.state.last_disconnect_last_status_request_at=='now'
    assert s.state.last_disconnect_last_status_response_at=='earlier'
    assert s.state.disconnect_history[0]['authenticated'] is True
    assert s.state.disconnect_history[0]['rssi_at_connect']==-62
    assert s.state.disconnect_count == 1
    assert 'proxy-new' in s._source_failure_at


def test_planned_cleanup_is_not_misattributed_to_controller():
    cb=_callback()
    client=object()
    s=_fake_self(client)
    s._planned_disconnects[id(client)]='local_setup_failure_cleanup'
    cb(s,client)
    assert s.state.last_disconnect_kind=='local_setup_failure_cleanup'
    assert 'proxy-new' not in s._source_failure_at


def test_stale_callback_does_not_destroy_new_active_session():
    cb=_callback()
    active=object()
    stale=object()
    s=_fake_self(active)
    cb(s,stale)
    assert s._client is active
    assert s.state.connected is True
    assert s.state.disconnect_count == 0
    assert s.state.disconnect_history == []


def test_stale_planned_cleanup_does_not_touch_current_session():
    cb=_callback()
    active=object()
    stale=object()
    s=_fake_self(active)
    s._planned_disconnects[id(stale)]='local_setup_failure_cleanup'
    cb(s,stale)
    assert s._client is active
    assert s.state.connected is True
    assert s.state.disconnect_count == 0
    assert s.state.disconnect_history == []
    assert not s._planned_disconnects
