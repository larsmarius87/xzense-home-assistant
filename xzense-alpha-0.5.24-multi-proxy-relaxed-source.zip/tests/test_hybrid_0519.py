"""Xzense hybrid 0.5.19.3: loop/backoff/control/slider/caching guards."""
from __future__ import annotations
import ast
import asyncio
from pathlib import Path
from types import SimpleNamespace
import time

COMP = Path(__file__).resolve().parents[1] / 'custom_components/xzense_full_preview'
SOURCE = (COMP/'client.py').read_text()


def load_method(name: str, namespace=None):
    tree = ast.parse(SOURCE)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'XzenseClient')
    fn = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == name)
    ns = {'asyncio': asyncio, 'time': time, 'TimeoutError': TimeoutError}
    ns.update(namespace or {})
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])), '<hybrid>', 'exec'), ns)
    return ns[name]


def test_version_and_slider_range():
    import json
    assert json.loads((COMP/'manifest.json').read_text())['version'] == '0.5.24'
    source = (COMP/'number.py').read_text()
    for expected in ['NumberMode.SLIDER', '_attr_native_min_value = 0',
                     '_attr_native_max_value = 120', '_attr_native_step = 1',
                     'async_set_interval(int(value), active=False)']:
        assert expected in source
    assert 'DEFAULT_UPDATE_INTERVAL_MINUTES = 5' in SOURCE
    assert 'DEFAULT_ACTIVE_INTERVAL_SECONDS = 0' in SOURCE
    assert 'class XzenseActiveUpdateInterval' in source
    assert '_attr_native_max_value = 600' in source
    assert 'async_set_interval(int(value), active=True)' in source
    assert 'COMMAND_HOLD_SECONDS = 15.0' in SOURCE


def test_continuous_transport_still_uses_original_reconnect_loop():
    c = (COMP/'client.py').read_text()
    assert 'await self._continuous_connection_loop()' in c
    assert 'await self._periodic_connection_loop()' in c
    assert 'await self._wake.wait()' in c
    assert 'if self._wake.is_set():\n                    continue' not in c
    assert 'STATUS_POLL_INTERVAL = 10.0' in c


def test_offline_sensors_have_last_refresh_and_stale_flag():
    s = (COMP/'sensor.py').read_text()
    assert 'return self.native_value is not None' in s
    assert '"last_data_at": self.client.state.last_data_at' in s
    assert '"stale": not self.client._fresh_status_event.is_set()' in s
    assert 'self.state.globals.clear()' not in SOURCE
    assert 'self.state.status = None' not in SOURCE
    assert 'await client.async_initialize_cache()' in (COMP/'__init__.py').read_text()


def test_request_connection_and_serial_control_without_transmit_on_failed_auth():
    async def exercise():
        fn = load_method('async_run_control', {
            'HomeAssistantError': RuntimeError,
            '_utc_now': lambda: 'time',
            'SNAPSHOT_WAIT_SECONDS': 0.01,
            'COMMAND_HOLD_SECONDS': 0.01,
        })
        class Fake:
            _pending_commands = 0
            _connect_requested = False
            interval_minutes = 5
            _command_lock = asyncio.Lock()
            _session_ready = asyncio.Event()
            _fresh_status_event = asyncio.Event()
            _wake = asyncio.Event()
            _client = SimpleNamespace(is_connected=True)
            _keep_connected_until = 0
            state = SimpleNamespace(pending_commands=0, last_command_at=None)
            def _notify_listeners(self): pass
        x=Fake()
        calls=[]
        async def do_write(): calls.append('write')
        task=asyncio.create_task(fn(x, do_write))
        await asyncio.sleep(0)
        assert x._connect_requested
        assert x._wake.is_set()
        x._session_ready.set()
        try:
            await asyncio.wait_for(task, timeout=0.1)
        except RuntimeError as exc:
            assert 'fresh status' in str(exc)
        else:
            raise AssertionError('write must be refused without fresh STATUS')
        assert calls == []
        assert x._pending_commands == 0
        assert x._connect_requested is False
    asyncio.run(exercise())


def test_control_queue_serializes_two_commands():
    async def exercise():
        fn=load_method('async_run_control', {
            'HomeAssistantError': RuntimeError,
            '_utc_now': lambda: 'time',
            'COMMAND_HOLD_SECONDS': 15,
        })
        class Fake:
            _pending_commands = 0
            _connect_requested = False
            interval_minutes = 5
            _command_lock = asyncio.Lock()
            _session_ready = asyncio.Event()
            _fresh_status_event = asyncio.Event()
            _wake = asyncio.Event()
            _client = SimpleNamespace(is_connected=True)
            _keep_connected_until = 0
            state = SimpleNamespace(pending_commands=0, last_command_at=None)
            def _notify_listeners(self): pass
        x=Fake()
        x._session_ready.set(); x._fresh_status_event.set()
        order=[]
        async def write1():
            order.append('start1')
            await asyncio.sleep(0.01)
            order.append('end1')
        async def write2(): order.append('start2')
        await asyncio.gather(fn(x,write1),fn(x,write2))
        assert order==['start1','end1','start2']
        assert x._pending_commands == 0
        assert x._keep_connected_until > time.monotonic()
    asyncio.run(exercise())


def test_no_unbounded_synchronous_busy_loop_in_periodic_mode():
    # Covers regression that previously starved all of HA on 0.5.15.
    period=load_method('_periodic_connection_loop')
    assert asyncio.iscoroutinefunction(period)
    assert 'await asyncio.sleep(0.25)' in SOURCE
    assert 'await asyncio.sleep(1.0)' in SOURCE
    assert 'await asyncio.wait_for(self._wake.wait(), timeout=seconds)' in SOURCE


def test_no_protocol_frame_builder_modified():
    import zipfile
    archive=next(Path('/mnt/data').glob('xzense-alpha-0.5.17-source*.zip'))
    with zipfile.ZipFile(archive) as z:
        orig=z.read('custom_components/xzense_full_preview/protocol.py').decode()
    current=(COMP/'protocol.py').read_text()
    for function in ('build_frame','build_connect_request','build_global_request','build_boost_request','build_ventilation_request','decode_status_data'):
        a=next(n for n in ast.parse(orig).body if isinstance(n,ast.FunctionDef) and n.name==function)
        b=next(n for n in ast.parse(current).body if isinstance(n,ast.FunctionDef) and n.name==function)
        assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)


def test_one_periodic_cycle_releases_ble_and_sets_next_poll():
    """Run the actual periodic scheduler with fake Bleak/HA objects."""
    from datetime import UTC, datetime
    import logging
    async def exercise():
        fn = load_method('_periodic_connection_loop', {
            'APPLICATION_AUTH_TIMEOUT': 0.1,
            'SNAPSHOT_WAIT_SECONDS': 0.1,
            '_LOGGER': logging.getLogger('test-xzense'),
            'datetime': datetime,
            'UTC': UTC,
        })
        class Ble:
            is_connected=True
            async def disconnect(self):
                self.is_connected=False
        class Fake:
            _stopping=False
            interval_minutes=1
            interval_seconds=60
            _client=None
            _next_poll_monotonic=0
            _connect_requested=False
            _pending_commands=0
            _keep_connected_until=0
            _wake=asyncio.Event()
            _session_ready=asyncio.Event()
            _fresh_status_event=asyncio.Event()
            _planned_disconnects={}
            state=SimpleNamespace(periodic_poll_count=0,local_periodic_disconnect_count=0,next_poll_at=None,
                                  connected=True,ble_link_connected=True,notifications_active=True,application_auth_state='connected')
            def _notify_listeners(self): pass
            def _set_phase(self, value): self.phase=value
            async def _connect_once(self, fast=False):
                self._client=Ble()
                self._session_ready.set()
                self._fresh_status_event.set()
                return True
        f=Fake()
        task=asyncio.create_task(fn(f))
        try:
            await asyncio.wait_for(_wait_for(lambda: f.state.local_periodic_disconnect_count==1), timeout=3.5)
            assert f.state.periodic_poll_count==1
            assert f.state.next_poll_at is not None
            assert f._next_poll_monotonic > time.monotonic()
            assert f._client is None
        finally:
            task.cancel()
            try: await task
            except asyncio.CancelledError: pass
    async def _wait_for(condition):
        while not condition():
            await asyncio.sleep(.05)
    asyncio.run(exercise())
