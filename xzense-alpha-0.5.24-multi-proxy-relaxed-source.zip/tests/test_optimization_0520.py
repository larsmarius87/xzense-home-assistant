"""0.5.20 regression: lightweight diagnostics, safe fast scan, full fallback."""
from __future__ import annotations
import ast
import asyncio
from pathlib import Path
from types import SimpleNamespace
import time

BASE = Path(__file__).resolve().parents[1]
COMP = BASE / 'custom_components/xzense_full_preview'
CLIENT = (COMP/'client.py').read_text()
SENSOR = (COMP/'sensor.py').read_text()


def _method(name, namespace):
    tree = ast.parse(CLIENT)
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'XzenseClient')
    fn = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == name)
    ns = {'asyncio': asyncio, 'time': time, **namespace}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])), 'test', 'exec'), ns)
    return ns[name]


def _constants():
    vals = {}
    for node in ast.parse(CLIENT).body:
        if isinstance(node, ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            if node.targets[0].id in {'ADVERTISEMENT_WAIT_TIMEOUT','ADAPTER_COLLECTION_WINDOW','FAST_ADAPTER_COLLECTION_WINDOW','FAST_ADAPTER_MIN_RSSI','RECENT_SOURCE_FAILURE_SECONDS','MAX_SOURCE_ATTEMPTS_PER_ROUND'}:
                vals[node.targets[0].id] = ast.literal_eval(node.value)
    return vals


def test_diagnostic_inventory_keeps_12_core_and_old_ids():
    source=ast.parse(SENSOR)
    keys=None
    for node in source.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CORE_DIAGNOSTIC_KEYS' for t in node.targets):
            keys=set(ast.literal_eval(node.value.args[0]))
    assert keys is not None and len(keys)==12
    assert {'last_data_at','phase','selected_source','ble_link_connected','last_error','crc_errors','status_nack_count'} <= keys
    assert '_ALL_DIAGNOSTIC_SENSORS' in SENSOR
    assert 'description.key in CORE_DIAGNOSTIC_KEYS' in SENSOR
    init=(COMP/'__init__.py').read_text()
    assert 'RegistryEntryDisabler.INTEGRATION' in init
    assert 'entity_entry.unique_id in reduced_diagnostics' in init
    assert 'registry.async_remove(entity_entry.entity_id)' in init  # old scaffolds only
    assert 'if entity_entry.domain == "sensor" and entity_entry.unique_id in reduced_diagnostics' in init
    assert 'f"{client.address}_{description.key}"' in SENSOR
    full=(COMP/'diagnostics.py').read_text()
    assert '"packet_history": list(state.packet_history)' in full
    assert '"adaptive_short_window_count"' in full
    assert '"adaptive_fallbacks"' in full


def test_advertisement_does_not_wake_all_entities():
    tree=ast.parse(CLIENT)
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='XzenseClient')
    fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_record_advertisement')
    assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='_notify_listeners' for n in ast.walk(fn))


def test_adaptive_scan_only_for_strong_fresh_previously_successful_proxy():
    async def exercise(previous, source, rssi, force_full=False, recently_failed=False):
        callbacks=[]
        seen_windows=[]
        def register(hass, callback, address):
            callbacks.append(callback)
            asyncio.get_running_loop().call_soon(callback, SimpleNamespace(
                connectable=True,device=SimpleNamespace(name='Xzense'),source=source,
                rssi=rssi,name='Xzense'))
            return lambda:None
        async def request_scan(timeout): return None
        module=SimpleNamespace(
            async_register_advertisement_callback=register,
            async_clear_advertisement_history=lambda *args:None,
            async_request_active_scan=request_scan,
        )
        # Keep real event scheduling/timeouts, but avoid spending 3 seconds per
        # static test: trap only sleep(window), which has no notification timing
        # dependency once our callback is delivered.
        class AsyncioProxy:
            Event=asyncio.Event
            @staticmethod
            def timeout(delay):return asyncio.timeout(delay)
            def __getattr__(self, key):return getattr(asyncio,key)
            @staticmethod
            async def sleep(delay):
                seen_windows.append(delay)
                await asyncio.sleep(0)
        def rank(values):return sorted(values,key=lambda v:(-v.rssi,v.source))
        fake=SimpleNamespace(
            hass=SimpleNamespace(async_create_task=lambda coro:asyncio.create_task(coro)),
            address='xx',
            state=SimpleNamespace(advertisement_waits=0,advertisement_timeouts=0,
                last_successful_source=previous,source_discovery_method=None,
                preferred_source=None,adaptive_short_window_count=0,
                adaptive_full_window_count=0,adapter_collection_last_seconds=None,
                candidate_source_count=0),
            _source_failure_at=({previous:time.monotonic()} if recently_failed else {}),
            _last_scan_was_adaptive=False,
            _record_advertisement=lambda *args:None,
            _set_phase=lambda *args:None,
            _set_error=lambda *args:None,
            _source_key=lambda info:info.source,
            _rssi_value=lambda info:info.rssi,
            _cached_source_candidates=lambda:[],
            _publish_candidates=lambda cs:None,
            _preferred_source=None,
        )
        namespace=dict(_constants(),bluetooth=module,callback=lambda x:x,
                       _BleSourceCandidate=lambda **kwargs:SimpleNamespace(**kwargs),
                       rank_proxy_candidates=rank,_LOGGER=SimpleNamespace(info=lambda *a:None))
        namespace['asyncio']=AsyncioProxy()
        method=_method('_collect_fresh_advertisements',namespace)
        result=await method(fake,force_full_window=force_full)
        assert result and result[0].source==source
        assert len(seen_windows)==1
        return fake.state,seen_windows[0],fake._last_scan_was_adaptive
    async def check():
        state,win,short=await exercise('stue','stue',-64)
        assert short and win==0.8 and state.adaptive_short_window_count==1
        for case in [('stue','stue',-87,False,False),
                     ('stue','annen',-60,False,False),
                     ('stue','stue',-65,True,False),
                     ('stue','stue',-65,False,True)]:
            state,win,short=await exercise(*case)
            assert not short and win==3.0 and state.adaptive_full_window_count==1
    asyncio.run(check())


def test_failed_round_does_not_rescan_recursively():
    async def exercise():
        scans=[]
        attempts=[]
        class Fake:
            _stopping=False
            _last_scan_was_adaptive=False
            _client=None
            address='xx'
            hass=SimpleNamespace()
            state=SimpleNamespace(fast_connect_fallbacks=0,adaptive_fallbacks=0,
                source_fallbacks=0,last_failed_source=None,active_session_source=None,
                active_session_rssi=None,connected=False,ble_link_connected=False,
                notifications_active=False)
            _source_failure_at={}
            _active_ble_started_monotonic=None
            def _set_phase(self,x):pass
            def _set_error(self,x):pass
            async def _collect_fresh_advertisements(self,*,force_full_window=False):
                scans.append(force_full_window)
                self._last_scan_was_adaptive=not force_full_window
                return [SimpleNamespace(source='stue',rssi=-64,device=object())]
            async def _establish_source_connection(self,info):
                attempts.append(info.source)
                raise OSError('Connection failed')
        bluetooth=SimpleNamespace(async_clear_advertisement_history=lambda *a:None)
        fn=_method('_connect_once',dict(bluetooth=bluetooth,
            MAX_SOURCE_ATTEMPTS_PER_ROUND=6,
            rank_proxy_candidates=lambda x:list(x),
            _LOGGER=SimpleNamespace(debug=lambda *args,**kwargs:None)))
        fake=Fake()
        fake._connect_once=lambda *args,**kwargs: fn(fake,*args,**kwargs)
        got=await fn(fake)
        assert got is False
        assert scans==[False], scans
        assert len(attempts)==1
        assert fake.state.adaptive_fallbacks==0
    asyncio.run(exercise())
