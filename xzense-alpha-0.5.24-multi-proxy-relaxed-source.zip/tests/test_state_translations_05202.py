"""State translations preserve the original protocol/sensor and use stable enum keys."""
from __future__ import annotations
import ast
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]/'custom_components'/'xzense_full_preview'

def _module():
    tree=ast.parse((ROOT/'state_localization.py').read_text())
    allowed=[]
    for n in tree.body:
        if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id in {'DEVICE_STATE_CODES'}:
            allowed.append(n)
        if isinstance(n,ast.FunctionDef) and n.name in {'device_state_code'}:
            allowed.append(n)
    ns={}
    exec(compile(ast.fix_missing_locations(ast.Module(body=allowed,type_ignores=[])),str(ROOT/'state_localization.py'),'exec'),ns)
    return ns

def test_original_protocol_labels_remain_english():
    ns=_module()
    assert '2: "Ready for lighting"' in (ROOT/'protocol.py').read_text()
    assert '6: "Afterrun"' in (ROOT/'protocol.py').read_text()
    assert ns['device_state_code'](2)=='ready_for_lighting'
    assert ns['device_state_code'](6)=='afterrun'
    assert ns['device_state_code'](55)=='unknown_state'
    assert ns['device_state_code'](None) is None

def test_native_ha_enum_and_all_translations_are_complete():
    source=(ROOT/'sensor.py').read_text()
    assert '"device_state", "Device state", _operating_state' in source
    assert '"device_state_localized", "Localized device state", _operating_state_localized_code' in source
    assert 'device_class=SensorDeviceClass.ENUM' in source
    assert '_attr_options = list(description.options)' in source
    codes=set(_module()['DEVICE_STATE_CODES'].values())|{'unknown_state'}
    for file in (ROOT/'strings.json', ROOT/'translations/en.json',ROOT/'translations/nb.json'):
        data=json.loads(file.read_text())
        for sensor in ('device_state_localized',):
            assert set(data['entity']['sensor'][sensor]['state'])==codes
            assert all(data['entity']['sensor'][sensor]['state'].values())
    nb=json.loads((ROOT/'translations/nb.json').read_text())
    assert nb['entity']['sensor']['device_state_localized']['state']['ready_for_lighting']=='Klar for fyring'
    assert nb['entity']['number']['afterrun_time']['name']=='Ettergangstid'
    assert nb['entity']['number']['refire_time']['name']=='Gjenfyrings-tid'

def test_bluetooth_files_unmodified_against_language_overlay_baseline():
    import zipfile
    baseline=Path('/mnt/data/xzense-alpha-0.5.20.1-norsk-sprakpakke-revidert-source.zip')
    with zipfile.ZipFile(baseline) as archive:
        for name in ('protocol.py','proxy_selection.py','settings.py','timing.py','select.py','number.py','switch.py','button.py'):
            rel='custom_components/xzense_full_preview/'+name
            assert archive.read(rel)==(ROOT/name).read_bytes(),name


def test_bluetooth_core_keeps_status_observer_hooks():
    """Recent BLE transport updates must not remove STATUS observer support."""
    source=(ROOT/'client.py').read_text()
    assert 'async_add_status_listener' in source
    assert 'for observer in tuple(self._status_listeners):' in source
    assert 'self._update_timing(status.device_state, status.state_timer)' in source
    assert 'def _send_application_connect' in source
