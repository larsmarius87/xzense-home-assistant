const assert=require('assert');
const vm=require('vm');
const fs=require('fs');
const registry={};
class HTMLElement {
  attachShadow(){this.shadowRoot={innerHTML:'',activeElement:null,querySelectorAll:()=>[],querySelector:()=>null,getElementById:()=>({addEventListener:()=>{}})};return this.shadowRoot;}
}
const context={window:{customCards:[]},customElements:{get:x=>registry[x],define:(x,c)=>registry[x]=c},HTMLElement,document:{createElement:x=>new registry[x]()},console,confirm:()=>true};
vm.runInNewContext(fs.readFileSync('custom_components/xzense_full_preview/www/xzense-card.js','utf8'),context);
const card = context.document.createElement('xzense-card');
card.setConfig({type:'custom:xzense-card',entities:{device_state:'sensor.xzense_state',start_fire:'button.xzense_start'}});
const states={'sensor.xzense_state':{state:'Afterrun',attributes:{}},'button.xzense_start':{state:'unknown',attributes:{}}};
card.hass={states};
assert(card.shadowRoot.innerHTML.includes('Start ny fyring'));
states['button.xzense_start'].state='2026-10-23T10:00:00+02:00';
card.hass={states};
assert(card.shadowRoot.innerHTML.includes('data-action="start_fire"'));
assert(!/data-action="start_fire" disabled/.test(card.shadowRoot.innerHTML));
states['sensor.xzense_state'].state='Ready';
card.hass={states};
assert(!card.shadowRoot.innerHTML.includes('Start ny fyring'));
console.log('Xzense Afterrun dashboard label smoke OK');
