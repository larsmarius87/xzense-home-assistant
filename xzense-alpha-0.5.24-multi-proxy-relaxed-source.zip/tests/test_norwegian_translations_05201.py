"""Validate the complete Xzense 0.5.20.1 language overlay without HA dependencies."""
from __future__ import annotations
import ast, json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]/"custom_components"/"xzense_full_preview"

def test_translation_parity():
    a=json.loads((ROOT/"strings.json").read_text(encoding="utf-8"))
    b=json.loads((ROOT/"translations"/"nb.json").read_text(encoding="utf-8"))
    c=json.loads((ROOT/"translations"/"en.json").read_text(encoding="utf-8"))
    assert set(a["config"])==set(c["config"])
    for typ in ["sensor","number","select","button","switch","binary_sensor"]:
        assert set(a["entity"][typ])==set(b["entity"][typ])==set(c["entity"][typ])
        assert all(v.get("name") for v in b["entity"][typ].values())

def test_no_hardcoded_names_override_translation():
    for source in ("sensor.py","entity.py","number.py","binary_sensor.py"):
        text=(ROOT/source).read_text(encoding="utf-8")
        assert "_attr_name =" not in text
        assert "_attr_translation_key" in text

def test_all_entity_keys_covered():
    translations=json.loads((ROOT/"translations"/"nb.json").read_text(encoding="utf-8"))["entity"]
    a=ast.parse((ROOT/"sensor.py").read_text(encoding="utf-8"))
    for node in ast.walk(a):
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=="SensorDescription":
            assert ast.literal_eval(node.args[0]) in translations["sensor"]
    b=ast.parse((ROOT/"features.py").read_text(encoding="utf-8"))
    for node in ast.walk(b):
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=="FeatureSpec":
            typ=ast.literal_eval(node.args[2]); key=ast.literal_eval(node.args[0])
            if typ in translations and typ!="sensor":
                assert key in translations[typ]

def test_unmodified_select_protocol_and_bluetooth():
    assert '"Manual", "eXotelligence", "Pressure controlled"' in (ROOT/"select.py").read_text()
    assert 'DOMAIN = "xzense_full_preview"' in (ROOT/"const.py").read_text()
