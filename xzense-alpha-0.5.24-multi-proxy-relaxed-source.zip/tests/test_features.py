"""Feature matrix regression tests without Home Assistant imports."""
from pathlib import Path
import importlib.util
import sys

PATH = Path(__file__).parents[1] / "custom_components" / "xzense_full_preview" / "features.py"
spec = importlib.util.spec_from_file_location("xzense_features_test", PATH)
features = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = features
spec.loader.exec_module(features)


def test_key_app_features_are_scaffolded():
    keys = features.FEATURE_BY_KEY
    for key in (
        "start_fire", "stop_fire", "refuel", "boost", "ventilation",
        "user_fan_speed", "system_control", "chimney_temperature",
        "inside_temperature", "outside_temperature", "pressure",
        "alarm_setpoint", "refire_time", "burnout_time", "firmware_version",
    ):
        assert key in keys


def test_v057_verified_and_firmware_recovered_controls_are_write_ready():
    write_ready = {
        f.key
        for f in features.FEATURES
        if f.kind in {"button", "switch", "number", "select", "update"}
        and f.state == "write_ready"
    }
    assert write_ready == {
        "start_fire", "stop_fire", "refuel",
        "boost", "ventilation", "system_control",
        "volume_raw", "contrast_raw", "brightness_raw",
        "boost_fan_speed", "user_fan_speed",
        "auto_start_temperature", "auto_stop_temperature",
        "boost_time", "afterrun_time", "boost_stop_temperature",
        "wanted_draft", "minimum_fan_voltage", "alarm_setpoint",
        "refire_time", "burnout_time", "temperature_sensor",
    }
    assert features.FEATURE_BY_KEY["boost"].packet_type == 0x08
    assert features.FEATURE_BY_KEY["start_fire"].packet_type == 0x08
    assert features.FEATURE_BY_KEY["refuel"].packet_type == 0x08
    assert features.FEATURE_BY_KEY["stop_fire"].global_id == 0x19
    assert features.FEATURE_BY_KEY["ventilation"].packet_type == 0x09
    assert features.FEATURE_BY_KEY["system_control"].global_id == 0x55
    assert features.FEATURE_BY_KEY["user_fan_speed"].global_id == 0x50
    assert features.FEATURE_BY_KEY["user_fan_speed"].name == "Fan speed"


def test_live_runtime_global_ids_are_unchanged():
    keys = features.FEATURE_BY_KEY
    assert keys["chimney_temperature"].global_id == 0x1E
    assert keys["fan_speed"].global_id == 0x1F
    assert keys["inside_temperature"].global_id == 0x1C
    assert keys["outside_temperature"].global_id == 0x1D
    assert keys["pressure"].global_id == 0x1B
    assert keys["pressure"].state == "verified_read"
    assert keys["state_timer"].global_id == 0x1A
    assert keys["device_state"].global_id == 0x19


def test_power_source_mapping_is_unverified():
    key = features.FEATURE_BY_KEY["battery"]  # legacy key preserves unique_id
    assert key.name == "0x05 status"
    assert key.global_id == 0x05
    assert key.state == "id_known"


def test_interface_setting_ids_match_live_panel_correlation():
    keys = features.FEATURE_BY_KEY
    expected = {
        "volume_raw": ("Sound", 0x32),
        "contrast_raw": ("Contrast", 0x33),
        "brightness_raw": ("Brightness", 0x34),
    }
    for key, (name, global_id) in expected.items():
        assert keys[key].name == name
        assert keys[key].global_id == global_id
        assert keys[key].state == "write_ready"
    assert "language_raw" not in keys  # obsolete non-functional control removed


def test_setup_setting_ids_match_live_panel_correlation():
    keys = features.FEATURE_BY_KEY
    expected = {
        "auto_start_temperature": 0x4B,
        "auto_stop_temperature": 0x4C,
        "boost_time": 0x4D,
        "afterrun_time": 0x4E,
        "boost_fan_speed": 0x4F,
        "boost_stop_temperature": 0x52,
        "wanted_draft": 0x53,
        "minimum_fan_voltage": 0x54,
    }
    for key, global_id in expected.items():
        assert keys[key].global_id == global_id
        assert keys[key].state == "write_ready"


def test_temperature_probe_experimental_switch_is_mapped_to_correct_global():
    keys = features.FEATURE_BY_KEY
    key = features.FEATURE_BY_KEY["temperature_sensor"]
    assert key.state == "write_ready"
    assert key.kind == "switch"
    assert key.global_id == 0x56
    assert "Experimental" in key.notes

    # Xzense 4.10 RC2 UI code plus the earlier physical probe promote 0x50
    # back to the Operation fan-speed control in 0.5.7.
    assert keys["user_fan_speed"].state == "write_ready"
    assert keys["user_fan_speed"].global_id == 0x50
    assert keys["system_control"].global_id == 0x55
    assert keys["temperature_sensor"].global_id == 0x56
    assert keys["alarm_setpoint"].global_id == 0x58
    assert keys["refire_time"].global_id == 0x59
    assert keys["burnout_time"].global_id == 0x5B
    assert keys["alarm_setpoint"].state == "write_ready"
    assert keys["refire_time"].state == "write_ready"
    assert keys["burnout_time"].state == "write_ready"


def test_removed_placeholders_stay_removed_and_firmware_sensor_stays_verified():
    keys = features.FEATURE_BY_KEY
    assert "weather_station" not in keys
    assert "chimney_state" not in keys
    assert "firmware" not in keys
    assert keys["firmware_version"].state == "verified_read"


def test_obsolete_placeholder_features_are_absent():
    for key in ("language_raw", "burn_count", "operation_time", "error_log", "download_log", "history"):
        assert key not in features.FEATURE_BY_KEY

def test_temperature_probe_is_explicitly_marked_experimental():
    assert "not yet confirmed" in features.FEATURE_BY_KEY["temperature_sensor"].notes
    for key in ("refire_time", "burnout_time"):
        assert features.FEATURE_BY_KEY[key].state == "write_ready"


def test_deferred_external_controls_are_absent():
    # Raw power-source field remains even though the enum is now unverified.
    assert "external_start" not in features.FEATURE_BY_KEY
    assert "external_fan_speed" not in features.FEATURE_BY_KEY
    assert features.FEATURE_BY_KEY["battery"].global_id == 0x05
    assert features.FEATURE_BY_KEY["ventilation"].packet_type == 0x09
