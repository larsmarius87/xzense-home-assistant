const assert=require('assert');const vm=require('vm');const fs=require('fs');
const registry={};
class HTMLElement{attachShadow(){this.shadowRoot={innerHTML:'',activeElement:null,querySelectorAll:()=>[],querySelector:()=>null,getElementById:()=>({addEventListener:()=>{}})};return this.shadowRoot;}}
const context={window:{customCards:[]},customElements:{get:k=>registry[k],define:(k,v)=>registry[k]=v},HTMLElement,document:{createElement:k=>new registry[k]()},console,confirm:()=>true,Date,Intl};
vm.runInNewContext(fs.readFileSync('custom_components/xzense_full_preview/www/xzense-card.js','utf8'),context);
const card=new registry['xzense-card']();card.setConfig({type:'custom:xzense-card'});
const time=new Date(Date.now()-2*60*1000).toISOString();
card.hass={states:{'sensor.xzense_last_data_update':{state:time,attributes:{friendly_name:'Xzense Last data update'}},'sensor.xzense_device_state':{state:'Ready',attributes:{friendly_name:'Xzense Device state'}}},config:{time_zone:'Europe/Oslo'}};
assert.strictEqual(card._entity('last_data_at'),'sensor.xzense_last_data_update');
assert(card.shadowRoot.innerHTML.includes('Sist oppdatert:'));
assert(card.shadowRoot.innerHTML.includes('for 2 min siden'));
assert(!card.shadowRoot.innerHTML.includes(time)); // Show localized date, not raw ISO
card._tab='diagnostics';card._render();
assert(card.shadowRoot.innerHTML.includes('Sist oppdatert (Bluetooth)'));
assert(card.shadowRoot.innerHTML.includes('for 2 min siden'));
card.hass={states:{},config:{time_zone:'Europe/Oslo'}};card._tab='main';card._render();
assert(card.shadowRoot.innerHTML.includes('Ingen mottatte data ennå'));
console.log('Xzense last BT update UI test OK');
