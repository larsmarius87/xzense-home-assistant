"""Synthetic protocol/status regression tests for Alpha 0.5.16 timing."""
import ast
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMP = ROOT / 'custom_components' / 'xzense_full_preview'
spec = importlib.util.spec_from_file_location('xzense_timing_0516', COMP / 'timing.py')
timing = importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name] = timing
spec.loader.exec_module(timing)


def test_hms_formats_multi_day():
    assert timing.format_hms(0) == '00:00:00'
    assert timing.format_hms(3700) == '01:01:40'
    assert timing.format_hms(100000) == '27:46:40'
    assert timing.format_hms(None) is None


def test_signed_32768_boundary_is_not_timer_reset():
    t = timing.XzenseTiming()
    t.observe(2, 32762, 1000)
    t.observe(2, -32763, 1011)
    assert t.state_elapsed == 32773
    assert t.rollovers == 0
    assert t.state_continuity == 'observed'


def test_modulo_65536_rollover_keeps_total_elapsed():
    t = timing.XzenseTiming()
    t.observe(2, -6, 1000)  # 65530
    t.observe(2, 4, 1010)
    assert t.state_elapsed == 65540
    assert t.rollovers == 1
    t.observe(2, 14, 1020)
    assert t.state_elapsed == 65550
    assert timing.format_hms(t.state_elapsed) == '18:12:30'


def test_long_gap_recovers_complete_wraps():
    t = timing.XzenseTiming()
    t.observe(2, 10, 1000)
    t.observe(2, 14, 1000+65540)
    assert t.state_elapsed == 65550
    assert t.rollovers == 1
    assert t.state_continuity == 'inferred_across_gap'


def test_short_gap_with_raw_reset_does_not_fabricate_wrap():
    t = timing.XzenseTiming()
    t.observe(2, 2500, 1000)
    t.observe(2, 1, 1010)
    assert t.state_elapsed == 1
    assert t.state_continuity == 'timer_reset_or_missed_transition'


def test_fire_duration_spans_operation_refuel_burnout_afterrun():
    t = timing.XzenseTiming()
    t.observe(2, 190, 1000)
    t.observe(3, 5, 1010)  # Started about five seconds before observed
    assert t.fire_quality == 'observed_start'
    t.observe(4, 0, 1025)
    t.observe(7, 2, 1030)
    t.observe(5, 2, 1050)
    t.observe(6, 3, 1075)
    assert t.fire_duration == 70
    assert t.fire_started_epoch == 1005
    t.observe(2, 0, 1100)
    assert t.fire_duration == 0
    assert t.last_fire_duration == 95
    assert t.last_fire_quality == 'observed_start'


def test_ventilation_does_not_start_fire():
    t = timing.XzenseTiming()
    t.observe(2, 100, 1000)
    t.observe(8, 20, 1010)
    assert t.fire_started_epoch is None
    assert t.fire_duration == 0


def test_restart_restores_cycle_epoch_and_timer():
    t = timing.XzenseTiming()
    t.observe(2, 30, 1000)
    t.observe(3, 2, 1010)
    t.observe(4, 0, 1100)
    restored = timing.XzenseTiming.restore(t.snapshot())
    restored.observe(4, 70, 1170)
    assert restored.fire_started_epoch == 1008
    assert restored.fire_duration == 162
    assert restored.state_elapsed == 70
    restored.observe(2, 0, 1190)
    assert restored.last_fire_duration == 182


def test_ha_first_sees_running_fire_no_guessed_original_start():
    t = timing.XzenseTiming()
    t.observe(5, 200, 1000)
    assert t.fire_started_epoch == 1000
    assert t.fire_quality == 'partial_observation'
    t.observe(6, 0, 1100)
    assert t.fire_duration == 100


def test_gap_after_known_start_marks_uncertainty():
    t = timing.XzenseTiming()
    t.observe(2, 10, 1000)
    t.observe(3, 3, 1010)
    t.observe(3, 203, 1210)
    assert t.fire_quality == 'estimated_after_gap'
    t.observe(2, 0, 1300)
    assert t.last_fire_quality == 'estimated_end_after_gap'


def test_malformed_restore_is_ignored():
    assert timing.XzenseTiming.restore({'raw_unsigned': -200}).raw_unsigned is None
    assert timing.XzenseTiming.restore({'state_elapsed': -1}).state_elapsed is None


def test_source_wiring_keeps_existing_entity_identity_and_restores_store():
    client = (COMP / 'client.py').read_text()
    sensor = (COMP / 'sensor.py').read_text()
    integration = (COMP / '__init__.py').read_text()
    diag = (COMP / 'diagnostics.py').read_text()
    assert '"state_timer",\n        "Time in current state"' in sensor
    assert '"fire_duration",\n        "Fire duration"' in sensor
    assert 'lambda s: s.state_timer_display' in sensor
    assert 'lambda s: s.fire_duration_display' in sensor
    assert 'await client.async_initialize_timing()' in integration
    assert 'self._update_timing(status.device_state, status.state_timer)' in client
    assert 'self._timing_store.async_delay_save' in client
    assert 'await self._timing_store.async_save' in client
    assert '"fire_duration_quality": state.fire_quality' in diag
    for f in ('client.py','sensor.py','__init__.py','timing.py','diagnostics.py'):
        ast.parse((COMP / f).read_text())
