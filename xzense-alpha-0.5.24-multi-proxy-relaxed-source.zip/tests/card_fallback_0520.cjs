const assert=require('assert');const vm=require('vm');const fs=require('fs');
const registry={};
class HTMLElement{attachShadow(){this.shadowRoot={innerHTML:'',activeElement:null,querySelectorAll:()=>[],querySelector:()=>null,getElementById:()=>({addEventListener:()=>{}})};return this.shadowRoot;}}
const sandbox={window:{customCards:[]},customElements:{get:k=>registry[k],define:(k,v)=>registry[k]=v},HTMLElement,document:{createElement:k=>new registry[k]()},console,Date,Intl};
vm.runInNewContext(fs.readFileSync('custom_components/xzense_full_preview/www/xzense-card.js','utf8'),sandbox);
const card=new registry['xzense-card']();card.setConfig({type:'custom:xzense-card',entities:{chimney_temperature:'sensor.xzense_pipe'}});
const t=new Date(Date.now()-125*1000).toISOString();
card.hass={states:{'sensor.xzense_pipe':{state:'47',attributes:{friendly_name:'Xzense chimney temp',unit_of_measurement:'°C',last_data_at:t}},'sensor.xzense_device_state':{state:'Operation',attributes:{friendly_name:'Xzense Device state'}}},config:{time_zone:'Europe/Oslo'}};
assert(card._lastUpdatedInfo().age==='for 2 min siden');
assert(card.shadowRoot.innerHTML.includes('Sist oppdatert:'));
assert(!card.shadowRoot.innerHTML.includes('Ingen mottatte data ennå'));
card._tab='diagnostics';card._render();
assert(card.shadowRoot.innerHTML.includes('for 2 min siden'));
// Unavailable diagnostic sensor must not shadow valid live-sensor timestamp.
card.hass={states:{...card._hass.states,'sensor.xzense_last_data_at':{state:'unavailable',attributes:{friendly_name:'Xzense Sist oppdatert (Bluetooth)'}}},config:{time_zone:'Europe/Oslo'}};
assert(card._lastUpdatedInfo().age==='for 2 min siden');
console.log('Xzense 0.5.20 last_data_at fallback smoke OK');
