"""Integration-level lightweight method tests with no HA runtime dependency."""
import ast
import asyncio
import json
import time
from pathlib import Path
from types import SimpleNamespace as Obj

P = Path(__file__).resolve().parents[1] / 'custom_components' / 'xzense_full_preview'
SRC = (P / 'client.py').read_text()

def extract(name, ns):
    cls = next(n for n in ast.parse(SRC).body if isinstance(n, ast.ClassDef) and n.name == 'XzenseClient')
    fn = next(n for n in cls.body if isinstance(n, (ast.AsyncFunctionDef, ast.FunctionDef)) and n.name == name)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[])), 'test', 'exec'), ns)
    return ns[name]

def test_version_and_unlocked_source_diagnostics():
    assert json.loads((P / 'manifest.json').read_text())['version'] == '0.5.24'
    assert 'VERSION = "0.5.24"' in (P/'const.py').read_text()
    diag = (P/'diagnostics.py').read_text()
    assert '"source_lock_active": False' in diag
    assert '"locked_bluetooth_source": None' in diag
    assert '"max_source_attempts_per_round": MAX_SOURCE_ATTEMPTS_PER_ROUND' in diag
    assert 'LOCKED_BLUETOOTH_SOURCE' not in SRC
    assert 'max_attempts=1' in SRC

def test_multisource_cache_is_not_filtered_by_old_stue_mac():
    fn = extract('_cached_source_candidates', {
        'bluetooth': Obj(async_scanner_devices_by_address=lambda *a, **k: [
            Obj(scanner=Obj(source=source), ble_device=Obj(name='xzense'),
                advertisement=Obj(rssi=rssi))
            for source, rssi in [('old_stue', -65), ('new_stue', -45), ('gang', -88)]
        ]),
        '_BleSourceCandidate': Obj,
    })
    f = Obj(hass=object(), address='84:8B:CD:50:36:29')
    result = fn(f)
    assert {c.source for c in result} == {'old_stue','new_stue','gang'}

def test_no_fresh_ads_reuse_multiple_cached_sources_with_cooldown():
    class TimedOutEvent:
        async def wait(self): raise TimeoutError
        def set(self): pass
    async def scan(_seconds): return None
    a = Obj(
        Event=TimedOutEvent,
        timeout=asyncio.timeout,
        sleep=asyncio.sleep,
    )
    namespace={
        'asyncio':a, 'time':time,
        'ADVERTISEMENT_WAIT_TIMEOUT':45.,
        'ADAPTER_COLLECTION_WINDOW':3.,
        'RECENT_SOURCE_FAILURE_SECONDS':120.,
        'CACHED_SOURCE_SCAN_SECONDS':3.,
        'bluetooth': Obj(
            BluetoothServiceInfoBleak=object,
            BluetoothChange=object,
            async_clear_advertisement_history=lambda *a:None,
            async_register_advertisement_callback=lambda *a:lambda:None,
            async_request_active_scan=scan),
        'callback':lambda func:func,
        '_BleSourceCandidate':Obj,
        'rank_proxy_candidates':lambda items:sorted(items, key=lambda x:-x.rssi),
        '_LOGGER':Obj(info=lambda *a:None),
    }
    fn=extract('_collect_fresh_advertisements', namespace)
    cache=[Obj(source='new_stue',rssi=-40,device=object(),origin='per_scanner_cache'),
           Obj(source='old_stue',rssi=-60,device=object(),origin='per_scanner_cache'),
           Obj(source='gang',rssi=-93,device=object(),origin='per_scanner_cache')]
    class Fake:
        address='84:8B:CD:50:36:29'
        _preferred_source=None
        _last_scan_was_adaptive=False
        def __init__(self):
            self.hass=Obj(async_create_task=lambda coro:asyncio.create_task(coro))
            self.state=Obj(advertisement_waits=0,advertisement_timeouts=0,
                source_discovery_method=None,adapter_collection_last_seconds=None,
                cached_sources_without_fresh_count=0)
            self._source_failure_at={'old_stue':time.monotonic()}
            self.phase=None;self.published=None
        def _cached_source_candidates(self): return cache
        def _set_phase(self,value):self.phase=value
        def _set_error(self,value):self.error=value
        def _publish_candidates(self,value):self.published=value
    async def exercise():
        fake=Fake()
        result=await fn(fake)
        assert [x.source for x in result]==['new_stue','gang']
        assert fake.phase=='cached_adapter_candidates_ready'
        assert fake.state.cached_sources_without_fresh_count==1
        assert fake.state.adapter_collection_last_seconds==3.
        assert fake.state.source_discovery_method=='multi_proxy_cache_without_fresh_advertisement'
    asyncio.run(exercise())

def test_failure_falls_through_to_second_proxy_in_same_round():
    class FakeClient:
        is_connected=True
        async def start_notify(self, uuid, callback): return None
        async def disconnect(self): self.is_connected=False
    fn=extract('_connect_once',dict(
        asyncio=asyncio,time=time,
        MAX_SOURCE_ATTEMPTS_PER_ROUND=6,
        RECENT_SOURCE_FAILURE_SECONDS=120.,
        NOTIFY_TIMEOUT=10.,NOTIFY_UUID='uuid',
        bluetooth=Obj(async_clear_advertisement_history=lambda *a:None),
        BleakClientWithServiceCache=FakeClient,
        _utc_now=lambda:'now',
        _LOGGER=Obj(debug=lambda *a,**k:None, info=lambda *a,**k:None),
        rank_proxy_candidates=lambda x:list(x),
    ))
    class Fake:
        _stopping=False
        _client=None
        _preferred_source=None
        _last_scan_was_adaptive=False
        _active_ble_started_monotonic=None
        _connect_requested=False
        _source_failure_at={}
        _planned_disconnects={}
        address='84:8B:CD:50:36:29'
        name='Xzense'
        _notification=lambda *args:None
        def __init__(self):
            self.state=Obj(fast_connect_attempts=0, source_fallbacks=0,
                last_failed_source=None, active_session_source=None,
                active_session_rssi=None,connected=False,ble_link_connected=False,
                notifications_active=False, status_polling_active=False,
                session_id=None,last_status_request_at=None,
                application_auth_state='not_started',last_error=None)
            self._parser=Obj(reset=lambda:None)
            self._session_ready=asyncio.Event()
            self._fresh_status_event=asyncio.Event()
            self.calls=[]
        def _set_phase(self,x):pass
        def _set_error(self,x):self.state.last_error=x
        def _notify_listeners(self):pass
        async def _collect_fresh_advertisements(self,*,force_full_window=False):
            return [Obj(source='new_stue',rssi=-50,device=object()),
                    Obj(source='old_stue',rssi=-65,device=object()),
                    Obj(source='gang',rssi=-95,device=object())]
        async def _establish_source_connection(self,info):
            self.calls.append(info.source)
            if info.source=='new_stue': raise OSError('test fail')
            c=FakeClient();self._client=c
            self.state.active_session_source=info.source
            return c
        async def _send_application_connect(self,c):
            self.handshake=1
    async def run():
        f=Fake()
        success=await fn(f)
        assert success
        assert f.calls==['new_stue','old_stue']
        assert f.state.source_fallbacks==1
        assert f.state.last_failed_source=='new_stue'
        assert f.handshake==1
    asyncio.run(run())
