"""Regression: BLE reconnect must never spin synchronously with a pre-set wake."""
from __future__ import annotations
import asyncio
import ast
from pathlib import Path
from types import SimpleNamespace

CLIENT = Path(__file__).resolve().parents[1] / 'custom_components/xzense_full_preview/client.py'


def load_continuous_connection_loop():
    tree = ast.parse(CLIENT.read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'XzenseClient')
    func = next(n for n in cls.body if isinstance(n, ast.AsyncFunctionDef) and n.name == '_continuous_connection_loop')
    fn = ast.Module(body=[func],type_ignores=[])
    namespace = {'asyncio':asyncio}
    exec(compile(ast.fix_missing_locations(fn),'<xzense connection loop>','exec'), namespace)
    return namespace['_continuous_connection_loop']


def test_ble_connection_loop_yields_on_pending_disconnect_signal():
    async def exercise():
        class SimulatedClient:
            is_connected = True

        class XzenseState:
            _stopping = False
            interval_minutes = 0
            _client = None
            _wake = asyncio.Event()
            connect_calls = 0

            async def _connect_once(self):
                self.connect_calls += 1
                self._client = SimulatedClient()
                self._wake.set() # callback fired during CONNECT before new session is ready
                return True

        c=XzenseState()
        connection_loop=load_continuous_connection_loop()
        loop_task=asyncio.create_task(connection_loop(c))
        try:
            # If a synchronous tight loop is present, even this timer never fires.
            await asyncio.wait_for(asyncio.sleep(.02), timeout=.2)
            assert c.connect_calls == 1
            assert not loop_task.done()  # loop is safely asleep, not crashed
            assert not c._wake.is_set()  # stale signal consumed
            c._wake.set()  # regular subsequent callback wakes the loop
            await asyncio.wait_for(asyncio.sleep(.01), timeout=.2)
            assert c.connect_calls == 1
        finally:
            loop_task.cancel()
            try:
                await asyncio.wait_for(loop_task, timeout=.2)
            except asyncio.CancelledError:
                pass
    asyncio.run(exercise())


def test_no_bare_continue_on_pre_set_wake():
    """Static safety rule: avoid introducing the same fatal pattern again."""
    s=CLIENT.read_text()
    assert 'if self._wake.is_set():\n                    continue' not in s
    assert 'self._wake.clear()' in s
