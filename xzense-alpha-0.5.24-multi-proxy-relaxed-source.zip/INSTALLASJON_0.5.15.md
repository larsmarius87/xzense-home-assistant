# Xzense Alpha 0.5.15 – BLE update

## Before replacing files

The archive provides the official integration domain `xzense_full_preview` under `custom_components/xzense_full_preview`.
Your earlier runtime log used the Python path `/config/custom_components/xzense/client.py` although your diagnostics report domain `xzense_full_preview`. Do not rename integration directories based only on that logger path. Back up the current integration and verify which folder Home Assistant loads.

For a normal `xzense_full_preview` installation, copy the entire `custom_components/xzense_full_preview` folder to `/config/custom_components/` and restart Home Assistant.

If your **active** integration package is physically `/config/custom_components/xzense/`, first verify the package manifest/domain and only then update the corresponding **full files** (`client.py`, new `proxy_selection.py`, `diagnostics.py`, `sensor.py`, `const.py`, `manifest.json`). Avoid creating a duplicate second integration folder without resolving the current domain. Preserve all existing config entry and entity IDs.

### Dashboard
Dashboard unchanged from 0.5.14. Use `/config/www/xzense-card.js` and registered resource `/local/xzense-card.js?v=0514` (no reload of JS needed for this BLE release).

### Validation
After restart, download a diagnostic. Verify version `0.5.15`, `adapter_collection_window_seconds = 3.0`, `active_session_source`, `disconnect_history`, `last_disconnect_kind`, and that the preferred source is the strongest nearby proxy if available. Observe several connections at good RSSI before attributing dropouts to the controller.

### Interpretation
`unexpected_ble_callback` only means the integration did not request a local disconnect. It is **not** evidence that the controller deliberately disconnected. ESPHome, radio loss, connection timeout or controller closure can all result in this callback.
