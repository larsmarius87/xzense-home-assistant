"""Release-baseline regressions for Xzense Alpha 0.5.5."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).parents[1]
COMPONENT = ROOT / "custom_components" / "xzense_full_preview"


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_manifest_keeps_domain_and_alpha_identity():
    manifest = json.loads((COMPONENT / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["domain"] == "xzense_full_preview"
    assert manifest["name"] == "Xzense Alpha"
    assert manifest["version"] == "0.5.5"


def test_v053_connection_release_and_version_code_is_unchanged():
    # Exact hashes from the recovered, pristine 0.5.3 source package. 0.5.5 is
    # intentionally a settings/mapping release, not a BLE/reconnect rewrite.
    expected = {
        "client.py": "172ba7249670587ceb0cdefcbdde0b83f2badf30d58bfd11e4333b83ee5c16e3",
        "button.py": "dbc820dc7a931df3634f045278e4702467b937c2c2a0c0eff0267b339238964d",
        "version.py": "7ea97a270dc9df892fcaf629da8e4597c28018c58b77c5ada36e292bc70ec2bb",
    }
    assert {name: _sha256(COMPONENT / name) for name in expected} == expected
