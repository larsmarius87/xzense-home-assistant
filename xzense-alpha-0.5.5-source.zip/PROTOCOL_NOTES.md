# Xzense protocol notes — Alpha 0.5.5

## 0.5.5 live controller correlation — current source of truth

Alpha 0.5.5 is rebased on the preserved 0.5.3 source. The 0.5.4 regression build is discarded and is not a source baseline.

A fresh physical-panel correlation established this block:

- `0x32` = **Sound**, direct percent. Panel Sound was changed 12 -> 24 and raw followed 12 -> 24.
- `0x33` = **Contrast**, direct percent. Panel 75 matched raw 75.
- `0x34` = **Brightness**, direct percent. Panel 68 matched raw 68.
- `0x4B` = **Start temperature**, tenths °C. `502` -> 50.2 °C.
- `0x4C` = **Stop temperature**, tenths °C. `398` -> 39.8 °C.
- `0x4D` = **Boost time**, seconds. `900` -> 15 min.
- `0x4E` = **Afterrun time**, seconds. `1800` -> 30 min.
- `0x4F` = **Boost speed**, direct percent. `100` -> 100 %.
- `0x52` = **Boost stop temperature**, tenths °C. `600` -> 60.0 °C.
- `0x53` = **Chimney draught setpoint**, direct Pa. `26` -> 26 Pa.
- `0x54` = **Minimum fan voltage**, direct volts. `105` -> 105 V.

Power-source A/B test:

- `0x05 = 2` -> **Battery**
- `0x05 = 3` -> **External power**

The integration intentionally does not call state 3 “charging”; actual charging state has not been established.

Values `0x35`, `0x36`, `0x50`, `0x51` and `0x55` remain unknown and are diagnostic/read-only. The earlier 0.5.3 `0x50` fan-setpoint interpretation is not used for writes in 0.5.5. Remaining `0x56`-`0x5B` labels are candidates only unless separately verified.

Published Xzense service-menu ranges are used for HA controls where available: Sound/Contrast/Brightness 0-100 %, Start temperature 5-100 °C, Stop temperature 0-95 °C, Boost time 1-15 min, Afterrun 1-200 min, Boost speed 40-100 %, chimney draught 8-60 Pa and minimum fan voltage 80-120 V. The manual lists a Boost-stop factory value but not an explicit adjustment range.


## STATUS layout

14-byte STATUS application payload:

`u8 state | i16 state_timer_s | i16 fan_% | i16 chimney_temp_x10 | i16 outside_temp_x10 | i16 inside_temp_x10 | i16 air_pressure_hPa | u8 flags`

Current mappings:

- GLOBAL `0x19` = device state.
- GLOBAL `0x1A` = time in current state, seconds.
- GLOBAL `0x1B` = air pressure, hPa; raw `1011` was user-confirmed as 1011 hPa.
- GLOBAL `0x1C` = inside temperature candidate, tenths °C.
- GLOBAL `0x1D` = outside temperature candidate, tenths °C.
- GLOBAL `0x1E` = chimney temperature, tenths °C.
- GLOBAL `0x1F` = actual fan speed, %.
- GLOBAL `0x20` = unidentified raw value.

Device-state labels currently used:

- `2 = Ready for lighting` (manual-supported)
- `3 = Boosting` (live-verified)
- `4 = Operation` (manual-supported; live verification pending)
- `5 = Refueling` (manual-supported; live verification pending)
- `6 = Afterrun` (live-verified)

## Firmware version

The CONNECT ACK contains a numeric version field. The observed value `410` matches the installed Xzense firmware `4.10`, so 0.4.7 exposes it as `4.10`.

Both the user's control panel and Power Unit currently run 4.10, so this field cannot yet be assigned specifically to one of those devices. Separate device-version requests remain to be reverse-engineered.

## BOOST packet

Static controller-firmware analysis identifies packet type `0x08` as `BOOST`.
BOOST/REQ uses:

`08 0B | session_id_le32 | start_u8 | inside_temp_i16_le`

Live testing confirmed:

- `start = 1` starts Boost and receives ACK.
- `start = 0` stops Boost and works on the physical controller.

## GLOBAL writes

Envelope:

`06 0B | session_id_le32 | global_id_u8 | value_i16_le`

Boost On/Off remain write-ready through packet `0x08`. The live-correlated numeric settings listed in the 0.5.5 section are also write-ready through the verified GLOBAL request envelope. Unknown/candidate fields remain non-writable.

## XTP / actual draft

GLOBAL `0x51` was previously treated as an actual-draught candidate. Alpha 0.5.5 no longer presents that meaning as established; `0x51` remains an unidentified raw diagnostic until XTP traffic or another direct correlation proves the mapping.


## Experimental GLOBAL writes (v0.5.0)

The already-tested GLOBAL request envelope is used directly:

`06 0B | session_id_le32 | global_id_u8 | value_i16_le`

Version 0.5.0 opens raw signed-int16 writes only for selected recovered numeric
setting IDs. It intentionally performs no guessed scale/unit conversion. Enum,
boolean and packet-payload controls whose value coding is still ambiguous remain
locked.


## Historical interface-setting cross-check (v0.5.1)

Fresh live diagnostic with controller sound set to 0 and contrast approximately 70:

- GLOBAL `0x33` = `75`: therefore `0x33` is **not** a direct sound/volume percentage mapping. It is now read-only and unidentified.
- GLOBAL `0x34` = `68`: matches the controller contrast setting closely enough to enable a direct 0-100 % Contrast write test.
- GLOBAL `0x35` = `1`: brightness naming remains a candidate only and stays raw/experimental.


## Historical 0.5.2 mapping corrections — superseded where noted

- Historical 0.5.2 interpretation: GLOBAL `0x50` was treated as a normal **fan speed setpoint**. Alpha 0.5.5 no longer exposes `0x50` as writable because the later panel-wide correlation identifies `0x4F` as Boost speed and leaves `0x50` unidentified.
- Historical 0.5.2 interpretation of `0x52` as unidentified is superseded: `0x52` is now Boost stop temperature (tenths °C).
- GLOBAL `0x54` remains **minimum fan voltage**, direct volts; later panel correlation also matched 105 V exactly.
- GLOBAL `0x55` is therefore unidentified.
- Historical 0.5.2 conclusion that `0x33` was not direct Sound is retained in part: `0x33` is now identified as Contrast, while Sound is `0x32`.
- Historical `0x34=Contrast` interpretation is superseded: fresh panel correlation identifies `0x34` as Brightness and `0x33` as Contrast.
- Historical `0x4E` Boost-time interpretation is superseded: `0x4D=900` is Boost time 15 min and `0x4E=1800` is Afterrun time 30 min; both are wire seconds.
