# Xzense BLE protocol manifest — Alpha 0.5.5

Work-in-progress protocol map. **Verified** means confirmed against live hardware or a captured working write. **Live-correlated** means a controller setting and GLOBAL value were matched directly. **Candidate** means the ID/name still needs physical verification before writes are allowed.

| ID | Current meaning | Encoding / unit | Access | Status | Evidence / notes |
|---:|---|---|---|---|---|
| `0x05` | Power source | enum | read | **Verified** | `2=Battery`, `3=External power` from unplug/replug A/B test |
| `0x18` | Signal strength | raw level | read | Candidate | Appears discrete, not dBm |
| `0x19` | Device state | enum | read | Verified | Operating-state decoder |
| `0x1A` | State timer | seconds | read | Verified | Increments approximately once per second |
| `0x1B` | Air pressure | hPa | read | Verified | Live-confirmed, e.g. 1011 hPa |
| `0x1C` | Inside temperature | value / 10 °C | read | Strong | Corroborates STATUS field |
| `0x1D` | Outside temperature | value / 10 °C | read | Strong | Corroborates STATUS field |
| `0x1E` | Chimney temperature | value / 10 °C | read | Verified | Live-calibrated |
| `0x1F` | Actual fan speed | % | read | Verified | Live-calibrated at 10 % and 100 % |
| `0x20` | Unknown | raw int16 | read | Unknown | Often 10 |
| `0x32` | Sound | % | read/write | **Live-correlated** | Panel 12→24 produced raw 12→24 |
| `0x33` | Contrast | % | read/write | **Live-correlated** | Panel 75 matched raw 75 |
| `0x34` | Brightness | % | read/write | **Live-correlated** | Panel 68 matched raw 68 |
| `0x35` | Unknown | raw int16 | read | Unknown | Observed 1; diagnostic only |
| `0x36` | Unknown | raw int16 | read | Unknown | Observed 0; diagnostic only |
| `0x4B` | Start temperature | value / 10 °C | read/write | **Live-correlated** | 502 -> 50.2 °C |
| `0x4C` | Stop temperature | value / 10 °C | read/write | **Live-correlated** | 398 -> 39.8 °C |
| `0x4D` | Boost time | seconds | read/write | **Live-correlated** | 900 s -> 15 min |
| `0x4E` | Afterrun time | seconds | read/write | **Live-correlated** | 1800 s -> 30 min |
| `0x4F` | Boost speed | % | read/write | **Live-correlated** | 100 -> 100 % |
| `0x50` | Unknown | raw int16 | read | Unknown | Observed 10; no write in 0.5.5 |
| `0x51` | Unknown | raw int16 | read | Unknown | Observed 0; not treated as actual draught |
| `0x52` | Boost stop temperature | value / 10 °C | read/write | **Live-correlated** | 600 -> 60.0 °C |
| `0x53` | Chimney draught setpoint | Pa | read/write | **Live-correlated** | 26 -> 26 Pa |
| `0x54` | Minimum fan voltage | V | read/write | **Live-correlated** | 105 -> 105 V |
| `0x55` | Unknown | raw int16 | read | Unknown | Observed 0; diagnostic only |
| `0x56` | System control candidate | enum | read | Candidate | Manual/eXotelligence/pressure-controlled; coding pending |
| `0x57` | Temperature sensor candidate | enum/bool | read | Candidate | Coding pending |
| `0x58` | External start candidate | raw int16 | read | Candidate | Observed 2500; not treated as a simple boolean |
| `0x59` | Alarm setpoint candidate | raw int16 | read | Candidate | Observed 180; no write until separately verified |
| `0x5A` | Refire/reboost-time candidate | raw int16 | read | Candidate | Observed 0 |
| `0x5B` | External fan-speed candidate | raw int16 | read | Candidate | Observed 300 |

## Packet types

| Packet | Meaning | Status |
|---:|---|---|
| `0x02` | CONNECT | Verified |
| `0x06` | GLOBAL | Verified read/write envelope |
| `0x07` | STATUS | Verified |
| `0x08` | BOOST | Verified on/off |
| `0x09` | VENTILATION | Firmware-derived candidate; payload pending |
| `0x0A` | RANGETEST | Firmware-derived candidate |
| `0x0B` | FACTORY_RESET | Firmware-derived; intentionally not exposed |
| `0x0C` | FILE_TRANSFER | Firmware-derived candidate |
| `0x0D` | TIMESYNC | Firmware-derived candidate |
| `0x0E` | CONNECTED_PEERS | Firmware-derived candidate |

## Home Assistant setting ranges

For Sound, Contrast, Brightness, Start/Stop temperature, Boost/Afterrun time, Boost speed, chimney draught and minimum fan voltage, Alpha 0.5.5 uses the published Xzense manual ranges. Boost-stop temperature has live-confirmed scaling but no explicit manual range; its HA bound is deliberately conservative.
