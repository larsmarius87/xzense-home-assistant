# Xzense Alpha 0.5.15 – installasjon

## 1. Oppdater integrasjonen

1. Pakk ut ZIP-filen. Kopier **hele** mappen `custom_components/xzense_full_preview` til `/config/custom_components/` i Home Assistant. Erstatt den gamle mappen.
2. Start Home Assistant på nytt. Din eksisterende Xzense-enhet og dens tilpassede entitets-ID-er blir beholdt.
3. Åpne Innstillinger → Enheter og tjenester → Xzense Alpha. Verifiser at integrasjonen viser versjon 0.5.15 og kobler seg til.

## 2. Registrer dashboardkortet (anbefalt og uavhengig av integrasjonsmappen)

1. Fra ZIP-filen, kopier `www/xzense-card.js` til `/config/www/xzense-card.js` i Home Assistant.
   Opprett `/config/www` hvis den mangler.
2. Åpne **Innstillinger → Dashboard → Ressurser** og legg inn:
   - Adresse: `/local/xzense-card.js?v=0514`
   - Type: **JavaScript-modul**
3. Fjern eventuelle gamle ressurser for samme kort, for eksempel
   `/api/xzense_full_preview/xzense-card.js?v=0514`.
4. Last dashboardet på nytt med en hard oppdatering av nettleseren.

**Viktig om mappenavn:** Hvis din eksisterende integrasjonsmappe heter
`/config/custom_components/xzense` og ikke `xzense_full_preview`, må vi
ikke bare gi den nytt navn eller kopiere `xzense_full_preview` over denne.
`domain` i manifestet, mappenavnet og den installerte integrasjonen må stemme
med hverandre. Denne kortinstallasjonen er helt uavhengig av dette, fordi
`/local/` viser til `/config/www/`.

Alternativt leveres kortet også under
`custom_components/xzense_full_preview/www/xzense-card.js`, som kan bli
servert via `/api/xzense_full_preview/xzense-card.js` **bare hvis akkurat
integrasjonen `xzense_full_preview` faktisk er installert og lastet**.

## 3. Legg kortet på dashboardet

Åpne ønsket dashboard → Rediger → Legg til kort → Manuelt. Lim inn:

```yaml
type: custom:xzense-card
title: Xzense
entities: {}
```

Kortet har Hovedskjerm, Driftsinnstillinger, Konfigurasjon, Kontrollpanel og Diagnostikk. Displayet bruker standard Home Assistant-farger og har ingen ramme som etterligner den fysiske enheten.

## 4. Koble riktige entiteter uten YAML

Åpne dashboard → Rediger → klikk kortet → **Rediger**. Kortets egen redigerer viser alle funksjoner med nedtrekkslister over de **faktiske Home Assistant-entitetene**. Velg riktig `sensor.*`, `number.*`, `switch.*`, `button.*` eller `select.*` for hver funksjon. Oppsettet lagres i Lovelace og fungerer på alle enheter, også nettbrettet.

Du kan også skrive et eget **visningsnavn** per rad. Dette endrer kun teksten i kortet, ikke den faktiske entitets-ID-en. Du må velge korrekt entitets-ID separat.

Uten manuell kobling forsøker kortet å gjenkjenne entiteter ut fra unik samsvarende `global_id` eller entitetsnavn; *flertydige treff blir ikke valgt automatisk.* Hvis en funksjon ikke fungerer, velg alltid korrekt entitet i redigeringen. Manuelle valg overstyrer automatisk gjenkjenning.

## Viktige endringer og sikkerhet

- `Temperature probe` er en **eksperimentell** På/Av-bryter i Konfigurasjon via GLOBAL `0x56`. `0=Av`, `1=På` er **foreløpig en antagelse** som må bekreftes mot panelet ved første test. Når temperatursensoren slås av, slutter automatisk temperaturbasert start og stopp å fungere. Kontroller fysisk panel etter endring, og ikke bruk bryteren under aktiv fyring før den er verifisert.
- Tidligere 0.5.12b/0.5.13-endringer er videreført, inkludert «Legg på ved» i driftstilstand 4 og 5.
- Lydstyrke, lysstyrke og kontrast endres 0–100 % når du trykker **Lagre**; kortet skriver ikke automatisk ved åpning eller oppdatering.
- Diagnostikkloggen er forbedret: Home Assistant-sensorer begrenses til 255 tegn, mens full GLOBAL-dump og lange feilmeldinger fortsatt finnes i attributter/diagnostikk.
- Ingen endringer i PIN, GATT, Bluetooth-oppkobling, kildevalg eller intervall. Test gjerne med den nye ESP32-proxyen før protokollen justeres.

## Feilsøking dashboard

- «Custom element doesn't exist»: Sjekk at ressursen er registrert, at integrasjonen er lastet og at du har oppdatert nettlesersiden helt.
- «Mangler entiteter»: Åpne kortets visuelle redigerer og velg faktiske entitets-ID-er. Tidligere manuelle navneendringer i Home Assistant beholdes.
- Utilgjengelig kontroll: Hjemmeassistent vil normalt blokkere skrivekommandoer når Xzense ikke er tilkoblet; dette er tilsiktet.
