"""Pure, deterministic ranking of fresh HA Bluetooth proxy advertisements.

Do not cache BLEDevice objects between connection attempts; Home Assistant may
invalidate them. The candidate list must contain advertisements collected now.
"""
from __future__ import annotations

from collections.abc import Iterable
from typing import Protocol, TypeVar

PREFERRED_SOURCE_BONUS_DB = 8
RECENT_FAILURE_PENALTY_DB = 6

class _Advertisement(Protocol):
    source: str | None
    rssi: int | None

T = TypeVar("T", bound=_Advertisement)


def rank_proxy_candidates(
    candidates: Iterable[T],
    *,
    preferred_source: str | None = None,
    recent_failed_sources: set[str] | None = None,
) -> list[T]:
    """Rank fresh candidates by signal, then a small stable-source preference.

    Strong proxies win over substantially weaker sources. A recent failure adds
    a temporary penalty, but no source is blacklisted: fallback still works.
    """
    failed = recent_failed_sources or set()

    def key(item: T) -> tuple[int, int, str]:
        source = item.source or "unknown"
        rssi = item.rssi if item.rssi is not None else -999
        score = (
            rssi
            + (PREFERRED_SOURCE_BONUS_DB if source == preferred_source else 0)
            - (RECENT_FAILURE_PENALTY_DB if source in failed else 0)
        )
        return (-score, -rssi, source)

    return sorted(candidates, key=key)
