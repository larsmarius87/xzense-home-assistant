"""Xzense 4.10 RC2 control-path regressions."""
from pathlib import Path

ROOT = Path(__file__).parents[1]
BUTTON = (ROOT / "custom_components" / "xzense_full_preview" / "button.py").read_text(encoding="utf-8")
NUMBER = (ROOT / "custom_components" / "xzense_full_preview" / "number.py").read_text(encoding="utf-8")


def test_refuel_is_gated_to_burnout_state_5():
    assert 'if self.feature.key == "refuel":\n            return self.client.boost_available() and state == 5' in BUTTON


def test_stop_firing_uses_boost_off_for_boosting_and_reheating():
    assert 'if state in {3, 7}:\n                await self.client.async_set_boost(False)' in BUTTON


def test_finish_firing_is_available_from_operation_or_burnout():
    assert BUTTON.count('state in {4, 5}') >= 3
    assert 'await self.client.async_execute_feature("start_afterrun", 6)' in BUTTON


def test_operation_fan_speed_is_only_available_in_operation():
    assert 'if self.feature.key == "user_fan_speed":' in NUMBER
    assert 'self.client.current_device_state() == 4' in NUMBER
