# Xzense Alpha 0.5.7 — feature matrix

| Feature | Status | Mapping / notes |
|---|---|---|
| BLE connect + PIN session | Working | DSPS BLE service + Xzense CONNECT; connection methods unchanged from 0.5.5 |
| Temporary BLE release to app | Working / integration-local | Adjustable 1-600 s; no Xzense control packet sent |
| Live status polling | Working | STATUS `0x07` |
| Device state | Verified read / v4.10 mapped | GLOBAL `0x19`; 0 Offline, 1 Setup, 2 Ready/IDLE, 3 Boosting, 4 Operation, 5 Burnout, 6 Afterrun, 7 Refueling/Reheating, 8 Ventilation, 9 Error, 10 Upgrading |
| State timer | Verified read | GLOBAL `0x1A`, seconds |
| Air pressure | Verified read | GLOBAL `0x1B`, hPa |
| Inside temperature | Strong read mapping | GLOBAL `0x1C`, tenths °C |
| Outside temperature | Strong read mapping | GLOBAL `0x1D`, tenths °C |
| Chimney temperature | Verified read | GLOBAL `0x1E`, tenths °C |
| Actual fan speed | Verified read | GLOBAL `0x1F`, % |
| Power source | Verified read | GLOBAL `0x05`; `2=Battery`, `3=External power` |
| Firmware version | Verified read | CONNECT ACK; `410` -> `4.10` |
| Boost on/off | Verified write | packet `0x08`, start 1/0 + inside temperature |
| Start lighting | Firmware-derived / write-ready | state 2 -> BOOST `0x08`, start=1 |
| Refuel | v4.10 firmware-derived / write-ready | state 5 Burnout -> BOOST `0x08`, start=1 -> state 7 Reheating/Refueling |
| Stop firing | v4.10 firmware-derived / write-ready | state 3/7 -> BOOST start=0; state 4/5 -> GLOBAL `0x19=6` |
| Finish firing | v4.10 firmware-derived / write-ready | state 4/5 -> GLOBAL `0x19=6` (Afterrun) |
| Ventilation | Firmware-derived / write-ready | packet `0x09`, session + start flag 1/0; live test pending |
| Operation fan speed | Firmware + physical-probe / write-ready | GLOBAL `0x50`, direct 10-100 %; HA control gated to state 4 |
| System control | v4.10 firmware-derived / write-ready | GLOBAL `0x55`; `0=Manual`, `1=eXotelligence`, `2=Pressure controlled` |
| Sound | Live-correlated / write-ready | GLOBAL `0x32`, direct % |
| Contrast | Live-correlated / write-ready | GLOBAL `0x33`, direct % |
| Brightness | Live-correlated / write-ready | GLOBAL `0x34`, direct % |
| Start temperature | Live-correlated / write-ready | GLOBAL `0x4B`, raw / 10 °C |
| Stop temperature | Live-correlated / write-ready | GLOBAL `0x4C`, raw / 10 °C |
| Boost time | Live-correlated / write-ready | GLOBAL `0x4D`, wire seconds / HA minutes |
| Afterrun time | Live-correlated / write-ready | GLOBAL `0x4E`, wire seconds / HA minutes |
| Boost speed | Live-correlated / write-ready | GLOBAL `0x4F`, direct % |
| Actual draught | Firmware-derived read | GLOBAL `0x51`; raw until scaling is live-verified |
| Boost stop temperature | Live-correlated / write-ready | GLOBAL `0x52`, raw / 10 °C |
| Chimney draught setpoint | Live-correlated / write-ready | GLOBAL `0x53`, direct Pa |
| Minimum fan voltage | Live-correlated / write-ready | GLOBAL `0x54`, direct V |
| Temperature sensor | v4.10 ID known / read-only | GLOBAL `0x56`; enum values not yet write-verified |
| External start | v4.10 ID known / read-only | GLOBAL `0x57`; coding pending |
| Alarm setpoint | v4.10 ID known / read-only | GLOBAL `0x58`; scaling pending |
| Reboost/refire time | v4.10 ID known / read-only | GLOBAL `0x59`; scaling/range pending |
| External fan speed | v4.10 candidate / read-only | GLOBAL `0x5A` |
| Burnout timeout | v4.10 ID known / read-only | GLOBAL `0x5B`; direct Burnout UI binding, observed raw 300 |
| GLOBAL `0x20` / `0x35` / `0x36` | Unknown / diagnostic | Raw read only |

The Home Assistant domain remains `xzense_full_preview` for registry compatibility. The user-facing integration name is **Xzense Alpha**.
