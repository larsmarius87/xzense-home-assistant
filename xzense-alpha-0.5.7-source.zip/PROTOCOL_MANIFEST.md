# Xzense BLE protocol manifest — Alpha 0.5.7

Current source of truth for the 4.10 controller. **Verified** = confirmed on live hardware/captured working write. **Live-correlated** = physical controller setting matched to GLOBAL value. **Firmware-derived** = directly recovered from the official Xzense 5.0.5 bundled controller firmware (`v4.10_RC2`). **Candidate** = read-only until semantics/scaling are independently confirmed.

The v4.10_RC2 image contains a stale legacy GLOBAL debug-name table. Current IDs below therefore use direct UI/controller-code bindings plus live 4.10 correlations, not the legacy name table alone.

| ID | Current meaning | Encoding / unit | Access | Status | Evidence / notes |
|---:|---|---|---|---|---|
| `0x05` | Power source | enum | read | **Verified** | `2=Battery`, `3=External power` from unplug/replug A/B |
| `0x18` | Signal level | raw | read | Candidate | Discrete level; not RSSI dBm |
| `0x19` | Device state | enum | read + selected state action | Verified read / Firmware-derived write | State 3/6 live verified; Afterrun action writes value 6 |
| `0x1A` | State timer | seconds | read | **Verified** | Advances approximately once per second |
| `0x1B` | Air pressure | hPa | read | **Verified** | e.g. live 1011 = 1011 hPa |
| `0x1C` | Inside temperature | /10 °C | read | Strong | Corroborates STATUS |
| `0x1D` | Outside temperature | /10 °C | read | Strong | Corroborates STATUS |
| `0x1E` | Chimney temperature | /10 °C | read | **Verified** | Live calibrated |
| `0x1F` | Actual fan speed | % | read | **Verified** | Live at 10 % and 100 % |
| `0x20` | Unknown | int16 | read | Unknown | Often 10 |
| `0x32` | Sound | % | read/write | **Live-correlated + firmware** | 12→24 A/B; direct v4.10 UI binding |
| `0x33` | Contrast | % | read/write | **Live-correlated + firmware** | 75 matched panel |
| `0x34` | Brightness | % | read/write | **Live-correlated + firmware** | 68 matched panel |
| `0x35` | Unknown | int16 | read | Unknown | observed 1 |
| `0x36` | Unknown | int16 | read | Unknown | observed 0 |
| `0x4B` | Start temperature | /10 °C | read/write | **Live-correlated + firmware** | 502 = 50.2 °C |
| `0x4C` | Stop temperature | /10 °C | read/write | **Live-correlated + firmware** | 398 = 39.8 °C |
| `0x4D` | Boost time | seconds | read/write | **Live-correlated + firmware** | 900 = 15 min |
| `0x4E` | Afterrun time | seconds | read/write | **Live-correlated + firmware** | 1800 = 30 min |
| `0x4F` | Boost speed | % | read/write | **Live-correlated + firmware** | 100 = 100 % |
| `0x50` | Operation/User fan speed | % | read/write | **Firmware + physical probe** | v4.10 Fan Control UI binds 0x50; earlier write test showed direct % |
| `0x51` | Actual draught | raw | read | Firmware-derived | Scaling not yet live-confirmed; read-only |
| `0x52` | Boost stop temperature | /10 °C | read/write | **Live-correlated + firmware** | 600 = 60.0 °C |
| `0x53` | Chimney draught setpoint | Pa | read/write | **Live-correlated + firmware** | 26 = 26 Pa |
| `0x54` | Minimum fan voltage | V | read/write | **Live-correlated + firmware** | 105 = 105 V |
| `0x55` | System control | enum | read/write | **v4.10 firmware-derived** | direct SystemManager binding; 0 Manual, 1 eXotelligence, 2 Pressure controlled |
| `0x56` | Temperature sensor | enum | read | **v4.10 ID known** | direct TemperatureSensor UI binding; coding still write-locked |
| `0x57` | External start | raw/enum | read | Firmware-derived | setup control path; coding pending |
| `0x58` | Alarm setpoint | raw | read | Firmware-derived | direct setup UI binding; scaling pending |
| `0x59` | Reboost/refire time | raw | read | Firmware-derived | Reheat setup screen directly binds 0x59; scaling pending |
| `0x5A` | External fan speed | raw | read | Firmware-derived candidate | external-start UI path references 0x5A |
| `0x5B` | Burnout timeout | raw | read | Firmware-derived | Burnout setup screen directly binds 0x5B; observed 300 |

## v4.10 state table

The firmware state-name arrays contain: `OFFLINE`, `SETUP`, `IDLE`, `BOOSTING`, `OPERATING`, `BURNOUT`, inserted `AFTERRUN`, `REHEATING`, `VENTILATING`, `ERROR_STATE`, `UPGRADING`, `UNKNOWN_STATE`.

| Raw | Meaning |
|---:|---|
| `0` | Offline |
| `1` | Setup |
| `2` | Ready for lighting / IDLE |
| `3` | Boosting |
| `4` | Operation |
| `5` | Burnout |
| `6` | Afterrun |
| `7` | Refueling / Reheating |
| `8` | Ventilation |
| `9` | Error |
| `10` | Upgrading |

## Packet types

| Packet | Meaning | Status |
|---:|---|---|
| `0x02` | CONNECT | Verified |
| `0x06` | GLOBAL | Verified read/write envelope |
| `0x07` | STATUS | Verified |
| `0x08` | BOOST | Live verified on/off; v4.10 state-dependent Start lighting / Refuel paths |
| `0x09` | VENTILATION | Firmware-derived start/stop; live write pending |
| `0x0A` | RANGETEST | Firmware-derived, not exposed |
| `0x0B` | FACTORY_RESET | Firmware-derived, intentionally not exposed |
| `0x0C` | FILE_TRANSFER | Firmware-derived, not exposed |
| `0x0D` | TIMESYNC | Firmware-derived, not exposed |
| `0x0E` | CONNECTED_PEERS | Firmware-derived, not exposed |

## Action semantics in 0.5.7

- state `2` + BOOST `start=1` -> Start lighting.
- state `5` Burnout + BOOST `start=1` -> Refuel/Reheating (`state 7`).
- state `3` or `7` + BOOST `start=0` -> stop the active Boost/Reheat phase.
- state `4` Operation or `5` Burnout + GLOBAL `0x19=6` -> Finish firing / Afterrun.
- VENTILATION request: `09 0B | session_id_le32 | start_u8`.
- System control: GLOBAL `0x55`, values `0/1/2` as above.
- Operation fan speed: GLOBAL `0x50`, direct %, exposed 10-100 % and HA-gated to state `4`.

Controller ACK/NACK remains authoritative for state-dependent requests.
