"""Constants for the Xzense Alpha integration."""

from __future__ import annotations

import re

DOMAIN = "xzense_full_preview"
NAME = "Xzense Alpha"
VERSION = "0.5.7"

# Dialog/Renesas DSPS (Serial Port Service) UUIDs recovered from Xzense 5.0.2.
SERVICE_UUID = "0783b03e-8535-b5a0-7140-a304d2495cb7"
NOTIFY_UUID = "0783b03e-8535-b5a0-7140-a304d2495cb8"  # Server TX -> phone/HA
WRITE_UUID = "0783b03e-8535-b5a0-7140-a304d2495cba"   # Server RX <- phone/HA

CONF_NAME = "name"
CONF_PIN = "pin"
DEFAULT_NAME = "Xzense"

PIN_PATTERN = re.compile(r"^[0-9A-F]{4}$")

# All user-facing platforms are scaffolded now. Unsupported control writes remain
# unavailable until their exact on-wire command semantics are verified.
PLATFORMS = ["sensor", "binary_sensor", "button", "switch", "number", "select", "update"]

# v0.5.7 alpha: GLOBAL writes are enabled only for features explicitly marked
# write_ready. The number platform converts HA-native units to the verified wire
# encoding before the client sends the signed-int16 GLOBAL value. No unverified
# enum conversion is applied.
CONTROL_WRITES_ENABLED = True
EXPERIMENTAL_GLOBAL_WRITES_ENABLED = True

# BOOST remains the separately verified packet-type 0x08 control.
BOOST_WRITES_ENABLED = True

# VENTILATION packet 0x09 start/stop payload recovered from controller firmware.
# It is statically verified but still awaits the first live write test on this controller.
VENTILATION_WRITES_ENABLED = True

# Integration-local helper used to release the single Xzense BLE connection to
# the official phone app during testing. This is intentionally seconds-based in
# Alpha 0.5.7; it can become a minute-based user control after validation.
DEFAULT_BLE_RELEASE_SECONDS = 60
MIN_BLE_RELEASE_SECONDS = 1
MAX_BLE_RELEASE_SECONDS = 600


def clamp_ble_release_seconds(value: int | float) -> int:
    """Clamp the temporary BLE release duration to the supported test range."""
    return max(MIN_BLE_RELEASE_SECONDS, min(MAX_BLE_RELEASE_SECONDS, int(round(value))))


def normalize_pin(value: str) -> str | None:
    """Normalize a Xzense PIN, returning None if it is not four hex digits."""
    pin = value.strip().upper()
    return pin if PIN_PATTERN.fullmatch(pin) else None
