"""Power source is displayed conservatively until controller enum is verified."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1] / "custom_components/xzense_full_preview"

def test_power_source_unverified_mapping():
    s=(ROOT/"sensor.py").read_text()
    assert '"Power source (?)"' in s
    assert 'f"Unknown ({raw})"' in s
    assert 'return "Battery"' not in s
    assert 'return "External power"' not in s

def test_power_source_keeps_legacy_unique_id():
    s=(ROOT/"sensor.py").read_text()
    assert 'SensorDescription("battery", "Power source (?)"' in s

def test_timer_settings_do_not_exceed_signed_wire_bounds():
    import importlib.util,sys
    path=ROOT/"settings.py"
    spec=importlib.util.spec_from_file_location('settings_check',path)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=mod
    spec.loader.exec_module(mod)
    for k in ('refire_time','burnout_time'):
        assert mod.raw_to_native(k,180)==3.0
        assert mod.raw_to_native(k,300)==5.0
        assert mod.native_to_raw(k,546.1)<=32767
        import pytest
        with pytest.raises(ValueError):
            mod.native_to_raw(k,546.2)
