# Xzense BLE protocol manifest — Alpha 0.5.10

Current source of truth for the 4.10 controller. **Verified** = confirmed on live hardware/captured working write. **Live-correlated** = physical controller setting matched to GLOBAL value. **Firmware-derived** = directly recovered from the official Xzense 5.0.5 bundled controller firmware (`v4.10_RC2`). **Candidate** = read-only until semantics/scaling are independently confirmed.

The v4.10_RC2 image contains a stale legacy GLOBAL debug-name table. Current IDs below therefore use direct UI/controller-code bindings plus live 4.10 correlations, not the legacy name table alone.

| ID | Current meaning | Encoding / unit | Access | Status | Evidence / notes |
|---:|---|---|---|---|---|
| `0x05` | 0x05 status (meaning unknown) | raw integer | read | **Unresolved** | 2 and 3 observed despite stable wired setup; previous 2=Battery/3=External mapping contradicted |
| `0x18` | 0x18 status (possible signal level) | raw integer | read | Candidate | Discrete level; not RSSI dBm |
| `0x19` | Device state | enum | read + selected state action | Verified read / Firmware-derived write | State 3/6 live verified; Afterrun action writes value 6 |
| `0x1A` | State timer | seconds | read | **Verified** | Advances approximately once per second |
| `0x1B` | Air pressure | hPa | read | **Verified** | e.g. live 1011 = 1011 hPa |
| `0x1C` | Inside temperature | /10 °C | read | Strong | Corroborates STATUS |
| `0x1D` | Outside temperature | /10 °C | read | Strong | Corroborates STATUS |
| `0x1E` | Chimney temperature | /10 °C | read | **Verified** | Live calibrated |
| `0x1F` | Actual fan speed | % | read | **Verified** | Live at 10 % and 100 % |
| `0x20` | Unknown | int16 | read | Unknown | Often 10 |
| `0x32` | Sound | % | read/write | **Live-correlated + firmware** | 12→24 A/B; direct v4.10 UI binding |
| `0x33` | Contrast | % | read/write | **Live-correlated + firmware** | 75 matched panel |
| `0x34` | Brightness | % | read/write | **Live-correlated + firmware** | 68 matched panel |
| `0x35` | Unknown | int16 | read | Unknown | observed 1 |
| `0x36` | Unknown | int16 | read | Unknown | observed 0 |
| `0x4B` | Start temperature | /10 °C | read/write | **Live-correlated + firmware** | 502 = 50.2 °C |
| `0x4C` | Stop temperature | /10 °C | read/write | **Live-correlated + firmware** | 398 = 39.8 °C |
| `0x4D` | Boost time | seconds | read/write | **Live-correlated + firmware** | 900 = 15 min |
| `0x4E` | Afterrun time | seconds | read/write | **Live-correlated + firmware** | 1800 = 30 min |
| `0x4F` | Boost speed | % | read/write | **Live-correlated + firmware** | 100 = 100 % |
| `0x50` | Fan speed setpoint | % | read/write | **Live Ventilation A/B + firmware** | Operation (4) and Ventilation (8): 10→16 steps observed in Ventilation, STATUS fan=16%; HA control gated to states 4 and 8 |
| `0x51` | Actual draught | raw | read | Firmware-derived | Scaling not yet live-confirmed; read-only |
| `0x52` | Boost stop temperature | /10 °C | read/write | **Live-correlated + firmware** | 600 = 60.0 °C |
| `0x53` | Chimney draught setpoint | Pa | read/write | **Live-correlated + firmware** | 26 = 26 Pa |
| `0x54` | Minimum fan voltage | V | read/write | **Live-correlated + firmware** | 105 = 105 V |
| `0x55` | System control | enum | read/write | **v4.10 firmware-derived** | direct SystemManager binding; 0 Manual, 1 eXotelligence, 2 Pressure controlled |
| `0x56` | Temperature sensor | enum | read | **v4.10 ID known** | direct TemperatureSensor UI binding; coding still write-locked |
| `0x57` | External start | raw/enum | diagnostic only (deferred) | Firmware-derived | removed from active feature registry; raw capture retained |
| `0x58` | Alarm setpoint | raw | read | Firmware-derived | direct setup UI binding; scaling pending |
| `0x59` | Reboost/refire time | raw | read | Firmware-derived | Reheat setup screen directly binds 0x59; scaling pending |
| `0x5A` | External fan speed | raw | diagnostic only (deferred) | Firmware-derived candidate | removed from active feature registry; raw capture retained |
| `0x5B` | Burnout timeout | raw | read | Firmware-derived | Burnout setup screen directly binds 0x5B; observed 300 |

## v4.10 state table

The firmware state-name arrays contain: `OFFLINE`, `SETUP`, `IDLE`, `BOOSTING`, `OPERATING`, `BURNOUT`, inserted `AFTERRUN`, `REHEATING`, `VENTILATING`, `ERROR_STATE`, `UPGRADING`, `UNKNOWN_STATE`.

| Raw | Meaning |
|---:|---|
| `0` | Offline |
| `1` | Setup |
| `2` | Ready for lighting / IDLE |
| `3` | Boosting |
| `4` | Operation |
| `5` | Burnout |
| `6` | Afterrun |
| `7` | Refueling / Reheating |
| `8` | Ventilation |
| `9` | Error |
| `10` | Upgrading |

## Packet types

| Packet | Meaning | Status |
|---:|---|---|
| `0x02` | CONNECT | Verified |
| `0x06` | GLOBAL | Verified read/write envelope |
| `0x07` | STATUS | Verified |
| `0x08` | BOOST | Live verified on/off; v4.10 state-dependent Start lighting / Refuel paths |
| `0x09` | VENTILATION | Firmware-derived start/stop; live write pending |
| `0x0A` | RANGETEST | Firmware-derived, not exposed |
| `0x0B` | FACTORY_RESET | Firmware-derived, intentionally not exposed |
| `0x0C` | FILE_TRANSFER | Firmware-derived, not exposed |
| `0x0D` | TIMESYNC | Firmware-derived, not exposed |
| `0x0E` | CONNECTED_PEERS | Firmware-derived, not exposed |

## Action semantics in 0.5.7

- state `2` + BOOST `start=1` -> Start lighting.
- state `5` Burnout + BOOST `start=1` -> Refuel/Reheating (`state 7`).
- state `3` or `7` + BOOST `start=0` -> stop the active Boost/Reheat phase.
- state `4` Operation or `5` Burnout + GLOBAL `0x19=6` -> Finish firing / Afterrun.
- VENTILATION request: `09 0B | session_id_le32 | start_u8`.
- System control: GLOBAL `0x55`, values `0/1/2` as above.
- Fan speed setpoint: GLOBAL `0x50`, direct %, exposed 10-100 % and HA-gated to states `4` Operation or `8` Ventilation.

Controller ACK/NACK remains authoritative for state-dependent requests.

## Alpha 0.5.11 update (2026-10-21)

- Removed non-functional Bluetooth release-to-app button, timer and associated BLE pause logic.
- Combined Boost on/off into one Boost switch; removed redundant Finish firing button. Stop firing retains its Afterrun transition through GLOBAL 0x19=6.
- Boost and Ventilation switches follow authenticated STATUS state (Boost state 3; Ventilation state 8). Boost state 7 is unresolved and retains last known value.
- Switch state is restored across HA restarts and retained across BLE reconnects until the first valid fresh STATUS frame. CONNECT/ACK immediately triggers the existing STATUS polling loop; command ACK alone does not determine switch state.
- Fan speed GLOBAL 0x50 is available in all connected states; firmware may still enforce its own restrictions.
- Controls are normal entities, configuration settings categorized CONFIG; device-page display ordering remains Home Assistant controlled.
- GitHub release source zip built from this tree; local tests do not substitute for on-device validation.

## 0.5.12 exposure supplement (supersedes read-only row labels above)

- GLOBAL `0x58`: Alarm temperature, CONFIG write-enabled in HA, 150–400 °C, 0.1 °C steps, raw tenths. Firmware/official-manual-derived; physical HA write pending.
- GLOBAL `0x59` and `0x5B`: read-only DIAGNOSTIC display; 180/60 = 3, 300/60 = 5 minutes are still provisional. Raw GLOBAL values retained, no write controls.
- GLOBAL `0x51`: visible actual-draft raw entity removed; diagnostics still includes the raw value.
- FILE_TRANSFER `0x0C`: research only. No active log/firmware transfer implemented; see `CHIMNEYLOG_RESEARCH.md`.
