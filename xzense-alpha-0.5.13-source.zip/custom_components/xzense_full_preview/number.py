"""Number controls for verified Xzense settings and local test helpers."""

from __future__ import annotations

from homeassistant.components.number import NumberEntity, NumberMode
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import (
    EntityCategory,
    PERCENTAGE,
    UnitOfElectricPotential,
    UnitOfPressure,
    UnitOfTemperature,
    UnitOfTime,
)
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient
from .const import DOMAIN
from .entity import XzenseFeatureEntity
from .features import FEATURES, FeatureSpec
from .settings import SETTING_RULES, native_to_raw, raw_to_native

NUMBER_FEATURES = tuple(f for f in FEATURES if f.kind == "number" and f.state == "write_ready")

_UNIT_BY_KIND = {
    "percent": PERCENTAGE,
    "celsius": UnitOfTemperature.CELSIUS,
    "minutes": UnitOfTime.MINUTES,
    "pascal": UnitOfPressure.PA,
    "volt": UnitOfElectricPotential.VOLT,
}


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(XzenseNumber(client, feature) for feature in NUMBER_FEATURES)


class XzenseNumber(XzenseFeatureEntity, NumberEntity):
    """A numeric Xzense setting backed by a GLOBAL value."""

    _attr_mode = NumberMode.BOX

    def __init__(self, client: XzenseClient, feature: FeatureSpec) -> None:
        super().__init__(client, feature)
        if feature.key != "user_fan_speed":
            self._attr_entity_category = EntityCategory.CONFIG
        rule = SETTING_RULES.get(feature.key)
        if rule is None:
            raise ValueError(f"Missing verified setting rule for {feature.key}")

        self._attr_native_min_value = rule.minimum
        self._attr_native_max_value = rule.maximum
        self._attr_native_step = rule.step
        unit = _UNIT_BY_KIND.get(rule.unit)
        if unit is not None:
            self._attr_native_unit_of_measurement = unit

    @property
    def native_value(self) -> float | None:
        if self.feature.global_id is None:
            return None
        raw = self.client.state.globals.get(self.feature.global_id)
        return None if raw is None else raw_to_native(self.feature.key, raw)

    async def async_set_native_value(self, value: float) -> None:
        raw = native_to_raw(self.feature.key, value)
        await self.client.async_execute_feature(self.feature.key, raw)
