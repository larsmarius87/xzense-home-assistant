"""Diagnostics support for Xzense."""

from __future__ import annotations

from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from .client import ADAPTER_COLLECTION_WINDOW, STATUS_POLL_INTERVAL, XzenseClient
from .const import (
    BOOST_WRITES_ENABLED,
    CONTROL_WRITES_ENABLED,
    DOMAIN,
    EXPERIMENTAL_GLOBAL_WRITES_ENABLED,
    VENTILATION_WRITES_ENABLED,
)
from .features import FEATURES
from .protocol import GLOBAL_NAMES, device_state_name


async def async_get_config_entry_diagnostics(
    hass: HomeAssistant, entry: ConfigEntry
) -> dict[str, Any]:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    state = client.state
    frame = state.last_frame
    status = state.status
    return {
        "address": client.address,
        "connected": state.connected,
        "ble_link_connected": state.ble_link_connected,
        "notifications_active": state.notifications_active,
        "phase": state.phase,
        "phase_changed_at": state.phase_changed_at,
        "ble_connected_at": state.ble_connected_at,
        "notify_started_at": state.notify_started_at,
        "notify_active_at": state.notify_active_at,
        "last_notification_at": state.last_notification_at,
        "last_disconnect_at": state.last_disconnect_at,
        "pin_configured": bool(client.pin),
        "packet_count": state.packet_count,
        "notification_count": state.notification_count,
        "last_notification": state.last_notification.hex(),
        "last_frame": frame.hex if frame else None,
        "last_payload": frame.payload_hex if frame else None,
        "last_outer_type": f"0x{frame.outer_type:02x}" if frame else None,
        "last_packet_type": frame.packet_type_name if frame else None,
        "last_protocol_type": frame.protocol_type_name if frame else None,
        "checksum_little_endian": f"0x{frame.checksum:04x}" if frame else None,
        "discarded_bytes": state.discarded_bytes,
        "invalid_frames": state.invalid_frames,
        "crc_errors": state.crc_errors,
        "connection_attempts": state.connection_attempts,
        "disconnect_count": state.disconnect_count,
        "advertisement_count": state.advertisement_count,
        "advertisement_waits": state.advertisement_waits,
        "advertisement_timeouts": state.advertisement_timeouts,
        "last_advertisement_at": state.last_advertisement_at,
        "last_advertisement_rssi": state.last_advertisement_rssi,
        "last_advertisement_source": state.last_advertisement_source,
        "last_advertisement_name": state.last_advertisement_name,
        "last_advertisement_connectable": state.last_advertisement_connectable,
        "candidate_source_count": state.candidate_source_count,
        "candidate_sources": state.candidate_sources,
        "selected_source": state.selected_source,
        "selected_source_rssi": state.selected_source_rssi,
        "source_connection_attempts": state.source_connection_attempts,
        "source_fallbacks": state.source_fallbacks,
        "last_failed_source": state.last_failed_source,
        "pairing_attempts": state.pairing_attempts,
        "pairing_success": state.pairing_success,
        "pairing_last_error": state.pairing_last_error,
        "authorization_retries": state.authorization_retries,
        "ble_pairing_strategy": "disabled_fresh_advertisement_immediate_connect",
        "advertisement_wait_timeout_seconds": 45,
        "adapter_collection_window_seconds": ADAPTER_COLLECTION_WINDOW,
        "source_selection": "first_fresh_connectable_then_same-turn_fallbacks",
        "connect_attempts_per_source": 1,
        "notify_timeout_seconds": 10,
        "tx_count": state.tx_count,
        "tx_chunk_count": state.tx_chunk_count,
        "last_tx": "<redacted CONNECT/REQ>" if state.last_tx_kind == "CONNECT/REQ" else state.last_tx.hex(),
        "last_tx_kind": state.last_tx_kind,
        "last_tx_at": state.last_tx_at,
        "tx_write_mode": state.tx_write_mode,
        "tx_chunk_size": state.tx_chunk_size,
        "application_auth_state": state.application_auth_state,
        "application_connect_attempts": state.application_connect_attempts,
        "application_auth_success_count": state.application_auth_success_count,
        "handshake_sent_at": state.handshake_sent_at,
        "handshake_response_at": state.handshake_response_at,
        "handshake_last_error": state.handshake_last_error,
        "session_id": f"0x{state.session_id:08x}" if state.session_id is not None else None,
        "connect_ack_version": state.connect_ack_version,
        "connect_ack_flag": state.connect_ack_flag,
        "status_polling_active": state.status_polling_active,
        "status_poll_interval_seconds": STATUS_POLL_INTERVAL,
        "status_request_count": state.status_request_count,
        "status_response_count": state.status_response_count,
        "status_nack_count": state.status_nack_count,
        "status_request_errors": state.status_request_errors,
        "last_status_request_at": state.last_status_request_at,
        "last_status_response_at": state.last_status_response_at,
        "last_status_payload": state.last_status_payload.hex(),
        "decoded_status": (
            {
                "device_state": status.device_state,
                "device_state_name": device_state_name(status.device_state),
                "state_timer_seconds": status.state_timer,
                "fan_speed_percent": status.fan_speed,
                "chimney_temperature_raw_tenths": status.chimney_temperature_raw,
                "chimney_temperature_c": status.chimney_temperature,
                "outside_temperature_raw_tenths": status.outside_temperature_raw,
                "outside_temperature_c": status.outside_temperature,
                "inside_temperature_raw_tenths": status.inside_temperature_raw,
                "inside_temperature_c": status.inside_temperature,
                "air_pressure_hpa": status.air_pressure_hpa,
                "flags": status.flags,
                "global_0x20_raw_unidentified": state.globals.get(0x20),
            }
            if status
            else None
        ),
        "global_update_count": state.global_update_count,
        "globals": {
            f"0x{global_id:02x}_{GLOBAL_NAMES.get(global_id, 'UNKNOWN').lower()}": value
            for global_id, value in sorted(state.globals.items())
        },
        "last_global_id": f"0x{state.last_global_id:02x}" if state.last_global_id is not None else None,
        "last_global_name": state.last_global_name,
        "last_global_value": state.last_global_value,
        "last_global_at": state.last_global_at,
        "packet_history": list(state.packet_history),
        "last_error": state.last_error,
        "application_pin_auth_enabled": True,
        "application_status_polling_enabled": True,
        "application_time_field": 0,
        "application_client_name": "HomeAssistant",
        "diagnostic_entities_enabled_by_default": True,
        "control_writes_enabled": CONTROL_WRITES_ENABLED,
        "experimental_global_writes_enabled": EXPERIMENTAL_GLOBAL_WRITES_ENABLED,
        "boost_writes_enabled": BOOST_WRITES_ENABLED,
        "ventilation_writes_enabled": VENTILATION_WRITES_ENABLED,
        "global_write_request_count": state.global_write_request_count,
        "global_write_ack_count": state.global_write_ack_count,
        "global_write_nack_count": state.global_write_nack_count,
        "last_global_write_id": (f"0x{state.last_global_write_id:02X}" if state.last_global_write_id is not None else None),
        "last_global_write_value": state.last_global_write_value,
        "last_global_write_request_at": state.last_global_write_request_at,
        "last_global_write_response": state.last_global_write_response,
        "last_global_write_response_at": state.last_global_write_response_at,
        "boost_request_count": state.boost_request_count,
        "boost_ack_count": state.boost_ack_count,
        "boost_nack_count": state.boost_nack_count,
        "last_boost_action": state.last_boost_action,
        "last_boost_request_at": state.last_boost_request_at,
        "last_boost_response": state.last_boost_response,
        "last_boost_response_at": state.last_boost_response_at,
        "ventilation_request_count": state.ventilation_request_count,
        "ventilation_ack_count": state.ventilation_ack_count,
        "ventilation_nack_count": state.ventilation_nack_count,
        "last_ventilation_action": state.last_ventilation_action,
        "last_ventilation_request_at": state.last_ventilation_request_at,
        "last_ventilation_response": state.last_ventilation_response,
        "last_ventilation_response_at": state.last_ventilation_response_at,
        "ventilation_is_on": state.ventilation_is_on,
        "boost_is_on": state.boost_is_on,
        "last_mode_status_at": state.last_mode_status_at,
        "feature_matrix": {
            feature.key: {
                "name": feature.name,
                "kind": feature.kind,
                "readiness": feature.state,
                "global_id": (f"0x{feature.global_id:02X}" if feature.global_id is not None else None),
                "packet_type": (f"0x{feature.packet_type:02X}" if feature.packet_type is not None else None),
            }
            for feature in FEATURES
        },
    }
