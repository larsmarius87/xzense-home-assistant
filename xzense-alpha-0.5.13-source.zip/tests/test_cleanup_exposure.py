"""Lightweight non-HA tests guarding cleanup exposure and raw data retention."""
import ast
from pathlib import Path

COMPONENT = Path(__file__).parents[1] / "custom_components" / "xzense_full_preview"


def test_candidate_controls_not_exposed_as_unavailable_entities():
    for module, symbol in (
        ("number.py", "NUMBER_FEATURES"),
        ("button.py", "BUTTON_FEATURES"),
        ("select.py", "SELECT_FEATURES"),
        ("switch.py", "SWITCH_FEATURES"),
    ):
        source = (COMPONENT / module).read_text(encoding="utf-8")
        assert 'f.state == "write_ready"' in source, module


def test_full_raw_global_dump_is_still_available():
    source = (COMPONENT / "diagnostics.py").read_text(encoding="utf-8")
    assert 'for global_id, value in sorted(state.globals.items())' in source
    assert '"packet_history": list(state.packet_history)' in source


def test_obsolete_entity_registry_cleanup_is_explicit():
    source = (COMPONENT / "__init__.py").read_text(encoding="utf-8")
    assert '"burn_count", "operation_time", "error_log"' in source
    assert '"language_raw", "download_log"' in source
