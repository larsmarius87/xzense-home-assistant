"""Regression tests for deliberately deferred external control fields."""
from pathlib import Path

ROOT = Path(__file__).parents[1]
COMPONENT = ROOT / "custom_components" / "xzense_full_preview"


def test_legacy_external_entities_still_cleaned_from_registry():
    source = (COMPONENT / "__init__.py").read_text(encoding="utf-8")
    assert '"external_start"' in source
    assert '"external_fan_speed"' in source
    assert "registry.async_remove(entity_entry.entity_id)" in source


def test_raw_globals_are_preserved_with_labels():
    protocol = (COMPONENT / "protocol.py").read_text(encoding="utf-8")
    diagnostics = (COMPONENT / "diagnostics.py").read_text(encoding="utf-8")
    assert '0x57: "EXTERN_START"' in protocol
    assert '0x5A: "EXTERN_FAN_SPEED"' in protocol
    assert 'for global_id, value in sorted(state.globals.items())' in diagnostics


def test_ambiguous_power_source_preserved_and_ventilation_untouched():
    sensor = (COMPONENT / "sensor.py").read_text(encoding="utf-8")
    assert "return state.globals.get(0x05)" in sensor
    assert 'SensorDescription("battery", "0x05 status", _status_0x05' in sensor
    features = (COMPONENT / "features.py").read_text(encoding="utf-8")
    assert '"ventilation",' in features
    assert 'packet_type=0x09' in features
