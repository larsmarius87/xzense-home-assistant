"""Regression tests for CONNECT ACK firmware version formatting."""
from pathlib import Path
import importlib.util
import sys

PATH = Path(__file__).parents[1] / "custom_components" / "xzense_full_preview" / "version.py"
spec = importlib.util.spec_from_file_location("xzense_version_test", PATH)
version = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = version
spec.loader.exec_module(version)


def test_observed_410_maps_to_4_10():
    assert version.format_firmware_version(410) == "4.10"

def test_future_minor_version_keeps_two_digit_minor():
    assert version.format_firmware_version(420) == "4.20"

def test_single_digit_minor_is_readable():
    assert version.format_firmware_version(407) == "4.7"

def test_missing_version_stays_unknown():
    assert version.format_firmware_version(None) is None
