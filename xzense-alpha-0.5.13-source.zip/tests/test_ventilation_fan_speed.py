"""Cross-layer regressions for the live-verified Ventilation fan-speed setpoint."""

from pathlib import Path
import importlib.util
import sys

ROOT = Path(__file__).parents[1]
COMPONENT = ROOT / "custom_components" / "xzense_full_preview"


def _load_python(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, COMPONENT / filename)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def test_0x50_is_one_setpoint_in_operation_and_ventilation():
    features = _load_python("xzense_fan_speed_features_test", "features.py")
    setting = features.FEATURE_BY_KEY["user_fan_speed"]
    actual = features.FEATURE_BY_KEY["fan_speed"]
    assert setting.name == "Fan speed"
    assert setting.global_id == 0x50
    assert setting.state == "write_ready"
    assert actual.name == "Actual fan speed"
    assert actual.global_id == 0x1F
    # The legacy feature keys intentionally preserve existing entity unique IDs.
    assert setting.key == "user_fan_speed"
    assert actual.key == "fan_speed"


def test_ventilation_capture_matches_direct_percent_encoding():
    settings = _load_python("xzense_fan_speed_settings_test", "settings.py")
    # Device emitted GLOBAL 0x50 values 11..16 in state 8; 16% was reported in STATUS.
    for percent in range(10, 17):
        assert settings.raw_to_native("user_fan_speed", percent) == float(percent)
        assert settings.native_to_raw("user_fan_speed", percent) == percent
    assert settings.SETTING_RULES["user_fan_speed"].minimum == 10
    assert settings.SETTING_RULES["user_fan_speed"].maximum == 100


def test_ha_fan_speed_is_not_state_gated():
    number_source = (COMPONENT / "number.py").read_text(encoding="utf-8")
    assert "current_device_state() in {4, 8}" not in number_source
    assert "current_device_state() not in {4, 8}" not in number_source
    assert "await self.client.async_execute_feature(self.feature.key, raw)" in number_source

def test_live_status_and_globals_are_kept_separate():
    sensor_source = (COMPONENT / "sensor.py").read_text(encoding="utf-8")
    assert '"Actual fan speed",\n        lambda s: _status_or_global(s, "fan_speed", 0x1F)' in sensor_source


def _isolated_ha_number_class():
    """Execute the actual two changed HA methods with lightweight stand-ins."""
    import ast
    source = (COMPONENT / "number.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    original = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "XzenseNumber")
    methods = [n for n in original.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == "async_set_native_value"]
    cls = ast.ClassDef(
        name="XzenseNumber",
        bases=[ast.Name(id="DummyBase", ctx=ast.Load())],
        keywords=[],
        body=methods,
        decorator_list=[],
    )

    class DummyBase:
        @property
        def available(self):
            return self.base_available

    scope = {
        "DummyBase": DummyBase,
        "HomeAssistantError": RuntimeError,
        "native_to_raw": lambda key, value: int(value),
        "property": property,
    }
    exec(compile(ast.fix_missing_locations(ast.Module(body=[cls], type_ignores=[])), str(COMPONENT / "number.py"), "exec"), scope)
    return scope["XzenseNumber"]


def test_runtime_ha_number_write_in_any_state():
    import asyncio
    from types import SimpleNamespace
    cls = _isolated_ha_number_class()
    control = cls()
    control.feature = SimpleNamespace(key="user_fan_speed")
    written = []
    async def execute_feature(key, raw):
        written.append((key, raw))
    control.client = SimpleNamespace(async_execute_feature=execute_feature)
    for value in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]:
        asyncio.run(control.async_set_native_value(16))
    assert written == [("user_fan_speed", 16)] * 11
