"""Verifies status-derived switch state without requiring a HA installation."""
from pathlib import Path
import ast
import asyncio
from types import SimpleNamespace

COMPONENT = Path(__file__).parents[1] / "custom_components" / "xzense_full_preview"
CLIENT = (COMPONENT / "client.py").read_text()
SWITCH = (COMPONENT / "switch.py").read_text()
INIT = (COMPONENT / "__init__.py").read_text()


def test_status_mode_flags_only_update_on_decoded_status():
    tree = ast.parse(CLIENT)
    cls = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == "XzenseClient")
    fn = next(x for x in cls.body if isinstance(x, ast.FunctionDef) and x.name == "_update_mode_switches")
    fn.decorator_list = []
    scope = {"_utc_now": lambda: "fresh"}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[])), "client.py", "exec"), scope)
    client = SimpleNamespace(state=SimpleNamespace(boost_is_on=None, ventilation_is_on=None, last_mode_status_at=None))
    sync = scope["_update_mode_switches"]
    sync(client, 3)
    assert (client.state.boost_is_on, client.state.ventilation_is_on) == (True, False)
    sync(client, 7)
    assert (client.state.boost_is_on, client.state.ventilation_is_on) == (True, False)
    sync(client, 8)
    assert (client.state.boost_is_on, client.state.ventilation_is_on) == (False, True)
    sync(client, 4)
    assert (client.state.boost_is_on, client.state.ventilation_is_on) == (False, False)
    assert client.state.last_mode_status_at == "fresh"


def test_connect_reconnect_keeps_mode_values_until_status():
    assert "self.state.status = None" in CLIENT
    assert "self.state.globals.clear()" in CLIENT
    assert "self.state.boost_is_on = None" not in CLIENT
    assert "self.state.ventilation_is_on = None" not in CLIENT
    assert "self._update_mode_switches(status.device_state)" in CLIENT
    assert "self._session_ready.set()" in CLIENT
    assert "await self._send_status_request(client, session_id)" in CLIENT
    assert "self.state.ventilation_is_on = self.state.ventilation_pending_value" not in CLIENT


def test_switches_restore_last_value_without_overriding_fresh_status():
    assert "RestoreEntity" in SWITCH
    assert "await self.async_get_last_state()" in SWITCH
    assert "self.client.state.boost_is_on is None" in SWITCH
    assert "self.client.state.ventilation_is_on is None" in SWITCH
    assert "await self.client.async_set_boost(True)" in SWITCH
    assert "await self.client.async_set_boost(False)" in SWITCH
    assert "await self.client.async_set_ventilation(True)" in SWITCH


def test_remove_legacy_entity_ids_without_removing_new_boost_switch():
    assert 'entity_entry.domain == "button"' in INIT
    assert 'f"{entry.data[CONF_ADDRESS]}_boost"' in INIT
    assert '"boost_on", "boost_off", "start_afterrun"' in INIT
    assert '"ble_release_seconds", "release_ble_to_app"' in INIT


def test_release_pause_code_is_gone():
    assert "ble_release" not in CLIENT
    assert "Release Bluetooth to app" not in (COMPONENT / "button.py").read_text()
    assert "Bluetooth app release time" not in (COMPONENT / "number.py").read_text()
