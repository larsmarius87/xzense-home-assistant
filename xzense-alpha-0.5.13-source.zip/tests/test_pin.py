"""PIN normalization tests; no Home Assistant install required."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "custom_components" / "xzense_full_preview"))

from const import normalize_pin  # noqa: E402


def test_pin_normalization() -> None:
    assert normalize_pin("5ff0") == "5FF0"
    assert normalize_pin(" 5FF0 ") == "5FF0"
    assert normalize_pin("0000") == "0000"
    assert normalize_pin("FFFF") == "FFFF"
    assert normalize_pin("5FG0") is None
    assert normalize_pin("5FF") is None
    assert normalize_pin("5FF00") is None


if __name__ == "__main__":
    test_pin_normalization()
    print("PIN tests: OK")

