"""Xzense 4.10 RC2 control-path regressions."""
from pathlib import Path

ROOT = Path(__file__).parents[1]
BUTTON = (ROOT / "custom_components" / "xzense_full_preview" / "button.py").read_text(encoding="utf-8")
NUMBER = (ROOT / "custom_components" / "xzense_full_preview" / "number.py").read_text(encoding="utf-8")


def test_refuel_enabled_in_operation_4_and_burnout_5():
    assert 'if self.feature.key == "refuel":\n            return self.client.boost_available() and state in {4, 5}' in BUTTON


def test_stop_firing_uses_boost_off_for_boosting_and_reheating():
    assert 'if state in {3, 7}:\n                await self.client.async_set_boost(False)' in BUTTON


def test_stop_firing_preserves_afterrun_write_and_finish_firing_is_removed():
    assert 'await self.client.async_execute_feature("stop_fire", 6)' in BUTTON
    assert 'start_afterrun' not in BUTTON
    assert 'Finish firing' not in BUTTON


def test_fan_speed_has_no_state_gate():
    assert 'self.client.current_device_state() in {4, 8}' not in NUMBER
    assert 'self.client.current_device_state() not in {4, 8}' not in NUMBER
    assert 'await self.client.async_execute_feature(self.feature.key, raw)' in NUMBER
