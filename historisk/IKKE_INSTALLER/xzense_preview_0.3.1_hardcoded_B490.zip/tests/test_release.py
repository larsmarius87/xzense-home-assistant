from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

def test_release_version_and_hardcoded_pin():
    manifest = json.loads((ROOT / "custom_components/xzense_preview/manifest.json").read_text())
    assert manifest["version"] == "0.3.1"
    assert manifest["domain"] == "xzense_preview"
    const = (ROOT / "custom_components/xzense_preview/const.py").read_text()
    init = (ROOT / "custom_components/xzense_preview/__init__.py").read_text()
    flow = (ROOT / "custom_components/xzense_preview/config_flow.py").read_text()
    assert 'HARDCODED_PIN = "B490"' in const
    assert 'HARDCODED_PIN,' in init
    assert 'CONF_PIN' not in flow
