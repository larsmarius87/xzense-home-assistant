# Changelog

## 0.3.1
- Hardcode Xzense application PIN to `B490` for this preview/test build.
- Ignore any PIN stored in an existing config entry.
- Remove PIN prompts from setup.
- CONNECT/NACK is reported as `hardcoded_pin_rejected` instead of starting reauthentication.

# Changelog

## 0.3.0

- Separate `xzense_preview` domain so the preview can be installed without overwriting the regular integration.
- Explicitly blocks BLE activity while the regular `xzense` integration is loaded.
- PIN prompt on setup; no default PIN.
- Automatic reauthentication prompt after CONNECT/NACK.
- Verified CONNECT/PIN login, session ID handling and STATUS polling.
- Live chimney, inside and outside temperature plus fan-speed entities.
- Passive GLOBAL/DATA decoding and full diagnostics enabled by default.
- Primary connectivity entity represents the authenticated application session.
- Separate diagnostic BLE-link entity.
- No unverified physical control writes.
