"""Bluetooth client for Xzense."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
import logging

from bleak.backends.characteristic import BleakGATTCharacteristic
from bleak_retry_connector import BleakClientWithServiceCache, establish_connection

from homeassistant.components import bluetooth
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback

from .const import NOTIFY_UUID, WRITE_UUID
from .protocol import (
    PACKET_STATUS,
    PROTOCOL_NACK,
    XzenseFrame,
    XzenseFrameParser,
    XzenseStatusData,
    build_connect_request,
    build_status_request,
    decode_global_data,
    decode_status_data,
    global_name,
)

_LOGGER = logging.getLogger(__name__)

Listener = Callable[[], None]

NOTIFY_TIMEOUT = 10.0
ADVERTISEMENT_WAIT_TIMEOUT = 45.0
ADAPTER_COLLECTION_WINDOW = 0.0
APPLICATION_CLIENT_NAME = "HomeAssistant"
STATUS_POLL_INTERVAL = 10.0
PACKET_HISTORY_LIMIT = 20


def _utc_now() -> str:
    """Return an ISO-8601 UTC timestamp for diagnostics."""
    return datetime.now(UTC).isoformat(timespec="milliseconds")


@dataclass(slots=True)
class XzenseState:
    """Runtime state exposed by the experimental read-only integration."""

    connected: bool = False
    ble_link_connected: bool = False
    notifications_active: bool = False
    phase: str = "idle"
    phase_changed_at: str | None = None
    ble_connected_at: str | None = None
    notify_started_at: str | None = None
    notify_active_at: str | None = None
    last_notification_at: str | None = None
    last_disconnect_at: str | None = None
    packet_count: int = 0
    notification_count: int = 0
    last_notification: bytes = b""
    last_frame: XzenseFrame | None = None
    last_error: str | None = None
    discarded_bytes: int = 0
    invalid_frames: int = 0
    crc_errors: int = 0
    connection_attempts: int = 0
    disconnect_count: int = 0

    # Fresh-advertisement connection diagnostics (v0.2.5+).
    advertisement_count: int = 0
    advertisement_waits: int = 0
    advertisement_timeouts: int = 0
    last_advertisement_at: str | None = None
    last_advertisement_rssi: int | None = None
    last_advertisement_source: str | None = None
    last_advertisement_name: str | None = None
    last_advertisement_connectable: bool | None = None

    # Multi-adapter/source selection diagnostics (v0.2.6).
    candidate_source_count: int = 0
    candidate_sources: str = ""
    selected_source: str | None = None
    selected_source_rssi: int | None = None
    source_connection_attempts: int = 0
    source_fallbacks: int = 0
    last_failed_source: str | None = None

    # Kept for backwards-compatible diagnostics while BLE pairing is disabled.
    pairing_attempts: int = 0
    pairing_success: bool = False
    pairing_last_error: str | None = None
    authorization_retries: int = 0

    # TX/application session diagnostics (v0.2.7).
    tx_count: int = 0
    tx_chunk_count: int = 0
    last_tx: bytes = b""
    last_tx_at: str | None = None
    tx_write_mode: str | None = None
    tx_chunk_size: int | None = None

    application_auth_state: str = "not_started"
    application_connect_attempts: int = 0
    application_auth_success_count: int = 0
    handshake_sent_at: str | None = None
    handshake_response_at: str | None = None
    handshake_last_error: str | None = None
    session_id: int | None = None
    connect_ack_version: int | None = None
    connect_ack_flag: int | None = None

    # Read-only live status polling (v0.3.0).
    status_polling_active: bool = False
    status_request_count: int = 0
    status_response_count: int = 0
    status_nack_count: int = 0
    status_request_errors: int = 0
    last_status_request_at: str | None = None
    last_status_response_at: str | None = None
    last_status_payload: bytes = b""
    status: XzenseStatusData | None = None

    # GLOBAL/DATA cache. These are passive reads only; v0.3.0 never writes a global.
    globals: dict[int, int] = field(default_factory=dict)
    global_update_count: int = 0
    last_global_id: int | None = None
    last_global_name: str | None = None
    last_global_value: int | None = None
    last_global_at: str | None = None

    # Short validated-frame history for diagnostics/reverse engineering.
    packet_history: list[dict[str, object]] = field(default_factory=list)
    last_tx_kind: str | None = None


class XzenseClient:
    """Maintain the BLE/app session and read live Xzense status.

    v0.3.0 preserves the fresh-advertisement connection strategy and recovered
    CONNECT/PIN handshake proven on the real controller. After CONNECT/ACK it
    sends the official read-only STATUS/REQ every 10 seconds. Besides refreshing
    live temperature/fan values, this keeps the authenticated application session
    active so a successful BLE connection is not needlessly torn down for
    inactivity. No fan speed, mode, ventilation or setting writes are enabled.
    """

    def __init__(
        self,
        hass: HomeAssistant,
        entry: ConfigEntry,
        address: str,
        name: str,
        pin: str,
    ) -> None:
        self.hass = hass
        self.entry = entry
        self.address = address
        self.name = name
        self.pin = pin
        self.state = XzenseState()
        self._parser = XzenseFrameParser()
        self._listeners: set[Listener] = set()
        self._client: BleakClientWithServiceCache | None = None
        self._runner: asyncio.Task[None] | None = None
        self._status_runner: asyncio.Task[None] | None = None
        self._wake = asyncio.Event()
        self._session_ready = asyncio.Event()
        self._tx_lock = asyncio.Lock()
        self._stopping = False
        self._reauth_required = False

    @callback
    def async_add_listener(self, listener: Listener) -> Callable[[], None]:
        self._listeners.add(listener)

        @callback
        def remove_listener() -> None:
            self._listeners.discard(listener)

        return remove_listener

    @callback
    def _notify_listeners(self) -> None:
        for listener in tuple(self._listeners):
            listener()

    def _set_phase(self, phase: str) -> None:
        """Update the connection phase and expose it immediately."""
        if self.state.phase == phase:
            return
        self.state.phase = phase
        self.state.phase_changed_at = _utc_now()
        _LOGGER.debug("Xzense %s phase: %s", self.address, phase)
        self._notify_listeners()

    async def async_start(self) -> None:
        """Start the connection manager without blocking config-entry setup."""
        if self._runner and not self._runner.done():
            return
        self._stopping = False
        self._set_phase("starting")
        self._runner = self.entry.async_create_background_task(
            self.hass, self._connection_loop(), f"xzense-{self.address}"
        )
        self._status_runner = self.entry.async_create_background_task(
            self.hass, self._status_loop(), f"xzense-status-{self.address}"
        )

    async def async_stop(self) -> None:
        """Stop reconnects, notifications and the BLE connection."""
        self._stopping = True
        self._wake.set()

        runner = self._runner
        self._runner = None
        if runner:
            runner.cancel()
            try:
                await runner
            except asyncio.CancelledError:
                pass

        status_runner = self._status_runner
        self._status_runner = None
        self._session_ready.clear()
        if status_runner:
            status_runner.cancel()
            try:
                await status_runner
            except asyncio.CancelledError:
                pass

        client = self._client
        self._client = None
        if client and client.is_connected:
            if self.state.notifications_active:
                try:
                    await client.stop_notify(NOTIFY_UUID)
                except Exception:  # best-effort during unload
                    pass
            try:
                await client.disconnect()
            except Exception:  # best-effort during unload
                pass

        self.state.connected = False
        self.state.ble_link_connected = False
        self.state.notifications_active = False
        self._set_phase("stopped")
        self._notify_listeners()

    async def _connection_loop(self) -> None:
        """Wait for fresh advertisements and reconnect while loaded."""
        try:
            while not self._stopping:
                if self._reauth_required:
                    self._set_phase("reauth_required")
                    self._wake.clear()
                    await self._wake.wait()
                    continue

                if not self._client or not self._client.is_connected:
                    connected = await self._connect_once()
                    if not connected:
                        # _connect_once() already waited for a fresh advertisement.
                        # Yield briefly, then wait for the *next* advertisement.
                        self._wake.clear()
                        try:
                            await asyncio.wait_for(self._wake.wait(), timeout=1.0)
                        except TimeoutError:
                            pass
                        continue

                self._wake.clear()
                await self._wake.wait()
        except asyncio.CancelledError:
            raise

    def _record_advertisement(
        self, service_info: bluetooth.BluetoothServiceInfoBleak
    ) -> None:
        """Record a live Xzense advertisement for diagnostics."""
        self.state.advertisement_count += 1
        self.state.last_advertisement_at = _utc_now()
        self.state.last_advertisement_rssi = service_info.rssi
        self.state.last_advertisement_source = service_info.source
        self.state.last_advertisement_name = service_info.name
        self.state.last_advertisement_connectable = service_info.connectable
        _LOGGER.debug(
            "Fresh Xzense advertisement #%d from %s: RSSI=%s source=%s connectable=%s",
            self.state.advertisement_count,
            self.address,
            service_info.rssi,
            service_info.source,
            service_info.connectable,
        )
        self._notify_listeners()

    @staticmethod
    def _source_key(service_info: bluetooth.BluetoothServiceInfoBleak) -> str:
        """Return a stable source key for one HA Bluetooth adapter/proxy."""
        return service_info.source or "unknown"

    @staticmethod
    def _rssi_value(service_info: bluetooth.BluetoothServiceInfoBleak) -> int:
        """Normalize an optional RSSI for deterministic sorting."""
        return service_info.rssi if service_info.rssi is not None else -999

    def _publish_candidates(
        self, candidates: list[bluetooth.BluetoothServiceInfoBleak]
    ) -> None:
        """Expose adapter candidates ordered by strongest RSSI."""
        self.state.candidate_source_count = len(candidates)
        self.state.candidate_sources = " | ".join(
            f"{self._source_key(info)}:{self._rssi_value(info)} dBm"
            for info in candidates
        )
        self._notify_listeners()

    async def _collect_fresh_advertisements(
        self,
    ) -> list[bluetooth.BluetoothServiceInfoBleak]:
        """Collect fresh advertisements from all visible Bluetooth sources.

        We wait up to ADVERTISEMENT_WAIT_TIMEOUT for the first connectable packet and
        return it immediately. Any additional source advertisements already queued
        in the same event-loop turn are retained and RSSI-ranked, but there is no
        deliberate collection delay. Cached replay is disabled.
        """
        self.state.advertisement_waits += 1
        self._set_phase("waiting_for_adapter_candidates")

        bluetooth.async_clear_advertisement_history(self.hass, self.address)

        first_seen = asyncio.Event()
        by_source: dict[str, bluetooth.BluetoothServiceInfoBleak] = {}

        @callback
        def _async_fresh_advertisement(
            service_info: bluetooth.BluetoothServiceInfoBleak,
            _change: bluetooth.BluetoothChange,
        ) -> None:
            self._record_advertisement(service_info)
            key = self._source_key(service_info)
            previous = by_source.get(key)
            if previous is None or self._rssi_value(service_info) > self._rssi_value(previous):
                by_source[key] = service_info
            first_seen.set()

        cancel_callback = bluetooth.async_register_callback(
            self.hass,
            _async_fresh_advertisement,
            {"address": self.address, "connectable": True},
            bluetooth.BluetoothScanningMode.ACTIVE,
            replay=bluetooth.BluetoothCallbackReplay.DISABLED,
        )

        scan_task = self.hass.async_create_task(
            bluetooth.async_request_active_scan(
                ADVERTISEMENT_WAIT_TIMEOUT + ADAPTER_COLLECTION_WINDOW
            )
        )

        try:
            try:
                async with asyncio.timeout(ADVERTISEMENT_WAIT_TIMEOUT):
                    await first_seen.wait()
            except TimeoutError:
                self.state.advertisement_timeouts += 1
                self._set_phase("advertisement_timeout")
                self._set_error(
                    f"Timed out after {ADVERTISEMENT_WAIT_TIMEOUT:.0f}s waiting for a fresh "
                    "connectable Xzense advertisement"
                )
                return []

            self._set_phase("fresh_advertisement_ready")
            # v0.2.8: do not wait after the first live advertisement. Xzense has
            # shown intermittent connect timeouts, and with only one visible HA
            # Bluetooth source the old six-second collection window added latency
            # without providing any fallback benefit. Yield once so callbacks that
            # are already queued can still contribute a candidate.
            await asyncio.sleep(0)

            candidates = sorted(
                by_source.values(), key=self._rssi_value, reverse=True
            )
            self._publish_candidates(candidates)
            self._set_phase("adapter_candidates_ready")
            return candidates
        finally:
            cancel_callback()
            scan_task.cancel()

    async def _establish_source_connection(
        self, service_info: bluetooth.BluetoothServiceInfoBleak
    ) -> BleakClientWithServiceCache:
        """Connect once through the BLEDevice belonging to one live source."""
        ble_device = service_info.device
        if ble_device is None:
            raise RuntimeError("Fresh Xzense advertisement did not include a BLEDevice")

        source = self._source_key(service_info)
        rssi = self._rssi_value(service_info)
        self.state.selected_source = source
        self.state.selected_source_rssi = rssi
        self.state.source_connection_attempts += 1
        self.state.connection_attempts += 1
        self._set_phase("connecting_selected_source")
        _LOGGER.info(
            "Connecting Xzense %s via Bluetooth source %s at %s dBm",
            self.address,
            source,
            rssi,
        )

        client = await establish_connection(
            BleakClientWithServiceCache,
            ble_device,
            ble_device.name or self.name,
            self._disconnected,
            max_attempts=1,
        )
        self._client = client
        self.state.ble_link_connected = bool(client.is_connected)
        self.state.ble_connected_at = _utc_now()
        self._set_phase("ble_connected")
        return client

    async def _write_application_frame(
        self,
        client: BleakClientWithServiceCache,
        frame: bytes,
        kind: str,
    ) -> None:
        """Serialize one application frame over the DSPS write characteristic."""
        characteristic = client.services.get_characteristic(WRITE_UUID)
        if characteristic is None:
            raise RuntimeError(f"Xzense write characteristic {WRITE_UUID} not found")

        properties = set(characteristic.properties or [])
        if "write-without-response" in properties:
            response = False
            try:
                chunk_size = int(characteristic.max_write_without_response_size)
            except Exception:
                chunk_size = 20
            chunk_size = max(1, min(chunk_size, 512))
            write_mode = "write_without_response"
        elif "write" in properties:
            response = True
            chunk_size = 512
            write_mode = "write_with_response"
        else:
            raise RuntimeError(
                f"Xzense write characteristic has unsupported properties: {sorted(properties)}"
            )

        async with self._tx_lock:
            self.state.tx_write_mode = write_mode
            self.state.tx_chunk_size = chunk_size
            self.state.last_tx = frame
            self.state.last_tx_at = _utc_now()
            self.state.last_tx_kind = kind
            _LOGGER.debug(
                "Xzense TX %s: %s",
                kind,
                "<redacted>" if kind == "CONNECT/REQ" else frame.hex(),
            )

            for offset in range(0, len(frame), chunk_size):
                chunk = frame[offset : offset + chunk_size]
                await client.write_gatt_char(characteristic, chunk, response=response)
                self.state.tx_chunk_count += 1
                if offset + chunk_size < len(frame):
                    await asyncio.sleep(0.01)
            self.state.tx_count += 1
            self._notify_listeners()

    async def _send_application_connect(
        self, client: BleakClientWithServiceCache
    ) -> None:
        """Send the recovered Xzense CONNECT/REQ application handshake."""
        frame = build_connect_request(self.pin, APPLICATION_CLIENT_NAME)
        self.state.application_connect_attempts += 1
        self.state.application_auth_state = "sending_connect"
        self.state.handshake_last_error = None
        self._set_phase("sending_application_connect")

        _LOGGER.info(
            "Sending Xzense CONNECT/REQ #%d (%d bytes) to %s",
            self.state.application_connect_attempts,
            len(frame),
            self.address,
        )

        # Set this before writing because the controller may ACK immediately.
        self.state.handshake_sent_at = _utc_now()
        try:
            await self._write_application_frame(client, frame, "CONNECT/REQ")
        except Exception as err:
            self.state.application_auth_state = "connect_write_failed"
            self.state.handshake_last_error = f"{type(err).__name__}: {err}"
            self._set_phase("application_connect_write_failed")
            self._notify_listeners()
            raise

        if self.state.application_auth_state == "sending_connect":
            self.state.application_auth_state = "connect_sent"
            self._set_phase("application_connect_sent")
        self._notify_listeners()

    async def _send_status_request(
        self, client: BleakClientWithServiceCache, session_id: int
    ) -> None:
        """Send the captured read-only STATUS/REQ for the active session."""
        frame = build_status_request(session_id)
        self.state.status_request_count += 1
        self.state.last_status_request_at = _utc_now()
        try:
            await self._write_application_frame(client, frame, "STATUS/REQ")
        except Exception as err:
            self.state.status_request_errors += 1
            self.state.last_error = f"STATUS/REQ {type(err).__name__}: {err}"
            self._notify_listeners()
            raise

    async def _status_loop(self) -> None:
        """Poll live read-only status while an authenticated session is active."""
        try:
            while not self._stopping:
                await self._session_ready.wait()
                if self._stopping:
                    return

                self.state.status_polling_active = True
                self._notify_listeners()
                # Keep polling until disconnect clears the session event.
                while self._session_ready.is_set() and not self._stopping:
                    client = self._client
                    session_id = self.state.session_id
                    if not client or not client.is_connected or session_id is None:
                        break
                    try:
                        await self._send_status_request(client, session_id)
                    except asyncio.CancelledError:
                        raise
                    except Exception:
                        _LOGGER.debug(
                            "Xzense STATUS/REQ failed for %s", self.address, exc_info=True
                        )
                        if not client.is_connected:
                            break

                    await asyncio.sleep(STATUS_POLL_INTERVAL)

                self.state.status_polling_active = False
                self._notify_listeners()
                # The event may have been set again by a very fast reconnect.
                if self._session_ready.is_set():
                    await asyncio.sleep(0)
        except asyncio.CancelledError:
            raise
        finally:
            self.state.status_polling_active = False

    async def _connect_once(self) -> bool:
        candidates = await self._collect_fresh_advertisements()
        if not candidates or self._stopping:
            return False

        last_error: Exception | None = None

        # Strongest source first. If it fails, immediately try the next source
        # observed during the same fresh scan window before waiting for new ads.
        for index, service_info in enumerate(candidates):
            if self._stopping:
                return False

            client: BleakClientWithServiceCache | None = None
            source = self._source_key(service_info)
            try:
                if index:
                    self.state.source_fallbacks += 1
                    self._set_phase("trying_next_adapter_source")

                client = await self._establish_source_connection(service_info)
                self._parser.reset()
                self._session_ready.clear()
                self.state.status_polling_active = False
                self.state.session_id = None
                self.state.status = None
                self.state.last_status_payload = b""
                self.state.globals.clear()
                self.state.application_auth_state = "not_started"

                self.state.notify_started_at = _utc_now()
                self._set_phase("enabling_notifications")
                try:
                    await asyncio.wait_for(
                        client.start_notify(NOTIFY_UUID, self._notification),
                        timeout=NOTIFY_TIMEOUT,
                    )
                except Exception as notify_err:
                    if self._is_authorization_error(notify_err):
                        self.state.authorization_retries += 1
                    raise

                self.state.notifications_active = True
                self.state.notify_active_at = _utc_now()
                self.state.connected = True
                self.state.ble_link_connected = bool(client.is_connected)
                self.state.last_error = None
                self._set_phase("notifications_active")
                self._notify_listeners()

                # The controller sends no unsolicited data and closes the BLE link
                # after about 20 seconds unless the application session is opened.
                # Send only the recovered, non-control CONNECT/REQ handshake.
                await self._send_application_connect(client)

                _LOGGER.info(
                    "Connected Xzense protocol monitor to %s via %s (%s dBm); application CONNECT sent",
                    self.address,
                    source,
                    self._rssi_value(service_info),
                )
                return True

            except Exception as err:
                last_error = err
                self.state.last_failed_source = source
                if client and client.is_connected:
                    try:
                        await client.disconnect()
                    except Exception:
                        pass
                self._client = None
                self.state.connected = False
                self.state.ble_link_connected = False
                self.state.notifications_active = False
                self._set_error(f"{type(err).__name__}: {err}")
                _LOGGER.debug(
                    "Unable to connect/subscribe Xzense %s via source %s",
                    self.address,
                    source,
                    exc_info=True,
                )

        self._set_phase("all_adapter_sources_failed")
        if last_error is not None:
            self._set_error(f"{type(last_error).__name__}: {last_error}")
        bluetooth.async_clear_advertisement_history(self.hass, self.address)
        return False

    @staticmethod
    def _is_authorization_error(err: Exception) -> bool:
        """Return True for the GATT authorization failure seen on Xzense."""
        message = str(err).lower()
        return (
            "insufficient authorization" in message
            or "authorization (8)" in message
            or "gatterrorresponse: insufficient authorization" in message
        )

    def _disconnected(self, _client: BleakClientWithServiceCache) -> None:
        """Bleak disconnected callback."""
        self._client = None
        self.state.connected = False
        self.state.ble_link_connected = False
        self.state.notifications_active = False
        self.state.status_polling_active = False
        self._session_ready.clear()
        self.state.disconnect_count += 1
        self.state.last_disconnect_at = _utc_now()
        if self.state.application_auth_state == "connected":
            self.state.application_auth_state = "disconnected_after_ack"
        elif self.state.application_auth_state in ("connect_sent", "sending_connect"):
            self.state.application_auth_state = "disconnected_before_ack"
        self._set_phase("disconnected")
        self._notify_listeners()
        self._wake.set()

    def _record_frame_history(self, frame: XzenseFrame) -> None:
        """Keep a compact history of validated protocol frames."""
        self.state.packet_history.append(
            {
                "at": _utc_now(),
                "packet": frame.packet_type_name,
                "protocol": frame.protocol_type_name,
                "frame": frame.hex,
                "application_payload": frame.application_payload.hex(),
            }
        )
        if len(self.state.packet_history) > PACKET_HISTORY_LIMIT:
            del self.state.packet_history[:-PACKET_HISTORY_LIMIT]

    def _notification(
        self, _characteristic: BleakGATTCharacteristic, data: bytearray
    ) -> None:
        payload = bytes(data)
        self.state.notification_count += 1
        self.state.last_notification = payload
        self.state.last_notification_at = _utc_now()

        _LOGGER.debug(
            "Xzense raw RX notification #%d: %s",
            self.state.notification_count,
            payload.hex(),
        )

        frames = self._parser.feed(payload)
        self.state.discarded_bytes = self._parser.discarded_bytes
        self.state.invalid_frames = self._parser.invalid_frames
        self.state.crc_errors = self._parser.crc_errors

        for frame in frames:
            self.state.packet_count += 1
            self.state.last_frame = frame
            self._record_frame_history(frame)
            _LOGGER.debug(
                "Xzense RX frame #%d: %s outer=%02x packet=%s protocol=%s payload=%s crc=%04x",
                self.state.packet_count,
                frame.hex,
                frame.outer_type,
                frame.packet_type_name,
                frame.protocol_type_name,
                frame.payload_hex or "<empty>",
                frame.checksum,
            )

            if frame.is_connect_ack:
                self.state.application_auth_state = "connected"
                self.state.application_auth_success_count += 1
                self.state.handshake_response_at = _utc_now()
                self.state.handshake_last_error = None
                self.state.session_id = frame.session_id
                self.state.connect_ack_version = frame.connect_version
                self.state.connect_ack_flag = frame.connect_flag
                self._set_phase("application_connected")
                self._session_ready.set()
                _LOGGER.info(
                    "Xzense application CONNECT/ACK received: session=%08X version=%s flag=%s",
                    frame.session_id or 0,
                    frame.connect_version,
                    frame.connect_flag,
                )
            elif frame.is_connect_nack:
                self.state.application_auth_state = "hardcoded_pin_rejected"
                self.state.handshake_response_at = _utc_now()
                self.state.handshake_last_error = "CONNECT/NACK received; Xzense PIN was rejected"
                self.state.last_error = "Xzense rejected the hardcoded test PIN"
                self._session_ready.clear()
                self._reauth_required = False
                self._set_phase("hardcoded_pin_rejected")
                _LOGGER.warning("Xzense CONNECT/NACK received; hardcoded test PIN was rejected")
                client = self._client
                if client and client.is_connected:
                    self.hass.async_create_task(client.disconnect())

            status = decode_status_data(frame, self.state.session_id)
            if status is not None:
                self.state.status = status
                self.state.status_response_count += 1
                self.state.last_status_response_at = _utc_now()
                self.state.last_status_payload = status.raw
                _LOGGER.debug(
                    "Xzense STATUS/DATA: chimney=%s outside=%s inside=%s fan=%s raw=%s",
                    status.chimney_temperature,
                    status.outside_temperature,
                    status.inside_temperature,
                    status.fan_speed,
                    status.raw.hex(),
                )
            elif frame.packet_type == PACKET_STATUS and frame.protocol_type == PROTOCOL_NACK:
                self.state.status_nack_count += 1
                _LOGGER.warning("Xzense STATUS/NACK received")

            global_values = decode_global_data(frame, self.state.session_id)
            if global_values is not None:
                for global_id, value in global_values.items():
                    self.state.globals[global_id] = value
                    self.state.global_update_count += 1
                    self.state.last_global_id = global_id
                    self.state.last_global_name = global_name(global_id)
                    self.state.last_global_value = value
                    self.state.last_global_at = _utc_now()
                    _LOGGER.debug(
                        "Xzense GLOBAL/DATA %s (0x%02X)=%s",
                        global_name(global_id),
                        global_id,
                        value,
                    )

        self._notify_listeners()

    def _set_error(self, message: str) -> None:
        if self.state.last_error != message:
            self.state.last_error = message
            self.state.connected = False
            self._notify_listeners()
