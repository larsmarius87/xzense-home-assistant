"""Config flow for Xzense Preview with a fixed test PIN."""

from __future__ import annotations

from typing import Any

import voluptuous as vol

from homeassistant.components.bluetooth import (
    BluetoothServiceInfoBleak,
    async_discovered_service_info,
)
from homeassistant.config_entries import ConfigFlow, ConfigFlowResult
from homeassistant.const import CONF_ADDRESS

from .const import CONF_NAME, DEFAULT_NAME, DOMAIN, SERVICE_UUID


def _looks_like_xzense(info: BluetoothServiceInfoBleak) -> bool:
    name = (info.name or "").lower()
    return "xzense" in name or SERVICE_UUID.lower() in {
        uuid.lower() for uuid in info.service_uuids
    }


class XzenseConfigFlow(ConfigFlow, domain=DOMAIN):
    """Handle Xzense Preview setup."""

    VERSION = 4

    def __init__(self) -> None:
        self._discovery: BluetoothServiceInfoBleak | None = None
        self._discovered: dict[str, BluetoothServiceInfoBleak] = {}

    async def async_step_bluetooth(
        self, discovery_info: BluetoothServiceInfoBleak
    ) -> ConfigFlowResult:
        """Handle automatic Bluetooth discovery."""
        if not _looks_like_xzense(discovery_info):
            return self.async_abort(reason="not_supported")

        await self.async_set_unique_id(discovery_info.address)
        self._abort_if_unique_id_configured()
        self._discovery = discovery_info
        self.context["title_placeholders"] = {
            "name": discovery_info.name or DEFAULT_NAME
        }
        return await self.async_step_bluetooth_confirm()

    async def async_step_bluetooth_confirm(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Confirm a discovered Xzense device."""
        if self._discovery is None:
            return self.async_abort(reason="no_devices_found")

        if user_input is not None:
            return self.async_create_entry(
                title=self._discovery.name or DEFAULT_NAME,
                data={
                    CONF_ADDRESS: self._discovery.address,
                    CONF_NAME: self._discovery.name or DEFAULT_NAME,
                },
            )

        return self.async_show_form(
            step_id="bluetooth_confirm",
            data_schema=vol.Schema({}),
        )

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Let the user choose a discovered Xzense or enter an address manually."""
        if user_input is not None:
            address = user_input[CONF_ADDRESS].strip()
            await self.async_set_unique_id(address, raise_on_progress=False)
            self._abort_if_unique_id_configured()
            info = self._discovered.get(address)
            title = (info.name if info else None) or DEFAULT_NAME
            return self.async_create_entry(
                title=title,
                data={CONF_ADDRESS: address, CONF_NAME: title},
            )

        self._discovered = {
            info.address: info
            for info in async_discovered_service_info(self.hass, connectable=True)
            if _looks_like_xzense(info)
        }

        if self._discovered:
            labels = {
                address: f"{(info.name or DEFAULT_NAME)} ({address})"
                for address, info in self._discovered.items()
            }
            schema = vol.Schema({vol.Required(CONF_ADDRESS): vol.In(labels)})
        else:
            schema = vol.Schema({vol.Required(CONF_ADDRESS): str})

        return self.async_show_form(step_id="user", data_schema=schema)
