# Xzense Preview 0.3.2 — no-auth probe

This is a deliberately isolated experimental build for one question: **can Xzense return read-only status over BLE without the application PIN/CONNECT handshake?**

Behavior:

- waits for a fresh connectable Xzense advertisement;
- opens the BLE/GATT link and enables DSPS notifications;
- **does not send CONNECT/REQ**;
- **does not send any PIN**;
- sends only the recovered read-only `STATUS/REQ` with session ID `0x00000000`;
- repeats the read probe every 5 seconds while the BLE link remains open;
- records all validated replies, NACKs, GLOBAL/DATA and STATUS/DATA;
- never sends fan, mode, boost, ventilation or setting writes.

The regular `xzense` integration must be unloaded/disabled while this preview is running.

Interpretation:

- `status_response_count > 0` or live status values => read-only STATUS works without application authentication.
- `status_nack_count > 0` => controller explicitly rejects the unauthenticated STATUS request.
- repeated `status_request_count` with zero notifications/responses followed by disconnect => controller silently ignores unauthenticated STATUS requests.

This version is a protocol experiment, not a production release.
