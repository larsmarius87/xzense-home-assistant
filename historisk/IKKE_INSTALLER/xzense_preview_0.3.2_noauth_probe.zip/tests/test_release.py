from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]


def test_release_is_noauth_probe():
    manifest = json.loads((ROOT / "custom_components/xzense_preview/manifest.json").read_text())
    assert manifest["version"] == "0.3.2"
    assert manifest["domain"] == "xzense_preview"
    client = (ROOT / "custom_components/xzense_preview/client.py").read_text()
    init = (ROOT / "custom_components/xzense_preview/__init__.py").read_text()
    const = (ROOT / "custom_components/xzense_preview/const.py").read_text()
    assert "NOAUTH_PROBE_SESSION_ID = 0x00000000" in client
    assert "await self._send_application_connect" not in client
    assert "build_connect_request" not in client
    assert "HARDCODED_PIN" not in init
    assert "CONF_PIN" not in const


def test_noauth_probe_status_request_is_zero_session():
    import importlib.util
    import sys
    protocol_path = ROOT / "custom_components/xzense_preview/protocol.py"
    spec = importlib.util.spec_from_file_location("xzense_protocol_release_test", protocol_path)
    protocol = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = protocol
    spec.loader.exec_module(protocol)
    raw = protocol.build_status_request(0)
    frame = protocol.XzenseFrameParser().feed(raw)[0]
    assert frame.packet_type == protocol.PACKET_STATUS
    assert frame.protocol_type == protocol.PROTOCOL_REQ
    assert frame.application_payload == b"\x00\x00\x00\x00"
