# Changelog

## 0.3.2

- Added deliberate no-authentication probe mode.
- Removed all PIN use from runtime setup.
- Removed CONNECT/REQ transmission.
- Sends read-only STATUS/REQ with session ID `0x00000000` every 5 seconds.
- Added explicit no-auth diagnostic flags.
- Live read sensors can become available if a STATUS/GLOBAL response is received without auth.
- No control writes are enabled.
