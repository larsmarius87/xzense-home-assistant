# Xzense protocol notes — 0.3.2 no-auth experiment

## Purpose of this build

The authenticated application flow previously observed is:

`BLE -> notifications -> CONNECT/REQ(PIN) -> CONNECT/ACK(session_id) -> STATUS/REQ(session_id)`

Version 0.3.2 intentionally skips `CONNECT/REQ(PIN)`. It sends only:

`STATUS/REQ(session_id=0x00000000)`

This does **not** claim that zero is a valid session. It is an invalid/empty-session probe designed to determine whether read-only status is gated by the application authentication layer.

---

# Xzense protocol notes – v0.3.0 beta 1

## BLE transport

Service: `0783b03e-8535-b5a0-7140-a304d2495cb7`

- Notify/TX from Xzense: `0783b03e-8535-b5a0-7140-a304d2495cb8`
- Write/RX to Xzense: `0783b03e-8535-b5a0-7140-a304d2495cba`

No BLE pairing is used. The four-character Xzense PIN belongs to the application protocol.

## Frame

Unescaped logical frame:

`23 | size_le16 | 00 | outer_type | payload | crc16_le | 24`

CRC is CRC-16/CCITT-FALSE over `00 | outer_type | payload`.
Reserved bytes `23`, `24`, `27` are escaped after the fixed five-byte header as `27, byte|80`.

## Application packet

Outer type `06` contains:

`packet_type | protocol_type | application_payload`

Known protocol values include DATA=`08`, NACK=`09`, ACK=`0A`, REQ=`0B`.

## CONNECT

CONNECT/REQ:

`02 0B | pin_le16 | time_u32 | name_len | ASCII name`

Home Assistant sends time `00000000` to avoid changing the controller clock.

CONNECT/ACK:

`02 0A | session_id_le32 | version_le16 | flag | ...`

## STATUS

The official-client read request is:

`07 0B | session_id_le32`

For public capture session `0xED249437`, the exact wire frame is:

`2308000006070b379427a4ed398b24`

The controller firmware builds a 19-byte STATUS/DATA body. Recovered offsets:

- byte 0: state selector (kept diagnostic)
- bytes 1–2: auxiliary value (kept diagnostic; semantic meaning not guessed)
- bytes 3–4: `CHIMNEY_TEMP` signed i16 LE
- bytes 5–6: `OUTSIDE_TEMP` signed i16 LE
- bytes 7–8: `INSIDE_TEMP` signed i16 LE
- bytes 9–10: `STATE_TIMER` signed i16 LE
- byte 11: flag (kept diagnostic)
- bytes 12–13: `FAN_SPEED` signed i16 LE
- bytes 14–18: reserved/unused in the recovered build

v0.3.0 beta 1 sends STATUS/REQ every 10 seconds after CONNECT/ACK. It sends no control/global writes.

## GLOBAL/DATA

GLOBAL/DATA values are packed as repeated 3-byte entries:

`global_id_u8 | value_i16_le`

Known IDs recovered from the bundled controller firmware include:

- `1D` INSIDE_TEMP
- `1E` OUTSIDE_TEMP
- `1F` CHIMNEY_TEMP
- `20` FAN_SPEED
- `50` BOOST_FAN_SPEED
- `51` ACTUAL_DRAFT
- `52` USER_FAN_SPEED

The public Bluetooth capture showing fan changes uses GLOBAL/REQ with ID `50`; this build does not replay or generalize those writes because doing so would physically control the chimney fan.
