# Xzense protocol notes – alpha 0.2.6

Known Dialog/Renesas DSPS UUIDs recovered from the Xzense 5.0.2 Android app:

- Service: `0783b03e-8535-b5a0-7140-a304d2495cb7`
- Notify / server TX: `0783b03e-8535-b5a0-7140-a304d2495cb8`
- Write / server RX: `0783b03e-8535-b5a0-7140-a304d2495cba`

The integration is still read-only at the Xzense application-protocol layer. The configured four-hex-character PIN is stored but is not transmitted yet.

## BLE connection strategy in 0.2.6

A live advertisement is required. Cached callback replay is disabled. After the first live advertisement, the integration spends 6 seconds collecting the same Xzense from every HA Bluetooth source/proxy that reports it. One strongest observation is retained per source. Sources are sorted by RSSI and tried in that order, one GATT attempt per source.

This is intended to prevent a weak ESPHome proxy from winning simply because its advertisement arrived first when a stronger local adapter or another proxy can also see the device.
