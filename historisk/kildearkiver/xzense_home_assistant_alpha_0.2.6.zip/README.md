# Xzense Home Assistant – alpha 0.2.6

Experimental local Bluetooth integration for Exodraft Xzense.

## v0.2.6 changes

- Keeps BLE pairing/bonding disabled.
- Waits for fresh, connectable Xzense advertisements with cached replay disabled.
- After the first fresh advertisement, listens for **6 seconds** for the same Xzense through every Home Assistant Bluetooth source/proxy that can see it.
- Keeps the strongest fresh observation from each source and ranks sources by RSSI.
- Attempts the **strongest source first**.
- If that source cannot establish the GATT connection, immediately tries the next strongest source collected in the same scan window before waiting for new advertisements.
- Adds diagnostics for all candidate sources, selected source/RSSI, fallback count and last failed source.
- Keeps all diagnostic entities enabled by default.
- Keeps the configured Xzense application PIN, but still does **not** transmit PIN/login/control frames in this build.

## Current connection sequence

1. Clear advertisement de-duplication history for the Xzense address.
2. Wait for the first new connectable advertisement.
3. Collect advertisements from all visible HA Bluetooth adapters/proxies for 6 seconds.
4. Rank the sources by RSSI.
5. Try one GATT connection through the strongest source.
6. If it fails, try the next source from the same fresh scan set.
7. Once connected, subscribe to DSPS TX notifications (`...5CB8`).
8. Wait for Xzense protocol traffic.
9. On disconnect/failure, repeat from step 1.

No application-protocol writes or fan-control commands are sent in this build.

## Useful diagnostics

- `Bluetooth source candidates` – all fresh sources ranked strongest first, e.g. `AA:BB:...:-58 dBm | CC:DD:...:-76 dBm`
- `Selected Bluetooth source`
- `Selected Bluetooth source RSSI`
- `Bluetooth source connection attempts`
- `Bluetooth source fallbacks`
- `Last failed Bluetooth source`
- `Last Bluetooth error`

## Install / upgrade

Copy `custom_components/xzense` over the existing Xzense custom component and restart Home Assistant. Existing config entries and the stored Xzense PIN are retained.
