"""Bluetooth client for Xzense."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
import logging

from bleak.backends.characteristic import BleakGATTCharacteristic
from bleak_retry_connector import BleakClientWithServiceCache, establish_connection

from homeassistant.components import bluetooth
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback

from .const import NOTIFY_UUID
from .protocol import XzenseFrame, XzenseFrameParser

_LOGGER = logging.getLogger(__name__)

Listener = Callable[[], None]

NOTIFY_TIMEOUT = 10.0
ADVERTISEMENT_WAIT_TIMEOUT = 45.0
ADAPTER_COLLECTION_WINDOW = 6.0


def _utc_now() -> str:
    """Return an ISO-8601 UTC timestamp for diagnostics."""
    return datetime.now(UTC).isoformat(timespec="milliseconds")


@dataclass(slots=True)
class XzenseState:
    """Runtime state exposed by the experimental read-only integration."""

    connected: bool = False
    ble_link_connected: bool = False
    notifications_active: bool = False
    phase: str = "idle"
    phase_changed_at: str | None = None
    ble_connected_at: str | None = None
    notify_started_at: str | None = None
    notify_active_at: str | None = None
    last_notification_at: str | None = None
    last_disconnect_at: str | None = None
    packet_count: int = 0
    notification_count: int = 0
    last_notification: bytes = b""
    last_frame: XzenseFrame | None = None
    last_error: str | None = None
    discarded_bytes: int = 0
    invalid_frames: int = 0
    connection_attempts: int = 0
    disconnect_count: int = 0

    # Fresh-advertisement connection diagnostics (v0.2.5+).
    advertisement_count: int = 0
    advertisement_waits: int = 0
    advertisement_timeouts: int = 0
    last_advertisement_at: str | None = None
    last_advertisement_rssi: int | None = None
    last_advertisement_source: str | None = None
    last_advertisement_name: str | None = None
    last_advertisement_connectable: bool | None = None

    # Multi-adapter/source selection diagnostics (v0.2.6).
    candidate_source_count: int = 0
    candidate_sources: str = ""
    selected_source: str | None = None
    selected_source_rssi: int | None = None
    source_connection_attempts: int = 0
    source_fallbacks: int = 0
    last_failed_source: str | None = None

    # Kept for backwards-compatible diagnostics while BLE pairing is disabled.
    pairing_attempts: int = 0
    pairing_success: bool = False
    pairing_last_error: str | None = None
    authorization_retries: int = 0

    # TX discovery diagnostics. v0.2.6 does not transmit application frames yet.
    tx_count: int = 0
    last_tx: bytes = b""
    last_tx_at: str | None = None


class XzenseClient:
    """Maintain a BLE connection and parse Xzense notifications.

    v0.2.6 deliberately does not request Bluetooth pairing/bonding. It avoids
    stale cached BLEDevice objects, waits for fresh advertisements, then gathers
    all Bluetooth adapter/proxy sources that see the Xzense during a short scan
    window. Sources are ranked by RSSI. The strongest is tried first and, if it
    fails, the next strongest fresh source is tried before waiting for new ads.

    No Xzense application-protocol PIN or control writes are sent yet. The PIN
    stored in the config entry is retained for the later application-auth layer
    once the first app->Xzense frame and its framing/CRC/sequence semantics are
    proven.
    """

    def __init__(
        self,
        hass: HomeAssistant,
        entry: ConfigEntry,
        address: str,
        name: str,
        pin: str,
    ) -> None:
        self.hass = hass
        self.entry = entry
        self.address = address
        self.name = name
        self.pin = pin
        self.state = XzenseState()
        self._parser = XzenseFrameParser()
        self._listeners: set[Listener] = set()
        self._client: BleakClientWithServiceCache | None = None
        self._runner: asyncio.Task[None] | None = None
        self._wake = asyncio.Event()
        self._stopping = False

    @callback
    def async_add_listener(self, listener: Listener) -> Callable[[], None]:
        self._listeners.add(listener)

        @callback
        def remove_listener() -> None:
            self._listeners.discard(listener)

        return remove_listener

    @callback
    def _notify_listeners(self) -> None:
        for listener in tuple(self._listeners):
            listener()

    def _set_phase(self, phase: str) -> None:
        """Update the connection phase and expose it immediately."""
        if self.state.phase == phase:
            return
        self.state.phase = phase
        self.state.phase_changed_at = _utc_now()
        _LOGGER.debug("Xzense %s phase: %s", self.address, phase)
        self._notify_listeners()

    async def async_start(self) -> None:
        """Start the connection manager without blocking config-entry setup."""
        if self._runner and not self._runner.done():
            return
        self._stopping = False
        self._set_phase("starting")
        self._runner = self.entry.async_create_background_task(
            self.hass, self._connection_loop(), f"xzense-{self.address}"
        )

    async def async_stop(self) -> None:
        """Stop reconnects, notifications and the BLE connection."""
        self._stopping = True
        self._wake.set()

        runner = self._runner
        self._runner = None
        if runner:
            runner.cancel()
            try:
                await runner
            except asyncio.CancelledError:
                pass

        client = self._client
        self._client = None
        if client and client.is_connected:
            if self.state.notifications_active:
                try:
                    await client.stop_notify(NOTIFY_UUID)
                except Exception:  # best-effort during unload
                    pass
            try:
                await client.disconnect()
            except Exception:  # best-effort during unload
                pass

        self.state.connected = False
        self.state.ble_link_connected = False
        self.state.notifications_active = False
        self._set_phase("stopped")
        self._notify_listeners()

    async def _connection_loop(self) -> None:
        """Wait for fresh advertisements and reconnect while loaded."""
        try:
            while not self._stopping:
                if not self._client or not self._client.is_connected:
                    connected = await self._connect_once()
                    if not connected:
                        # _connect_once() already waited for a fresh advertisement.
                        # Yield briefly, then wait for the *next* advertisement.
                        self._wake.clear()
                        try:
                            await asyncio.wait_for(self._wake.wait(), timeout=1.0)
                        except TimeoutError:
                            pass
                        continue

                self._wake.clear()
                await self._wake.wait()
        except asyncio.CancelledError:
            raise

    def _record_advertisement(
        self, service_info: bluetooth.BluetoothServiceInfoBleak
    ) -> None:
        """Record a live Xzense advertisement for diagnostics."""
        self.state.advertisement_count += 1
        self.state.last_advertisement_at = _utc_now()
        self.state.last_advertisement_rssi = service_info.rssi
        self.state.last_advertisement_source = service_info.source
        self.state.last_advertisement_name = service_info.name
        self.state.last_advertisement_connectable = service_info.connectable
        _LOGGER.debug(
            "Fresh Xzense advertisement #%d from %s: RSSI=%s source=%s connectable=%s",
            self.state.advertisement_count,
            self.address,
            service_info.rssi,
            service_info.source,
            service_info.connectable,
        )
        self._notify_listeners()

    @staticmethod
    def _source_key(service_info: bluetooth.BluetoothServiceInfoBleak) -> str:
        """Return a stable source key for one HA Bluetooth adapter/proxy."""
        return service_info.source or "unknown"

    @staticmethod
    def _rssi_value(service_info: bluetooth.BluetoothServiceInfoBleak) -> int:
        """Normalize an optional RSSI for deterministic sorting."""
        return service_info.rssi if service_info.rssi is not None else -999

    def _publish_candidates(
        self, candidates: list[bluetooth.BluetoothServiceInfoBleak]
    ) -> None:
        """Expose adapter candidates ordered by strongest RSSI."""
        self.state.candidate_source_count = len(candidates)
        self.state.candidate_sources = " | ".join(
            f"{self._source_key(info)}:{self._rssi_value(info)} dBm"
            for info in candidates
        )
        self._notify_listeners()

    async def _collect_fresh_advertisements(
        self,
    ) -> list[bluetooth.BluetoothServiceInfoBleak]:
        """Collect fresh advertisements from all visible Bluetooth sources.

        We wait up to ADVERTISEMENT_WAIT_TIMEOUT for the first connectable packet,
        then keep the callback open for ADAPTER_COLLECTION_WINDOW seconds. For
        each HA Bluetooth source/proxy we retain the strongest live advertisement
        seen during that window. Cached replay is disabled.
        """
        self.state.advertisement_waits += 1
        self._set_phase("waiting_for_adapter_candidates")

        bluetooth.async_clear_advertisement_history(self.hass, self.address)

        first_seen = asyncio.Event()
        by_source: dict[str, bluetooth.BluetoothServiceInfoBleak] = {}

        @callback
        def _async_fresh_advertisement(
            service_info: bluetooth.BluetoothServiceInfoBleak,
            _change: bluetooth.BluetoothChange,
        ) -> None:
            self._record_advertisement(service_info)
            key = self._source_key(service_info)
            previous = by_source.get(key)
            if previous is None or self._rssi_value(service_info) > self._rssi_value(previous):
                by_source[key] = service_info
            first_seen.set()

        cancel_callback = bluetooth.async_register_callback(
            self.hass,
            _async_fresh_advertisement,
            {"address": self.address, "connectable": True},
            bluetooth.BluetoothScanningMode.ACTIVE,
            replay=bluetooth.BluetoothCallbackReplay.DISABLED,
        )

        scan_task = self.hass.async_create_task(
            bluetooth.async_request_active_scan(
                ADVERTISEMENT_WAIT_TIMEOUT + ADAPTER_COLLECTION_WINDOW
            )
        )

        try:
            try:
                async with asyncio.timeout(ADVERTISEMENT_WAIT_TIMEOUT):
                    await first_seen.wait()
            except TimeoutError:
                self.state.advertisement_timeouts += 1
                self._set_phase("advertisement_timeout")
                self._set_error(
                    f"Timed out after {ADVERTISEMENT_WAIT_TIMEOUT:.0f}s waiting for a fresh "
                    "connectable Xzense advertisement"
                )
                return []

            self._set_phase("collecting_adapter_candidates")
            await asyncio.sleep(ADAPTER_COLLECTION_WINDOW)

            candidates = sorted(
                by_source.values(), key=self._rssi_value, reverse=True
            )
            self._publish_candidates(candidates)
            self._set_phase("adapter_candidates_ready")
            return candidates
        finally:
            cancel_callback()
            scan_task.cancel()

    async def _establish_source_connection(
        self, service_info: bluetooth.BluetoothServiceInfoBleak
    ) -> BleakClientWithServiceCache:
        """Connect once through the BLEDevice belonging to one live source."""
        ble_device = service_info.device
        if ble_device is None:
            raise RuntimeError("Fresh Xzense advertisement did not include a BLEDevice")

        source = self._source_key(service_info)
        rssi = self._rssi_value(service_info)
        self.state.selected_source = source
        self.state.selected_source_rssi = rssi
        self.state.source_connection_attempts += 1
        self.state.connection_attempts += 1
        self._set_phase("connecting_selected_source")
        _LOGGER.info(
            "Connecting Xzense %s via Bluetooth source %s at %s dBm",
            self.address,
            source,
            rssi,
        )

        client = await establish_connection(
            BleakClientWithServiceCache,
            ble_device,
            ble_device.name or self.name,
            self._disconnected,
            max_attempts=1,
        )
        self._client = client
        self.state.ble_link_connected = bool(client.is_connected)
        self.state.ble_connected_at = _utc_now()
        self._set_phase("ble_connected")
        return client

    async def _connect_once(self) -> bool:
        candidates = await self._collect_fresh_advertisements()
        if not candidates or self._stopping:
            return False

        last_error: Exception | None = None

        # Strongest source first. If it fails, immediately try the next source
        # observed during the same fresh scan window before waiting for new ads.
        for index, service_info in enumerate(candidates):
            if self._stopping:
                return False

            client: BleakClientWithServiceCache | None = None
            source = self._source_key(service_info)
            try:
                if index:
                    self.state.source_fallbacks += 1
                    self._set_phase("trying_next_adapter_source")

                client = await self._establish_source_connection(service_info)

                self.state.notify_started_at = _utc_now()
                self._set_phase("enabling_notifications")
                try:
                    await asyncio.wait_for(
                        client.start_notify(NOTIFY_UUID, self._notification),
                        timeout=NOTIFY_TIMEOUT,
                    )
                except Exception as notify_err:
                    if self._is_authorization_error(notify_err):
                        self.state.authorization_retries += 1
                    raise

                self.state.notifications_active = True
                self.state.notify_active_at = _utc_now()
                self.state.connected = True
                self.state.ble_link_connected = bool(client.is_connected)
                self.state.last_error = None
                self._set_phase("notifications_active")
                _LOGGER.info(
                    "Connected Xzense protocol monitor to %s via %s (%s dBm)",
                    self.address,
                    source,
                    self._rssi_value(service_info),
                )
                self._notify_listeners()
                return True

            except Exception as err:
                last_error = err
                self.state.last_failed_source = source
                if client and client.is_connected:
                    try:
                        await client.disconnect()
                    except Exception:
                        pass
                self._client = None
                self.state.connected = False
                self.state.ble_link_connected = False
                self.state.notifications_active = False
                self._set_error(f"{type(err).__name__}: {err}")
                _LOGGER.debug(
                    "Unable to connect/subscribe Xzense %s via source %s",
                    self.address,
                    source,
                    exc_info=True,
                )

        self._set_phase("all_adapter_sources_failed")
        if last_error is not None:
            self._set_error(f"{type(last_error).__name__}: {last_error}")
        bluetooth.async_clear_advertisement_history(self.hass, self.address)
        return False

    @staticmethod
    def _is_authorization_error(err: Exception) -> bool:
        """Return True for the GATT authorization failure seen on Xzense."""
        message = str(err).lower()
        return (
            "insufficient authorization" in message
            or "authorization (8)" in message
            or "gatterrorresponse: insufficient authorization" in message
        )

    def _disconnected(self, _client: BleakClientWithServiceCache) -> None:
        """Bleak disconnected callback."""
        self._client = None
        self.state.connected = False
        self.state.ble_link_connected = False
        self.state.notifications_active = False
        self.state.disconnect_count += 1
        self.state.last_disconnect_at = _utc_now()
        self._set_phase("disconnected")
        self._notify_listeners()
        self._wake.set()

    def _notification(
        self, _characteristic: BleakGATTCharacteristic, data: bytearray
    ) -> None:
        payload = bytes(data)
        self.state.notification_count += 1
        self.state.last_notification = payload
        self.state.last_notification_at = _utc_now()

        _LOGGER.debug(
            "Xzense raw RX notification #%d: %s",
            self.state.notification_count,
            payload.hex(),
        )

        frames = self._parser.feed(payload)
        self.state.discarded_bytes = self._parser.discarded_bytes
        self.state.invalid_frames = self._parser.invalid_frames

        for frame in frames:
            self.state.packet_count += 1
            self.state.last_frame = frame
            _LOGGER.debug(
                "Xzense RX frame #%d: %s payload=%s peer=%s checksum=%04x",
                self.state.packet_count,
                frame.hex,
                frame.payload_hex or "<empty>",
                frame.peer_id_hex,
                frame.checksum,
            )

        self._notify_listeners()

    def _set_error(self, message: str) -> None:
        if self.state.last_error != message:
            self.state.last_error = message
            self.state.connected = False
            self._notify_listeners()
