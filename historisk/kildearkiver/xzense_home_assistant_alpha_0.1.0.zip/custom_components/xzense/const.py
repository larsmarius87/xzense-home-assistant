"""Constants for the Xzense integration."""

from __future__ import annotations

DOMAIN = "xzense"
NAME = "Xzense"

# Dialog/Renesas DSPS (Serial Port Service) UUIDs recovered from Xzense 5.0.2.
SERVICE_UUID = "0783b03e-8535-b5a0-7140-a304d2495cb7"
NOTIFY_UUID = "0783b03e-8535-b5a0-7140-a304d2495cb8"  # Server TX -> phone/HA
WRITE_UUID = "0783b03e-8535-b5a0-7140-a304d2495cba"   # Server RX <- phone/HA

CONF_NAME = "name"
DEFAULT_NAME = "Xzense"

PLATFORMS = ["sensor", "binary_sensor"]
