"""Xzense application protocol framing.

This module intentionally only parses frames.  It does not construct or send control
packets yet.  The Xzense protocol contains sequence/ACK/NACK/CRC state, and sending a
partially understood control frame to a chimney-fan controller would be a bad idea.
"""

from __future__ import annotations

from dataclasses import dataclass

START_BYTE = 0x23  # '#'
END_BYTE = 0x24    # '$'
MIN_FRAME_SIZE = 15
MAX_FRAME_SIZE = 262  # one-byte declared length + the observed seven-byte overhead


@dataclass(frozen=True, slots=True)
class XzenseFrame:
    """A structurally valid Xzense frame.

    Observed captures use:
      byte 0       0x23 start marker
      byte 1       declared length; full frame length == declared + 7
      bytes 2..11  transport/protocol header (partially decoded)
      bytes 12..-4 application payload (may be empty)
      bytes -3..-2 16-bit CRC/check value, little-endian on observed traffic
      byte -1      0x24 end marker

    CRC polynomial evidence points to 0x1021, but its exact seed/range/xor scheme is
    not yet proven, so CRC validation is deliberately not claimed here.
    """

    raw: bytes

    @property
    def declared_length(self) -> int:
        return self.raw[1]

    @property
    def header(self) -> bytes:
        return self.raw[2:12]

    @property
    def peer_id(self) -> bytes:
        """Return the six-byte identifier observed in the fixed header."""
        return self.raw[6:12]

    @property
    def payload(self) -> bytes:
        return self.raw[12:-3]

    @property
    def checksum(self) -> int:
        return int.from_bytes(self.raw[-3:-1], "little")

    @property
    def hex(self) -> str:
        return self.raw.hex()

    @property
    def payload_hex(self) -> str:
        return self.payload.hex()

    @property
    def peer_id_hex(self) -> str:
        return self.peer_id.hex(":")


class XzenseFrameParser:
    """Incremental parser for the serial byte stream carried over BLE notifications."""

    def __init__(self) -> None:
        self._buffer = bytearray()
        self.discarded_bytes = 0
        self.invalid_frames = 0

    def reset(self) -> None:
        self._buffer.clear()
        self.discarded_bytes = 0
        self.invalid_frames = 0

    def feed(self, data: bytes) -> list[XzenseFrame]:
        """Feed a BLE notification and return every complete Xzense frame found."""
        if data:
            self._buffer.extend(data)

        frames: list[XzenseFrame] = []

        while self._buffer:
            # Resynchronise on '#'.
            try:
                start = self._buffer.index(START_BYTE)
            except ValueError:
                self.discarded_bytes += len(self._buffer)
                self._buffer.clear()
                break

            if start:
                self.discarded_bytes += start
                del self._buffer[:start]

            if len(self._buffer) < 2:
                break

            frame_size = self._buffer[1] + 7
            if frame_size < MIN_FRAME_SIZE or frame_size > MAX_FRAME_SIZE:
                self.invalid_frames += 1
                self.discarded_bytes += 1
                del self._buffer[0]
                continue

            if len(self._buffer) < frame_size:
                break

            candidate = bytes(self._buffer[:frame_size])
            if candidate[-1] != END_BYTE:
                self.invalid_frames += 1
                self.discarded_bytes += 1
                del self._buffer[0]
                continue

            del self._buffer[:frame_size]
            frames.append(XzenseFrame(candidate))

        return frames
