"""Binary sensors for Xzense."""

from __future__ import annotations

from homeassistant.components.binary_sensor import BinarySensorDeviceClass, BinarySensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient
from .const import DOMAIN
from .entity import XzenseEntity


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([XzenseConnectionBinarySensor(client)])


class XzenseConnectionBinarySensor(XzenseEntity, BinarySensorEntity):
    """BLE connection status."""

    _attr_name = "Bluetooth connection"
    _attr_device_class = BinarySensorDeviceClass.CONNECTIVITY

    def __init__(self, client: XzenseClient) -> None:
        super().__init__(client)
        self._attr_unique_id = f"{client.address}_connection"

    @property
    def is_on(self) -> bool:
        return self.client.state.connected
