"""Diagnostics support for Xzense."""

from __future__ import annotations

from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from .client import XzenseClient
from .const import DOMAIN


async def async_get_config_entry_diagnostics(
    hass: HomeAssistant, entry: ConfigEntry
) -> dict[str, Any]:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    state = client.state
    frame = state.last_frame
    return {
        "address": client.address,
        "connected": state.connected,
        "packet_count": state.packet_count,
        "notification_count": state.notification_count,
        "last_notification": state.last_notification.hex(),
        "last_frame": frame.hex if frame else None,
        "last_payload": frame.payload_hex if frame else None,
        "peer_id": frame.peer_id_hex if frame else None,
        "checksum_little_endian": f"0x{frame.checksum:04x}" if frame else None,
        "discarded_bytes": state.discarded_bytes,
        "invalid_frames": state.invalid_frames,
        "last_error": state.last_error,
        "control_writes_enabled": False,
    }
