"""Shared entity base for Xzense."""

from __future__ import annotations

from homeassistant.helpers.device_registry import CONNECTION_BLUETOOTH, DeviceInfo
from homeassistant.helpers.entity import Entity

from .client import XzenseClient
from .const import DOMAIN


class XzenseEntity(Entity):
    """Base entity backed by a XzenseClient."""

    _attr_has_entity_name = True

    def __init__(self, client: XzenseClient) -> None:
        self.client = client
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, client.address)},
            name=client.name,
            manufacturer="Exodraft",
            model="Xzense",
            connections={(CONNECTION_BLUETOOTH, client.address)},
        )

    async def async_added_to_hass(self) -> None:
        self.async_on_remove(self.client.async_add_listener(self.async_write_ha_state))
