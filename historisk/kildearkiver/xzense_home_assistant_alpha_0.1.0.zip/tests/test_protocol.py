"""Protocol parser smoke tests; no Home Assistant install required."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "custom_components" / "xzense"))

from protocol import XzenseFrameParser  # noqa: E402


KNOWN = [
    "2308000006070b379427a4ed398b24",
    "230b000006060b379427a4ed5012005aa424",
    "230b000006060b379427a4ed5013006b9724",
    "230b000006060b379427a4ed501400fc0e24",
    "230b000006060b379427a4ed501500cd3d24",
]


def test_known_frames() -> None:
    parser = XzenseFrameParser()
    frames = []
    for value in KNOWN:
        frames.extend(parser.feed(bytes.fromhex(value)))
    assert len(frames) == len(KNOWN)
    assert frames[0].payload == b""
    assert frames[1].payload == bytes.fromhex("501200")
    assert frames[1].peer_id == bytes.fromhex("0b379427a4ed")
    assert frames[1].checksum == 0xA45A


def test_fragmented_stream() -> None:
    parser = XzenseFrameParser()
    raw = bytes.fromhex(KNOWN[1])
    assert parser.feed(raw[:5]) == []
    frames = parser.feed(raw[5:])
    assert len(frames) == 1
    assert frames[0].raw == raw


def test_resync() -> None:
    parser = XzenseFrameParser()
    raw = bytes.fromhex(KNOWN[2])
    frames = parser.feed(b"noise" + raw)
    assert len(frames) == 1
    assert parser.discarded_bytes == 5


if __name__ == "__main__":
    test_known_frames()
    test_fragmented_stream()
    test_resync()
    print("protocol tests: OK")
