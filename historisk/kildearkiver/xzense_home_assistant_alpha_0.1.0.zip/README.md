# Xzense for Home Assistant — protocol monitor alpha

This is an **experimental, read-only first stage** of a Home Assistant custom integration for Exodraft Xzense.

It was built from static analysis of the supplied **Xzense 5.0.2 Android/XAPK** and known BLE traffic.  It does **not** send control commands yet.  That is deliberate: the app shows that Xzense uses sequence numbers, ACK/NACK handling, CRC checking and PIN authentication above BLE, so writes should not be guessed on a chimney-fan controller.

## What is already decoded

BLE transport used by the app:

- Service: `0783b03e-8535-b5a0-7140-a304d2495cb7`
- Device -> app/Home Assistant notifications: `0783b03e-8535-b5a0-7140-a304d2495cb8`
- App/Home Assistant -> device writes: `0783b03e-8535-b5a0-7140-a304d2495cba`

Observed Xzense framing:

- `0x23` (`#`) start marker
- next byte is a length field; observed full frame size = this byte + 7
- fixed header through byte 11
- optional application payload from byte 12
- two checksum/CRC bytes before the final byte
- `0x24` (`$`) end marker

A public fan-speed capture strongly correlates payload `50 XX 00` with a requested fan percentage, but the writer is intentionally disabled until the PIN/session/sequence and checksum rules are fully verified.

## What this alpha does

- Home Assistant Bluetooth discovery by Xzense name or service UUID
- Uses Home Assistant's Bluetooth manager and connectable adapters/proxies
- Connects to Xzense and subscribes to the DSPS notification characteristic
- Incrementally reconstructs Xzense protocol frames even when BLE splits them
- Creates diagnostic entities for connection state, valid frame count, last payload and optional raw data
- Adds config-entry diagnostics
- **Never writes to the Xzense control characteristic**

## Installation

Copy the folder:

`custom_components/xzense`

into:

`/config/custom_components/xzense`

Restart Home Assistant. Go to **Settings -> Devices & services**. Xzense should appear as Bluetooth discovery; otherwise choose **Add integration -> Xzense** and enter/select the Bluetooth address.

For active connections Home Assistant needs a connectable local Bluetooth adapter or a connectable Bluetooth proxy that can reach Xzense.

## Logging for protocol work

Add temporarily to `configuration.yaml`:

```yaml
logger:
  logs:
    custom_components.xzense: debug
```

After restart, the log will contain lines such as:

`Xzense RX frame #...: ... payload=... peer=... checksum=...`

Enable the disabled diagnostic sensors if useful.  A Home Assistant diagnostic download for the Xzense config entry also contains the last raw frame/payload.

## What is still needed for full control

To safely add normal Home Assistant entities (fan speed, chimney temperature, state, Start/Stop, Boost, ventilation), the missing piece is a capture that starts **before connection/authentication** and includes:

1. open/connect Xzense app
2. enter PIN
3. wait for initial status data
4. change fan speed, e.g. 20 -> 21 -> 20
5. start/stop or Boost once

An Android `btsnoop_hci.log`/Bluetooth HCI snoop capture is ideal.  With that capture the protocol messages can be mapped against the structures already recovered from the APK.
