"""Number controls for Xzense settings exposed by the app/firmware vocabulary."""

from __future__ import annotations

from homeassistant.components.number import NumberEntity, NumberMode
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient
from .const import DOMAIN
from .entity import XzenseFeatureEntity
from .features import FEATURES, FeatureSpec

NUMBER_FEATURES = tuple(f for f in FEATURES if f.kind == "number")
PERCENT_KEYS = {"user_fan_speed", "boost_fan_speed", "external_fan_speed"}


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(XzenseNumber(client, feature) for feature in NUMBER_FEATURES)


class XzenseNumber(XzenseFeatureEntity, NumberEntity):
    """A scaffolded numeric Xzense setting."""

    _attr_mode = NumberMode.BOX

    def __init__(self, client: XzenseClient, feature: FeatureSpec) -> None:
        super().__init__(client, feature)
        # Only fan percentages have a user-facing range we can state confidently.
        # Everything else remains a raw signed 16-bit scaffold until scaling/units
        # are verified from the official client protocol.
        if feature.key in PERCENT_KEYS:
            self._attr_native_min_value = 0
            self._attr_native_max_value = 100
            self._attr_native_step = 1
            self._attr_native_unit_of_measurement = "%"
        else:
            self._attr_native_min_value = -32768
            self._attr_native_max_value = 32767
            self._attr_native_step = 1

    @property
    def native_value(self) -> float | None:
        if self.feature.global_id is None:
            return None
        value = self.client.state.globals.get(self.feature.global_id)
        return None if value is None else float(value)

    async def async_set_native_value(self, value: float) -> None:
        await self.client.async_execute_feature(self.feature.key, int(round(value)))
