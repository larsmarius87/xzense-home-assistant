"""Buttons for app-visible Xzense actions."""

from __future__ import annotations

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient
from .const import DOMAIN
from .entity import XzenseFeatureEntity
from .features import FEATURES, FeatureSpec

BUTTON_FEATURES = tuple(f for f in FEATURES if f.kind == "button")


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    entities = [XzenseButton(client, feature) for feature in BUTTON_FEATURES]
    entities.extend((XzenseVolumeNoopProbeButton(client), XzenseFanWriteProbeButton(client)))
    async_add_entities(entities)


class XzenseButton(XzenseFeatureEntity, ButtonEntity):
    """A scaffolded Xzense action."""

    def __init__(self, client: XzenseClient, feature: FeatureSpec) -> None:
        super().__init__(client, feature)

    async def async_press(self) -> None:
        await self.client.async_execute_feature(self.feature.key)


class XzenseVolumeNoopProbeButton(XzenseFeatureEntity, ButtonEntity):
    """Experimental no-op write probe that preserves the current volume value."""

    def __init__(self, client: XzenseClient) -> None:
        feature = FeatureSpec(
            "write_probe_volume_noop",
            "Experimental write probe - volume no-op",
            "button",
            "write_ready",
            global_id=0x33,
            notes="Writes the current 0x33 volume value back unchanged; does not change a setting.",
        )
        super().__init__(client, feature)

    @property
    def available(self) -> bool:
        return self.client.volume_noop_probe_available()

    async def async_press(self) -> None:
        await self.client.async_volume_noop_probe()


class XzenseFanWriteProbeButton(XzenseFeatureEntity, ButtonEntity):
    """Conservative temporary write probe for candidate fan control global 0x50."""

    def __init__(self, client: XzenseClient) -> None:
        feature = FeatureSpec(
            "write_probe_fan_candidate",
            "Experimental fan write probe",
            "button",
            "write_ready",
            global_id=0x50,
            notes=(
                "Only available in Afterrun state 6 below 60 C with fan <=20 %. "
                "Temporarily raises current 0x50 by 10 (max 30), samples STATUS, then restores it."
            ),
        )
        super().__init__(client, feature)

    @property
    def available(self) -> bool:
        return self.client.fan_write_probe_available()

    async def async_press(self) -> None:
        await self.client.async_fan_write_probe()
