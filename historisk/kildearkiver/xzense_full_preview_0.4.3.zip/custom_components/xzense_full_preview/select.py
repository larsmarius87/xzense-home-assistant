"""Select controls for Xzense operating modes/settings."""

from __future__ import annotations

from homeassistant.components.select import SelectEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient
from .const import DOMAIN
from .entity import XzenseFeatureEntity
from .features import FEATURES, FeatureSpec

SELECT_FEATURES = tuple(f for f in FEATURES if f.kind == "select")

OPTIONS = {
    "system_control": ["Manual", "Pressure controlled", "eXotelligence"],
    # The selector exists in the recovered global table, but the official app's
    # exact numeric choices have not been mapped yet.
    "temperature_sensor": ["Protocol mapping pending"],
}


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(XzenseSelect(client, feature) for feature in SELECT_FEATURES)


class XzenseSelect(XzenseFeatureEntity, SelectEntity):
    """A scaffolded Xzense select."""

    def __init__(self, client: XzenseClient, feature: FeatureSpec) -> None:
        super().__init__(client, feature)
        self._attr_options = OPTIONS[feature.key]

    @property
    def current_option(self) -> str | None:
        return None

    async def async_select_option(self, option: str) -> None:
        if option not in self.options:
            return
        await self.client.async_execute_feature(self.feature.key, option)
