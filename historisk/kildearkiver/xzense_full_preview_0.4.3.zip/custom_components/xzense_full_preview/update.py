"""Firmware update scaffold for Xzense."""

from __future__ import annotations

from typing import Any

from homeassistant.components.update import UpdateDeviceClass, UpdateEntity, UpdateEntityFeature
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient
from .const import DOMAIN
from .entity import XzenseFeatureEntity
from .features import FEATURE_BY_KEY


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([XzenseFirmwareUpdate(client)])


class XzenseFirmwareUpdate(XzenseFeatureEntity, UpdateEntity):
    """Firmware updater scaffold matching the function exposed by the app."""

    _attr_device_class = UpdateDeviceClass.FIRMWARE
    _attr_supported_features = UpdateEntityFeature.INSTALL

    def __init__(self, client: XzenseClient) -> None:
        super().__init__(client, FEATURE_BY_KEY["firmware"])
        self._attr_installed_version = None
        self._attr_latest_version = None

    async def async_install(
        self, version: str | None, backup: bool, **kwargs: Any
    ) -> None:
        await self.client.async_execute_feature("firmware", version)
