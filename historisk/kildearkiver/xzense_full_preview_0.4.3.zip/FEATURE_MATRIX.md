# Xzense Full Preview 0.4.3 — feature matrix

| Function | Status | Mapping |
|---|---|---|
| Device state | Verified read | 0x19; 3=Boosting, 6=Afterrun |
| Time in current state | Verified read | 0x1A, seconds |
| Air pressure | Verified read | 0x1B, hPa |
| Inside temperature | Candidate read | 0x1C / 10 °C |
| Outside temperature | Candidate read | 0x1D / 10 °C |
| Chimney temperature | Verified read | 0x1E / 10 °C |
| Actual fan speed | Verified read | 0x1F % |
| GLOBAL 0x20 | Unknown | raw diagnostic only |
| Volume no-op write probe | Experimental | 0x33, writes same value |
| Fan candidate write probe | Experimental | 0x50, +10 then restore, guarded |
| Normal controls | Disabled | CONTROL_WRITES_ENABLED=False |
