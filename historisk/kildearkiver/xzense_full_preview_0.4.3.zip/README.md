# Xzense Full Preview 0.4.3

Development Home Assistant integration for Exodraft Xzense.

This release corrects the live runtime decoder and adds tightly-scoped write probes while keeping normal controls disabled.

## Live verified

- State 3 = Boosting
- State 6 = Afterrun
- Time in current state = GLOBAL/STATUS 0x1A, seconds
- Air pressure = GLOBAL/STATUS 0x1B, hPa
- Chimney temperature = GLOBAL 0x1E / 10
- Actual fan speed = GLOBAL 0x1F, percent

## Experimental write probes

Normal controls still use `CONTROL_WRITES_ENABLED = False`. Two separate test buttons bypass that gate only for narrowly-defined probes:

1. **Experimental write probe - volume no-op**: writes the current GLOBAL 0x33 value back unchanged.
2. **Experimental fan write probe**: only available in user-confirmed Afterrun (state 6), chimney <=60 °C, actual fan <=20 %, and baseline GLOBAL 0x50 <=20. It writes baseline+10 (max 30), requests STATUS, records observed fan speed, then restores the original 0x50 value in a `finally` block.

Use the diagnostics after a probe to inspect ACK/NACK, TX frames, packet history, and observed fan speed.
