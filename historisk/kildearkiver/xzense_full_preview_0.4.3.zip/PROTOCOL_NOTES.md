# Xzense protocol notes — 0.4.3

## Verified STATUS layout

14-byte STATUS application payload:

`u8 state | i16 state_timer_s | i16 fan_% | i16 chimney_temp_x10 | i16 outside_temp_x10 | i16 inside_temp_x10 | i16 air_pressure_hPa | u8 flags`

Verified live mappings:

- GLOBAL `0x19` = device state; `3` = Boosting, `6` = Afterrun.
- GLOBAL `0x1A` = time in current state, seconds.
- GLOBAL `0x1B` = air pressure, hPa; raw `1011` was user-confirmed as 1011 hPa.
- GLOBAL `0x1C` = inside temperature candidate, tenths °C.
- GLOBAL `0x1D` = outside temperature candidate, tenths °C.
- GLOBAL `0x1E` = chimney temperature, tenths °C.
- GLOBAL `0x1F` = actual fan speed, %.
- GLOBAL `0x20` = unknown.

## GLOBAL writes

Envelope: `06 0B | session_id_le32 | global_id_u8 | value_i16_le`.

Normal control writes remain disabled. 0.4.3 adds only two experimental probes. The fan probe uses GLOBAL `0x50`, because an exact GLOBAL/REQ write vector for that ID is already known, but its physical meaning on this controller is still under test. The probe is deliberately guarded and automatically restores the original value.
