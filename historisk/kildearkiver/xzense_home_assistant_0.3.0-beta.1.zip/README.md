# Exodraft Xzense – Home Assistant v0.3.0 beta 1

Experimental local BLE integration for Exodraft Xzense.

## What is proven on real hardware

- Home Assistant can discover the Xzense controller through a Bluetooth proxy.
- Notifications on the Dialog/Renesas DSPS TX characteristic work.
- The 4-hex-digit Xzense application PIN is accepted by the recovered CONNECT/REQ handshake.
- CONNECT/ACK returns a valid application session ID.
- Protocol framing, escaping and CRC have been validated against real Xzense traffic.

## New in 0.3.0 beta 1

- Sends the captured, read-only STATUS/REQ after successful application login.
- Polls STATUS every 10 seconds while the authenticated session is alive. This both refreshes values and keeps an otherwise idle session active.
- Decodes the 19-byte STATUS structure recovered from the controller firmware.
- Adds normal Home Assistant sensors for:
  - Chimney temperature
  - Inside temperature
  - Outside temperature
  - Fan speed
- Passively decodes GLOBAL/DATA packets and caches their ID/value pairs.
- Keeps the last 20 validated protocol frames in diagnostics.
- Keeps all diagnostic entities enabled by default.

## Deliberately not enabled yet

No control writes are exposed in this build. In particular, 0.3.0 beta 1 does **not** change fan speed, boost state, ventilation, temperatures, timers or system state. The goal of this build is to prove stable read/status operation before enabling physical control.

## Install

1. Copy `custom_components/xzense` over the existing folder in `/config/custom_components/`.
2. Restart Home Assistant.
3. Do not delete the integration; the configured Xzense PIN is retained.
4. Let it run for at least 30–60 seconds after it reaches `application_connected`.
5. Check the four live sensors and download diagnostics if values do not look right.

The integration is still reverse-engineered/experimental and is not affiliated with Exodraft.
