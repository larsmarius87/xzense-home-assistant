# Changelog

## 0.3.0-beta.1

- Keep the proven v0.2.8 fresh-advertisement BLE connect strategy.
- Keep the proven Xzense PIN CONNECT/REQ/ACK session handshake.
- Add exact STATUS/REQ generation verified against a public Xzense BLE capture.
- Poll live status every 10 seconds after CONNECT/ACK to refresh data and keep the application session active.
- Decode STATUS replies sent as either DATA or ACK.
- Decode chimney, inside and outside temperatures plus fan speed from the recovered 19-byte controller status structure.
- Add normal Home Assistant entities for the four live values.
- Passively cache GLOBAL/DATA triples using global IDs recovered from controller firmware.
- Add last-20 packet history to diagnostics.
- Serialize all BLE writes with a TX lock.
- Redact CONNECT/PIN payload from exposed diagnostics/logging.
- Keep all diagnostic entities enabled by default.
- No physical control writes are enabled yet.
