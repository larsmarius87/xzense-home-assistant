import importlib.util
from pathlib import Path
import sys

PROTOCOL_PATH = Path(__file__).parents[1] / "custom_components" / "xzense" / "protocol.py"
spec = importlib.util.spec_from_file_location("xzense_protocol_test", PROTOCOL_PATH)
protocol = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = protocol
spec.loader.exec_module(protocol)

XzenseFrameParser = protocol.XzenseFrameParser
build_connect_request = protocol.build_connect_request
build_frame = protocol.build_frame
crc16_ccitt_false = protocol.crc16_ccitt_false


def test_crc_known_vector():
    assert crc16_ccitt_false(b"123456789") == 0x29B1


def test_frame_roundtrip():
    raw = build_frame(0x06, bytes.fromhex("020a0102030405060708"))
    parser = XzenseFrameParser()
    frames = parser.feed(raw)
    assert len(frames) == 1
    frame = frames[0]
    assert frame.outer_type == 0x06
    assert frame.packet_type == 0x02
    assert frame.protocol_type == 0x0A
    assert frame.session_id == 0x04030201
    assert parser.invalid_frames == 0


def test_reserved_bytes_are_escaped_and_roundtrip():
    payload = bytes((0x23, 0x24, 0x27, 0x01))
    raw = build_frame(0x06, payload)
    assert bytes.fromhex("27a3") in raw
    assert bytes.fromhex("27a4") in raw
    assert bytes.fromhex("27a7") in raw
    parser = XzenseFrameParser()
    assert parser.feed(raw)[0].payload == payload


def test_fragmented_notifications():
    raw = build_frame(0x06, b"abcdef")
    parser = XzenseFrameParser()
    assert parser.feed(raw[:4]) == []
    assert parser.feed(raw[4:9]) == []
    frames = parser.feed(raw[9:])
    assert len(frames) == 1
    assert frames[0].payload == b"abcdef"


def test_connect_request_pin_zero_safe_time():
    raw = build_connect_request("0000", "HomeAssistant")
    # body size: network/type (2) + inner packet (22) = 24 = 0x0018
    assert raw == bytes.fromhex(
        "2318000006020b0000000000000d486f6d65417373697374616e74254d24"
    )
    frame = XzenseFrameParser().feed(raw)[0]
    assert frame.payload[:9] == bytes.fromhex("020b0000000000000d")
    assert frame.payload[9:] == b"HomeAssistant"


def test_status_request_matches_public_capture():
    raw = protocol.build_status_request(0xED249437)
    assert raw == bytes.fromhex("2308000006070b379427a4ed398b24")
    frame = XzenseFrameParser().feed(raw)[0]
    assert frame.packet_type == protocol.PACKET_STATUS
    assert frame.protocol_type == protocol.PROTOCOL_REQ
    assert frame.application_payload == bytes.fromhex("379424ed")


def test_decode_status_data_recovered_firmware_layout():
    # 19-byte STATUS body: byte0 state; i16 aux; then chimney/outside/inside,
    # state timer, flag, fan speed; remaining bytes are reserved/zero here.
    body = bytearray(19)
    body[0] = 3
    body[1:3] = (-12).to_bytes(2, "little", signed=True)
    body[3:5] = (56).to_bytes(2, "little", signed=True)
    body[5:7] = (-4).to_bytes(2, "little", signed=True)
    body[7:9] = (22).to_bytes(2, "little", signed=True)
    body[9:11] = (123).to_bytes(2, "little", signed=True)
    body[11] = 1
    body[12:14] = (50).to_bytes(2, "little", signed=True)
    raw = build_frame(
        protocol.OUTER_TYPE_APPLICATION,
        bytes((protocol.PACKET_STATUS, protocol.PROTOCOL_DATA)) + bytes(body),
    )
    frame = XzenseFrameParser().feed(raw)[0]
    status = protocol.decode_status_data(frame)
    assert status is not None
    assert status.chimney_temperature == 56
    assert status.outside_temperature == -4
    assert status.inside_temperature == 22
    assert status.fan_speed == 50
    assert status.state_timer == 123


def test_decode_global_data_three_byte_entries():
    payload = bytes((
        protocol.PACKET_GLOBAL,
        protocol.PROTOCOL_DATA,
        0x1F, 56, 0,
        0x20, 50, 0,
        0x1E, 0xFC, 0xFF,  # -4
    ))
    raw = build_frame(protocol.OUTER_TYPE_APPLICATION, payload)
    frame = XzenseFrameParser().feed(raw)[0]
    values = protocol.decode_global_data(frame)
    assert values == {0x1F: 56, 0x20: 50, 0x1E: -4}


def test_decode_status_ack_response():
    body = bytearray(19)
    body[3:5] = (61).to_bytes(2, "little", signed=True)
    body[5:7] = (5).to_bytes(2, "little", signed=True)
    body[7:9] = (21).to_bytes(2, "little", signed=True)
    body[12:14] = (47).to_bytes(2, "little", signed=True)
    raw = build_frame(
        protocol.OUTER_TYPE_APPLICATION,
        bytes((protocol.PACKET_STATUS, protocol.PROTOCOL_ACK)) + bytes(body),
    )
    frame = XzenseFrameParser().feed(raw)[0]
    status = protocol.decode_status_data(frame)
    assert status is not None
    assert status.chimney_temperature == 61
    assert status.fan_speed == 47
