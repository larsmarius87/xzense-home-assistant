"""Sensors for Exodraft Xzense."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from homeassistant.components.sensor import SensorDeviceClass, SensorEntity, SensorStateClass
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory, PERCENTAGE, UnitOfPressure, UnitOfTemperature, UnitOfTime
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import STATUS_POLL_INTERVAL, XzenseClient, XzenseState
from .const import DOMAIN
from .protocol import device_state_name
from .entity import XzenseEntity


def _status_or_global(state: XzenseState, attr: str, global_id: int) -> int | None:
    """Prefer a verified STATUS value, falling back to passive GLOBAL/DATA."""
    if state.status is not None:
        value = getattr(state.status, attr, None)
        if value is not None:
            return value
    return state.globals.get(global_id)


def _temperature_status_or_global(
    state: XzenseState, raw_attr: str, global_id: int
) -> float | None:
    """Return a calibrated temperature in degrees Celsius."""
    if state.status is not None:
        raw = getattr(state.status, raw_attr, None)
        if raw is not None:
            return raw / 10.0
    raw = state.globals.get(global_id)
    return None if raw is None else raw / 10.0


def _operating_state(state: XzenseState) -> str | None:
    raw = _status_or_global(state, "device_state", 0x19)
    return device_state_name(raw)


def _global_dump(state: XzenseState) -> str | None:
    if not state.globals:
        return None
    return " | ".join(f"0x{key:02X}={value}" for key, value in sorted(state.globals.items()))


@dataclass(frozen=True, slots=True)
class SensorDescription:
    key: str
    name: str
    value_fn: Callable[[XzenseState], Any]
    diagnostic: bool = True
    native_unit: str | None = None
    device_class: SensorDeviceClass | None = None
    state_class: SensorStateClass | None = None
    enabled_default: bool = True


# Live mappings calibrated against synchronized panel readings on 2026-10-19.
# Temperature globals are tenths of a degree Celsius. Fan speed is direct %.
LIVE_SENSORS = (
    SensorDescription(
        "chimney_temperature",
        "Chimney temperature",
        lambda s: _temperature_status_or_global(s, "chimney_temperature_raw", 0x1E),
        diagnostic=False,
        native_unit=UnitOfTemperature.CELSIUS,
        device_class=SensorDeviceClass.TEMPERATURE,
        state_class=SensorStateClass.MEASUREMENT,
    ),
    SensorDescription(
        "inside_temperature",
        "Inside temperature",
        lambda s: _temperature_status_or_global(s, "inside_temperature_raw", 0x1C),
        diagnostic=False,
        native_unit=UnitOfTemperature.CELSIUS,
        device_class=SensorDeviceClass.TEMPERATURE,
        state_class=SensorStateClass.MEASUREMENT,
    ),
    SensorDescription(
        "outside_temperature",
        "Outside temperature",
        lambda s: _temperature_status_or_global(s, "outside_temperature_raw", 0x1D),
        diagnostic=False,
        native_unit=UnitOfTemperature.CELSIUS,
        device_class=SensorDeviceClass.TEMPERATURE,
        state_class=SensorStateClass.MEASUREMENT,
    ),
    SensorDescription(
        "fan_speed",
        "Fan speed",
        lambda s: _status_or_global(s, "fan_speed", 0x1F),
        diagnostic=False,
        native_unit=PERCENTAGE,
        state_class=SensorStateClass.MEASUREMENT,
    ),
)

# Additional app/firmware-visible reads. IDs are recovered, but scaling/semantics
# beyond their names are deliberately left raw until verified on the wire.
APP_READ_SENSORS = (
    SensorDescription(
        "pressure",
        "Air pressure",
        lambda s: _status_or_global(s, "air_pressure_hpa", 0x1B),
        diagnostic=False,
        native_unit=UnitOfPressure.HPA,
        device_class=SensorDeviceClass.PRESSURE,
        state_class=SensorStateClass.MEASUREMENT,
    ),
    SensorDescription("actual_draft", "Chimney draught", lambda s: s.globals.get(0x51), diagnostic=False),
    SensorDescription(
        "state_timer",
        "Time in current state",
        lambda s: _status_or_global(s, "state_timer", 0x1A),
        diagnostic=False,
        native_unit=UnitOfTime.SECONDS,
        state_class=SensorStateClass.MEASUREMENT,
    ),
    SensorDescription("device_state", "Device state", _operating_state, diagnostic=False),
    SensorDescription("signal_strength", "Signal strength", lambda s: s.globals.get(0x18), diagnostic=False),
    SensorDescription("battery", "Battery", lambda s: s.globals.get(0x05), diagnostic=False),
    SensorDescription("burn_count", "Burn count", lambda s: None, diagnostic=False),
    SensorDescription("operation_time", "Operation time", lambda s: None, diagnostic=False),
    SensorDescription("error_log", "Error log", lambda s: None, diagnostic=False),
    SensorDescription("firmware_version", "Firmware version", lambda s: None, diagnostic=False),
)

DIAGNOSTIC_SENSORS = (
    SensorDescription("phase", "Bluetooth setup phase", lambda s: s.phase),
    SensorDescription("ble_link_connected", "BLE link connected", lambda s: s.ble_link_connected),
    SensorDescription("notifications_active", "BLE notifications active", lambda s: s.notifications_active),
    SensorDescription("packet_count", "Valid protocol frames", lambda s: s.packet_count),
    SensorDescription("last_payload", "Last protocol payload", lambda s: s.last_frame.payload_hex if s.last_frame else None),
    SensorDescription("last_frame", "Last protocol frame", lambda s: s.last_frame.hex if s.last_frame else None),
    SensorDescription("last_notification", "Last BLE notification", lambda s: s.last_notification.hex() if s.last_notification else None),
    SensorDescription("last_notification_at", "Last BLE notification time", lambda s: s.last_notification_at),
    SensorDescription("notification_count", "BLE notifications", lambda s: s.notification_count),
    SensorDescription("discarded_bytes", "Discarded protocol bytes", lambda s: s.discarded_bytes),
    SensorDescription("invalid_frames", "Invalid protocol frames", lambda s: s.invalid_frames),
    SensorDescription("crc_errors", "Protocol CRC errors", lambda s: s.crc_errors),
    SensorDescription("connection_attempts", "Bluetooth connection attempts", lambda s: s.connection_attempts),
    SensorDescription("disconnect_count", "Bluetooth disconnects", lambda s: s.disconnect_count),
    SensorDescription("advertisement_count", "Fresh BLE advertisements", lambda s: s.advertisement_count),
    SensorDescription("advertisement_waits", "Advertisement waits", lambda s: s.advertisement_waits),
    SensorDescription("advertisement_timeouts", "Advertisement wait timeouts", lambda s: s.advertisement_timeouts),
    SensorDescription("last_advertisement_at", "Last fresh advertisement time", lambda s: s.last_advertisement_at),
    SensorDescription("last_advertisement_rssi", "Last advertisement RSSI", lambda s: s.last_advertisement_rssi),
    SensorDescription("last_advertisement_source", "Last advertisement adapter", lambda s: s.last_advertisement_source),
    SensorDescription("last_advertisement_name", "Last advertisement name", lambda s: s.last_advertisement_name),
    SensorDescription("last_advertisement_connectable", "Last advertisement connectable", lambda s: s.last_advertisement_connectable),
    SensorDescription("candidate_source_count", "Bluetooth candidate sources", lambda s: s.candidate_source_count),
    SensorDescription("candidate_sources", "Bluetooth source candidates", lambda s: s.candidate_sources or None),
    SensorDescription("selected_source", "Selected Bluetooth source", lambda s: s.selected_source),
    SensorDescription("selected_source_rssi", "Selected Bluetooth source RSSI", lambda s: s.selected_source_rssi),
    SensorDescription("source_connection_attempts", "Bluetooth source connection attempts", lambda s: s.source_connection_attempts),
    SensorDescription("source_fallbacks", "Bluetooth source fallbacks", lambda s: s.source_fallbacks),
    SensorDescription("last_failed_source", "Last failed Bluetooth source", lambda s: s.last_failed_source),
    SensorDescription("pairing_attempts", "Bluetooth pairing attempts", lambda s: s.pairing_attempts),
    SensorDescription("pairing_success", "Bluetooth pairing succeeded", lambda s: s.pairing_success),
    SensorDescription("pairing_last_error", "Last Bluetooth pairing error", lambda s: s.pairing_last_error),
    SensorDescription("authorization_retries", "GATT authorization retries", lambda s: s.authorization_retries),
    SensorDescription("tx_count", "Application TX frames", lambda s: s.tx_count),
    SensorDescription("tx_chunk_count", "Application TX chunks", lambda s: s.tx_chunk_count),
    SensorDescription("last_tx", "Last application TX", lambda s: "<redacted CONNECT/REQ>" if s.last_tx_kind == "CONNECT/REQ" else (s.last_tx.hex() if s.last_tx else None)),
    SensorDescription("last_tx_kind", "Last application TX type", lambda s: s.last_tx_kind),
    SensorDescription("last_tx_at", "Last application TX time", lambda s: s.last_tx_at),
    SensorDescription("tx_write_mode", "Application TX write mode", lambda s: s.tx_write_mode),
    SensorDescription("tx_chunk_size", "Application TX chunk size", lambda s: s.tx_chunk_size),
    SensorDescription("application_auth_state", "Application authentication state", lambda s: s.application_auth_state),
    SensorDescription("application_connect_attempts", "Application CONNECT attempts", lambda s: s.application_connect_attempts),
    SensorDescription("application_auth_success_count", "Application authentication successes", lambda s: s.application_auth_success_count),
    SensorDescription("handshake_sent_at", "Application handshake sent time", lambda s: s.handshake_sent_at),
    SensorDescription("handshake_response_at", "Application handshake response time", lambda s: s.handshake_response_at),
    SensorDescription("handshake_last_error", "Application handshake error", lambda s: s.handshake_last_error),
    SensorDescription("session_id", "Application session ID", lambda s: f"0x{s.session_id:08X}" if s.session_id is not None else None),
    SensorDescription("connect_ack_version", "CONNECT ACK version", lambda s: s.connect_ack_version),
    SensorDescription("connect_ack_flag", "CONNECT ACK flag", lambda s: s.connect_ack_flag),
    SensorDescription("status_polling_active", "Status polling active", lambda s: s.status_polling_active),
    SensorDescription("status_request_count", "Status requests", lambda s: s.status_request_count),
    SensorDescription("status_response_count", "Status responses", lambda s: s.status_response_count),
    SensorDescription("status_nack_count", "Status NACKs", lambda s: s.status_nack_count),
    SensorDescription("status_request_errors", "Status request errors", lambda s: s.status_request_errors),
    SensorDescription("last_status_request_at", "Last status request time", lambda s: s.last_status_request_at),
    SensorDescription("last_status_response_at", "Last status response time", lambda s: s.last_status_response_at),
    SensorDescription("last_status_payload", "Last status payload", lambda s: s.last_status_payload.hex() if s.last_status_payload else None),
    SensorDescription("status_device_state", "Status device state", lambda s: s.status.device_state if s.status else None),
    SensorDescription("status_state_timer", "Status time in current state", lambda s: s.status.state_timer if s.status else None),
    SensorDescription("status_fan_speed", "Status fan speed", lambda s: s.status.fan_speed if s.status else None),
    SensorDescription("status_chimney_temperature_raw", "Status chimney temperature raw", lambda s: s.status.chimney_temperature_raw if s.status else None),
    SensorDescription("status_outside_temperature_raw", "Status outside temperature raw", lambda s: s.status.outside_temperature_raw if s.status else None),
    SensorDescription("status_inside_temperature_raw", "Status inside temperature raw", lambda s: s.status.inside_temperature_raw if s.status else None),
    SensorDescription("global_0x20_raw", "GLOBAL 0x20 raw", lambda s: s.globals.get(0x20)),
    SensorDescription("status_air_pressure_hpa", "Status air pressure", lambda s: s.status.air_pressure_hpa if s.status else None),
    SensorDescription("status_flags", "Status flags", lambda s: s.status.flags if s.status else None),
    SensorDescription("global_write_ack_count", "GLOBAL write ACKs", lambda s: s.global_write_ack_count),
    SensorDescription("global_write_nack_count", "GLOBAL write NACKs", lambda s: s.global_write_nack_count),
    SensorDescription("last_global_write_response", "Last GLOBAL write response", lambda s: s.last_global_write_response),
    SensorDescription("boost_request_count", "Boost requests", lambda s: s.boost_request_count),
    SensorDescription("boost_ack_count", "Boost ACKs", lambda s: s.boost_ack_count),
    SensorDescription("boost_nack_count", "Boost NACKs", lambda s: s.boost_nack_count),
    SensorDescription("last_boost_action", "Last Boost action", lambda s: s.last_boost_action),
    SensorDescription("last_boost_request_at", "Last Boost request time", lambda s: s.last_boost_request_at),
    SensorDescription("last_boost_response", "Last Boost response", lambda s: s.last_boost_response),
    SensorDescription("last_boost_response_at", "Last Boost response time", lambda s: s.last_boost_response_at),
    SensorDescription("global_update_count", "Global updates", lambda s: s.global_update_count),
    SensorDescription("last_global_id", "Last global ID", lambda s: f"0x{s.last_global_id:02X}" if s.last_global_id is not None else None),
    SensorDescription("last_global_name", "Last global name", lambda s: s.last_global_name),
    SensorDescription("last_global_value", "Last global value", lambda s: s.last_global_value),
    SensorDescription("last_global_at", "Last global update time", lambda s: s.last_global_at),
    SensorDescription("global_values", "Global values", _global_dump),
    SensorDescription("last_packet_type", "Last application packet type", lambda s: s.last_frame.packet_type_name if s.last_frame else None),
    SensorDescription("last_protocol_type", "Last application protocol type", lambda s: s.last_frame.protocol_type_name if s.last_frame else None),
    SensorDescription("last_error", "Last Bluetooth error", lambda s: s.last_error),
)

SENSORS = LIVE_SENSORS + APP_READ_SENSORS + DIAGNOSTIC_SENSORS


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(XzenseSensor(client, description) for description in SENSORS)


class XzenseSensor(XzenseEntity, SensorEntity):
    """A live or diagnostic Xzense value."""

    def __init__(self, client: XzenseClient, description: SensorDescription) -> None:
        super().__init__(client)
        self.description = description
        self._attr_name = description.name
        self._attr_unique_id = f"{client.address}_{description.key}"
        self._attr_entity_registry_enabled_default = description.enabled_default
        if description.diagnostic:
            self._attr_entity_category = EntityCategory.DIAGNOSTIC
        if description.native_unit is not None:
            self._attr_native_unit_of_measurement = description.native_unit
        if description.device_class is not None:
            self._attr_device_class = description.device_class
        if description.state_class is not None:
            self._attr_state_class = description.state_class

    @property
    def native_value(self) -> Any:
        return self.description.value_fn(self.client.state)

    @property
    def available(self) -> bool:
        if self.description.diagnostic:
            return True
        return self.client.state.application_auth_state == "connected" and self.native_value is not None
