"""Feature registry for Xzense Full Preview.

This module intentionally separates three levels of knowledge:
1. verified read paths that are already safe to use,
2. globals/packet types whose identifiers are known but write semantics are not,
3. app-visible features whose exact wire mapping is still unknown.

The entity model is created now so future protocol work can enable a feature by
updating its mapping instead of redesigning the Home Assistant integration.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

FeatureState = Literal["verified_read", "write_ready", "id_known", "mapping_pending"]

@dataclass(frozen=True, slots=True)
class FeatureSpec:
    key: str
    name: str
    kind: Literal["sensor", "binary_sensor", "button", "switch", "number", "select", "update", "virtual"]
    state: FeatureState
    global_id: int | None = None
    packet_type: int | None = None
    notes: str = ""

FEATURES: tuple[FeatureSpec, ...] = (
    # Verified / decoded live reads.
    FeatureSpec("chimney_temperature", "Chimney temperature", "sensor", "verified_read", global_id=0x1E, notes="Live calibrated: tenths of °C."),
    FeatureSpec("inside_temperature", "Inside temperature", "sensor", "id_known", global_id=0x1C, notes="Live field mapping inferred; tenths of °C. Awaiting panel cross-check."),
    FeatureSpec("outside_temperature", "Outside temperature", "sensor", "id_known", global_id=0x1D, notes="Live field mapping inferred; tenths of °C. Awaiting panel cross-check."),
    FeatureSpec("fan_speed", "Fan speed", "sensor", "verified_read", global_id=0x1F, notes="Live A/B verified at 10% and 100%."),
    FeatureSpec("pressure", "Air pressure", "sensor", "verified_read", global_id=0x1B, notes="User-confirmed live value: raw 1011 = 1011 hPa."),
    FeatureSpec("actual_draft", "Chimney draught", "sensor", "id_known", global_id=0x51),
    FeatureSpec("state_timer", "Time in current state", "sensor", "verified_read", global_id=0x1A, notes="Live transition showed approximately +1 count per second; seconds."),
    FeatureSpec("signal_strength", "Signal strength", "sensor", "id_known", global_id=0x18),
    FeatureSpec("battery", "Battery", "sensor", "id_known", global_id=0x05),
    FeatureSpec("device_state", "Device state", "sensor", "verified_read", global_id=0x19, notes="State 3 verified as Boosting; state 6 verified as Afterrun."),

    # App-visible operating controls.
    FeatureSpec("start_fire", "Start fire", "button", "mapping_pending"),
    FeatureSpec("stop_fire", "Stop fire", "button", "mapping_pending"),
    FeatureSpec("refuel", "Refueling", "button", "mapping_pending"),
    FeatureSpec("boost_on", "Boost on", "button", "write_ready", packet_type=0x08,
                notes="Packet 0x08 BOOST/REQ; start flag=1. First live write test in v0.4.4."),
    FeatureSpec("boost_off", "Boost off", "button", "write_ready", packet_type=0x08,
                notes="Packet 0x08 BOOST/REQ; start flag=0. First live write test in v0.4.4."),
    FeatureSpec("ventilation", "Ventilation", "switch", "id_known", packet_type=0x09),
    FeatureSpec("user_fan_speed", "Manual fan speed", "number", "id_known", global_id=0x52),
    FeatureSpec("boost_fan_speed", "Boost fan speed", "number", "id_known", global_id=0x50),
    FeatureSpec("system_control", "System control", "select", "id_known", global_id=0x56,
                notes="App exposes Manual, Pressure controlled and eXotelligence; numeric wire values not yet verified."),

    # User settings visible in firmware/app vocabulary.
    FeatureSpec("auto_start_temperature", "Auto start temperature", "number", "id_known", global_id=0x4C),
    FeatureSpec("auto_stop_temperature", "Auto stop temperature", "number", "id_known", global_id=0x4D),
    FeatureSpec("boost_time", "Boost time", "number", "id_known", global_id=0x4E),
    FeatureSpec("afterrun_time", "After run time", "number", "id_known", global_id=0x4F),
    FeatureSpec("boost_stop_temperature", "Boost stop temperature", "number", "id_known", global_id=0x53),
    FeatureSpec("wanted_draft", "Wanted draught", "number", "id_known", global_id=0x54),
    FeatureSpec("minimum_fan_voltage", "Minimum fan voltage", "number", "id_known", global_id=0x55),
    FeatureSpec("temperature_sensor", "Temperature sensor", "select", "id_known", global_id=0x57),
    FeatureSpec("external_start", "External start", "switch", "id_known", global_id=0x58),
    FeatureSpec("alarm_setpoint", "Alarm setpoint", "number", "id_known", global_id=0x59),
    FeatureSpec("refire_time", "Refire time", "number", "id_known", global_id=0x5A),
    FeatureSpec("external_fan_speed", "External fan speed", "number", "id_known", global_id=0x5B),

    # App-visible information/features without a verified packet/global mapping yet.
    FeatureSpec("burn_count", "Burn count", "sensor", "mapping_pending"),
    FeatureSpec("operation_time", "Operation time", "sensor", "mapping_pending"),
    FeatureSpec("weather_station", "Weather station", "binary_sensor", "mapping_pending"),
    FeatureSpec("error_log", "Error log", "sensor", "mapping_pending"),
    FeatureSpec("firmware", "Firmware", "update", "mapping_pending"),
    FeatureSpec("download_log", "Download log", "button", "mapping_pending"),
    FeatureSpec("history", "History", "virtual", "mapping_pending",
                notes="Planned as HA history/statistics from live entities rather than a separate control."),
)

FEATURE_BY_KEY = {feature.key: feature for feature in FEATURES}
