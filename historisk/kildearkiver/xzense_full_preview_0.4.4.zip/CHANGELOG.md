# 0.4.4

- Removed the v0.4.3 experimental volume/fan write probes and their Afterrun gates.
- Added dedicated **Boost on** and **Boost off** buttons.
- Statically verified controller packet type `0x08` as `BOOST` from the bundled firmware.
- BOOST request uses active session ID + start/stop byte + current raw inside temperature.
- Added BOOST ACK/NACK/request diagnostics and immediate STATUS refresh after a command.
- All non-Boost control writes remain disabled.

# Changelog

## 0.4.3

- Confirms device state `6` as **Afterrun** from a synchronized live capture.
- Reclassifies GLOBAL/STATUS `0x1A` as **time in current state**; the value reset at the state transition and advanced about once per second.
- Confirms GLOBAL/STATUS `0x1B` as **air pressure in hPa**; user confirmed raw `1011` = **1011 hPa**.
- Corrects the 14-byte STATUS layout accordingly.
- Keeps state `3` = **Boosting**, `0x1E` = chimney temperature `/10`, and `0x1F` = actual fan speed `%`.
- Keeps all normal control writes disabled.
- Adds two explicit experimental write-probe buttons:
  - volume no-op: writes the existing `0x33` value back unchanged;
  - fan candidate probe: only in Afterrun below 60 °C with actual fan <=20 %, temporarily changes GLOBAL `0x50` by +10 (max 30), samples STATUS for about five seconds, then restores the original value.
- Records GLOBAL ACK/NACK and probe results in diagnostics.

## 0.4.2

- Calibrated chimney temperature and actual fan speed from synchronized live values.
- Corrected temperature scaling and left GLOBAL `0x20` unidentified.
