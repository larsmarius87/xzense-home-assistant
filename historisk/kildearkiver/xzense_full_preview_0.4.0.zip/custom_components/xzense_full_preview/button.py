"""Buttons for app-visible Xzense actions."""

from __future__ import annotations

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient
from .const import DOMAIN
from .entity import XzenseFeatureEntity
from .features import FEATURES, FeatureSpec

BUTTON_FEATURES = tuple(f for f in FEATURES if f.kind == "button")


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(XzenseButton(client, feature) for feature in BUTTON_FEATURES)


class XzenseButton(XzenseFeatureEntity, ButtonEntity):
    """A scaffolded Xzense action."""

    def __init__(self, client: XzenseClient, feature: FeatureSpec) -> None:
        super().__init__(client, feature)

    async def async_press(self) -> None:
        await self.client.async_execute_feature(self.feature.key)
