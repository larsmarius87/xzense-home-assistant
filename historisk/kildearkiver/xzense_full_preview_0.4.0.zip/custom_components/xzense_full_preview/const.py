"""Constants for the Xzense Full Preview integration."""

from __future__ import annotations

import re

DOMAIN = "xzense_full_preview"
NAME = "Xzense Full Preview"
VERSION = "0.4.0"

# Dialog/Renesas DSPS (Serial Port Service) UUIDs recovered from Xzense 5.0.2.
SERVICE_UUID = "0783b03e-8535-b5a0-7140-a304d2495cb7"
NOTIFY_UUID = "0783b03e-8535-b5a0-7140-a304d2495cb8"  # Server TX -> phone/HA
WRITE_UUID = "0783b03e-8535-b5a0-7140-a304d2495cba"   # Server RX <- phone/HA

CONF_NAME = "name"
CONF_PIN = "pin"
DEFAULT_NAME = "Xzense"

PIN_PATTERN = re.compile(r"^[0-9A-F]{4}$")

# All user-facing platforms are scaffolded now. Unsupported control writes remain
# unavailable until their exact on-wire command semantics are verified.
PLATFORMS = ["sensor", "binary_sensor", "button", "switch", "number", "select", "update"]

# Deliberate safety gate. Read paths are enabled; physical/control writes are not.
CONTROL_WRITES_ENABLED = False


def normalize_pin(value: str) -> str | None:
    """Normalize a Xzense PIN, returning None if it is not four hex digits."""
    pin = value.strip().upper()
    return pin if PIN_PATTERN.fullmatch(pin) else None
