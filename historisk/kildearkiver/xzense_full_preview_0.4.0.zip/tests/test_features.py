"""Feature matrix tests without Home Assistant imports."""
from pathlib import Path
import importlib.util
import sys

PATH = Path(__file__).parents[1] / "custom_components" / "xzense_full_preview" / "features.py"
spec = importlib.util.spec_from_file_location("xzense_features_test", PATH)
features = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = features
spec.loader.exec_module(features)


def test_key_app_features_are_scaffolded():
    keys = features.FEATURE_BY_KEY
    for key in (
        "start_fire", "stop_fire", "refuel", "boost", "ventilation",
        "user_fan_speed", "system_control", "chimney_temperature",
        "inside_temperature", "outside_temperature", "pressure",
        "actual_draft", "burn_count", "operation_time", "weather_station",
        "error_log", "firmware", "download_log",
    ):
        assert key in keys


def test_no_control_is_accidentally_marked_write_ready():
    assert not any(
        f.state == "write_ready"
        for f in features.FEATURES
        if f.kind in {"button", "switch", "number", "select", "update"}
    )
