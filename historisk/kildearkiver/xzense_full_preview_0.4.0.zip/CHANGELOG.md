# Changelog

## 0.4.0

- New separate domain: `xzense_full_preview`.
- Preserves the authenticated BLE/session/status implementation from the working 0.3 branch.
- Adds complete Home Assistant platform scaffolding for app-visible Xzense functions.
- Adds buttons for Start fire, Stop fire, Refueling, Boost and Download log.
- Adds switches for Ventilation and External start.
- Adds number entities for fan/draft/temperature/time settings whose firmware global IDs are known.
- Adds System control select with Manual, Pressure controlled and eXotelligence options.
- Adds weather-station, burn-count, operation-time, error-log and firmware placeholders.
- Adds firmware `update` entity scaffold.
- Adds a generic GLOBAL/REQ encoder verified against the public BLE capture.
- Keeps all unverified control writes globally safety-gated (`CONTROL_WRITES_ENABLED = False`).
- Reconfigure PIN form no longer pre-fills the stored PIN.
