# Xzense Full Preview 0.4.0 — protocol notes

## BLE transport

Service: `0783b03e-8535-b5a0-7140-a304d2495cb7`

- Notify/TX from Xzense: `0783b03e-8535-b5a0-7140-a304d2495cb8`
- Write/RX to Xzense: `0783b03e-8535-b5a0-7140-a304d2495cba`

The four-character Xzense PIN is part of the Xzense application protocol, not standard BLE pairing.

## Frame

Unescaped logical frame:

`23 | size_le16 | 00 | outer_type | payload | crc16_le | 24`

CRC is CRC-16/CCITT-FALSE over `00 | outer_type | payload`. Reserved bytes `23`, `24`, `27` are escaped in payload/CRC as `27, byte|80`.

## Application packet

Outer type `06` carries:

`packet_type | protocol_type | application_payload`

Known protocol types: DATA=`08`, NACK=`09`, ACK=`0A`, REQ=`0B`.

## CONNECT

`02 0B | pin_le16 | time_u32 | name_len | ASCII name`

A successful ACK returns a session ID used by subsequent application messages.

## STATUS read

`07 0B | session_id_le32`

The recovered 19-byte status body contains chimney/outside/inside temperature, state timer and fan speed at the offsets implemented in `protocol.py`.

## GLOBAL read/write transport

GLOBAL/DATA is decoded as repeated entries:

`global_id_u8 | value_i16_le`

The public BLE capture provides a verified GLOBAL/REQ write shape:

`06 0B | session_id_le32 | global_id_u8 | value_i16_le`

For session `ED249437`, global `50`, value `18`, the encoder produces the captured wire frame:

`230b000006060b379427a4ed5012005aa424`

This verifies the generic write envelope. It does **not** by itself verify the user-facing meaning, scaling or valid range of every global ID.

## Known global IDs used by the feature scaffold

- `1C` PRESSURE
- `1D` INSIDE_TEMP
- `1E` OUTSIDE_TEMP
- `1F` CHIMNEY_TEMP
- `20` FAN_SPEED
- `4C` AUTO_START_TEMP
- `4D` AUTO_STOP_TEMP
- `4E` BOOST_TIME
- `4F` AFTERRUN_TIME
- `50` BOOST_FAN_SPEED
- `51` ACTUAL_DRAFT
- `52` USER_FAN_SPEED
- `53` BOOST_STOP_TEMP
- `54` WANTED_DRAFT
- `55` MIN_FAN_VOLTAGE
- `56` SYSTEM_CONTROL
- `57` TEMPERATURE_SENSOR
- `58` EXTERN_START
- `59` ALARM_SETPOINT
- `5A` REBOOST_TIME
- `5B` EXTERN_FAN_SPEED

Packet type `09` is VENTILATION; its application payload is not yet mapped.
