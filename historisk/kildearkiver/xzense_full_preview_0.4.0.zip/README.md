# Xzense Full Preview 0.4.0

A development Home Assistant integration for Exodraft Xzense that builds the **full entity model up front** while keeping unverified appliance-control writes safety-gated.

## What is already functional

- Bluetooth discovery through Home Assistant Bluetooth / ESPHome Bluetooth Proxy
- Xzense DSPS GATT transport
- Application PIN `CONNECT/REQ` and `CONNECT/ACK` session handling
- Session ID handling
- CRC-16/CCITT-FALSE and Xzense byte escaping
- Notifications and validated frame parsing
- `STATUS/REQ` polling every 10 seconds after an authenticated session
- STATUS decoding for chimney temperature, inside temperature, outside temperature and fan speed
- GLOBAL/DATA decoding and cache
- Generic GLOBAL/REQ frame builder, matched to the public Xzense BLE capture
- Extensive diagnostics

## Full app-style entity set

The integration now contains sensor, binary_sensor, button, switch, number, select and update platforms. See `FEATURE_MATRIX.md` for every feature and its protocol readiness.

Unverified controls appear as unavailable. This is intentional: the entity/UI plumbing is finished, but v0.4.0 will not invent unknown packet values for a chimney-fan controller.

## Side-integration rule

Domain: `xzense_full_preview`.

It can be installed alongside other Xzense custom-component folders, but it refuses to start its BLE client while `xzense` or `xzense_preview` is loaded. Disable/unload the other Xzense integration before reloading Full Preview.

## PIN

Setup asks for the current four-character hexadecimal PIN shown by Xzense. Reconfigure asks for a fresh PIN and does not pre-fill the old value.
