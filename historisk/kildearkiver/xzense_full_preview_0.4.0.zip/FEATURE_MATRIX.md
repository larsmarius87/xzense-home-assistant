# Xzense Full Preview 0.4.0 — feature matrix

This build deliberately creates the complete Home Assistant-side model now. A feature can therefore move from **pending** to **active** by adding/confirming its wire mapping; the entity and UI structure do not need to be redesigned.

## Live/read paths already implemented

| Function | HA entity | Protocol status |
|---|---|---|
| BLE link | Binary sensor | Implemented |
| Xzense application session | Binary sensor | Implemented |
| Chimney temperature | Sensor | STATUS + GLOBAL fallback implemented |
| Inside temperature | Sensor | STATUS + GLOBAL fallback implemented |
| Outside temperature | Sensor | STATUS + GLOBAL fallback implemented |
| Fan speed | Sensor | STATUS + GLOBAL fallback implemented |
| Air pressure | Sensor | Global ID `0x1C` known; exposed when received |
| Chimney draught / actual draft | Sensor | Global ID `0x51` known; exposed when received |
| State timer | Sensor | STATUS/global read implemented |
| Device/chimney state | Sensors | Global IDs known; raw until state labels are mapped |
| Signal strength / battery | Sensors | Global IDs known; raw when received |

## Control/settings model already scaffolded

These entities are present in the integration but intentionally unavailable until the exact setting/action semantics have been verified. No guessed appliance-control write is transmitted.

| Function | HA entity | Known protocol information |
|---|---|---|
| Start fire | Button | App function known; packet mapping pending |
| Stop fire | Button | App function known; packet mapping pending |
| Refueling | Button | App function known; packet mapping pending |
| Boost | Button | App function known; packet mapping pending |
| Ventilation | Switch | Packet type `0x09` known; payload mapping pending |
| Manual fan speed | Number | Global `0x52 USER_FAN_SPEED` known |
| Boost fan speed | Number | Global `0x50 BOOST_FAN_SPEED` known |
| System control | Select | Global `0x56`; Manual / Pressure controlled / eXotelligence exposed |
| Auto start temperature | Number | Global `0x4C` known |
| Auto stop temperature | Number | Global `0x4D` known |
| Boost time | Number | Global `0x4E` known |
| After-run time | Number | Global `0x4F` known |
| Boost stop temperature | Number | Global `0x53` known |
| Wanted draught | Number | Global `0x54` known |
| Minimum fan voltage | Number | Global `0x55` known |
| Temperature sensor selection | Select | Global `0x57` known; option encoding pending |
| External start | Switch | Global `0x58` known |
| Alarm setpoint | Number | Global `0x59` known |
| Refire time | Number | Global `0x5A` known |
| External fan speed | Number | Global `0x5B` known |

The generic `GLOBAL/REQ` encoder **is implemented and tested against the public BLE capture**. That means once a value's semantics are confirmed, the Home Assistant entity can be enabled without rebuilding the framing layer.

## Other app features scaffolded

- Burn count — sensor placeholder
- Operation time — sensor placeholder
- Weather station — binary-sensor placeholder
- Error log — sensor placeholder
- Firmware update — `update` entity placeholder
- Log download — button placeholder
- History — intended to use Home Assistant's native entity history/statistics once the live values are available
- PIN — config-flow/reauth/reconfigure support

## Safety rule in 0.4.0

`CONTROL_WRITES_ENABLED = False` by design. Reads, BLE/session diagnostics and status polling can run; no unverified physical-control command is sent. Control entities are still created so their names, unique IDs and HA platform types are already stable.
