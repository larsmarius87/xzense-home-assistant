"""Diagnostic sensors for Xzense protocol discovery."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from homeassistant.components.sensor import SensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddConfigEntryEntitiesCallback

from .client import XzenseClient, XzenseState
from .const import DOMAIN
from .entity import XzenseEntity


@dataclass(frozen=True, slots=True)
class SensorDescription:
    key: str
    name: str
    value_fn: Callable[[XzenseState], Any]
    enabled_default: bool = True


SENSORS = (
    SensorDescription("packet_count", "Valid protocol frames", lambda s: s.packet_count),
    SensorDescription(
        "last_payload",
        "Last protocol payload",
        lambda s: s.last_frame.payload_hex if s.last_frame else None,
    ),
    SensorDescription(
        "last_frame",
        "Last protocol frame",
        lambda s: s.last_frame.hex if s.last_frame else None,
        False,
    ),
    SensorDescription(
        "last_notification",
        "Last BLE notification",
        lambda s: s.last_notification.hex() if s.last_notification else None,
        False,
    ),
    SensorDescription(
        "notification_count",
        "BLE notifications",
        lambda s: s.notification_count,
        False,
    ),
    SensorDescription(
        "discarded_bytes",
        "Discarded protocol bytes",
        lambda s: s.discarded_bytes,
        False,
    ),
    SensorDescription(
        "invalid_frames",
        "Invalid protocol frames",
        lambda s: s.invalid_frames,
        False,
    ),
    SensorDescription(
        "connection_attempts",
        "Bluetooth connection attempts",
        lambda s: s.connection_attempts,
        False,
    ),
    SensorDescription(
        "disconnect_count",
        "Bluetooth disconnects",
        lambda s: s.disconnect_count,
        False,
    ),
    SensorDescription("last_error", "Last Bluetooth error", lambda s: s.last_error, False),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddConfigEntryEntitiesCallback,
) -> None:
    client: XzenseClient = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(XzenseDiagnosticSensor(client, description) for description in SENSORS)


class XzenseDiagnosticSensor(XzenseEntity, SensorEntity):
    """A read-only diagnostic value from the protocol monitor."""

    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, client: XzenseClient, description: SensorDescription) -> None:
        super().__init__(client)
        self.description = description
        self._attr_name = description.name
        self._attr_unique_id = f"{client.address}_{description.key}"
        self._attr_entity_registry_enabled_default = description.enabled_default

    @property
    def native_value(self) -> Any:
        return self.description.value_fn(self.client.state)
