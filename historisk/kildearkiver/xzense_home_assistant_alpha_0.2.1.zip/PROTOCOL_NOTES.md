# Xzense protocol notes (evidence status)

## High confidence

- The Android app package is `com.exodraft.xzense` and version supplied is 5.0.2.
- The app is Flutter and communicates locally over BLE for control.
- The BLE transport is the Dialog/Renesas DSPS serial profile:
  - service `...5cb7`
  - server TX / notify `...5cb8`
  - server RX / write `...5cba`
- App strings explicitly contain handling for sequence numbers, ACK, NACK, wrong CRC, Globals, Status, Ventilating, Boosting and PIN errors.
- Xzense protocol frames seen in a public capture begin `0x23`, end `0x24`, and satisfy `total_length = byte[1] + 7`.
- In the observed frames, six bytes at offsets 6..11 stay constant and behave like a peer/device identifier.
- Payload begins at offset 12; the two bytes before the terminator behave as a checksum/CRC.

## Strong but not yet safe to use for writes

Public capture while fan speed was increased contains:

- `... 50 12 00 5a a4 24`
- `... 50 13 00 6b 97 24`
- `... 50 14 00 fc 0e 24`
- `... 50 15 00 cd 3d 24`

This is strong evidence that application payload `50 <speed> 00` is a fan-speed request and `<speed>` is a one-byte percent value.  The checksum changes consistently with a CRC-16 family using polynomial `0x1021`; exact initial value/range/xor and session semantics are not yet proven.

## Deliberately unresolved

- PIN/authentication request and response message IDs/encoding
- exact meaning of header bytes 2..5
- sequence-number lifecycle
- ACK/NACK construction
- exact CRC initialization/range/xorout
- status/global message field layout and unit scaling
- Start/Stop/Boost/Ventilation command IDs

Control writes remain disabled until these are confirmed from a full connection capture.

## v0.2.0 PIN configuration

Exodraft's manual shows the smartphone/app PIN as a four-character hexadecimal value (example `5FF0`). The integration now collects and stores that value. This does not change the unresolved status of the application-protocol PIN request/response frame itself.

## v0.2.1 BLE authorization test

A real Xzense connection produced `BluetoothGATTErrorResponse: Insufficient authorization (8)` while Home Assistant was waiting for the GATT write response used to enable notifications. v0.2.1 therefore requests BLE pairing/bonding (`pair=True`) during `establish_connection()` before `start_notify()`. This is transport-layer authorization and is separate from the four-character Xzense application PIN.
