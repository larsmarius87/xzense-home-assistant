# Xzense Preview – v0.3.0

A separate, normal-running "finished preview" of the Exodraft Xzense integration, built only from functions that have been verified sufficiently so far. It uses the separate Home Assistant domain `xzense_preview`, so it does not overwrite the regular `xzense` integration.

## Important

**Do not run Xzense Preview and the regular Xzense integration at the same time.** The preview checks whether the regular integration is loaded and, if so, remains blocked without opening a BLE connection. Disable/unload the regular integration and reload Xzense Preview when you want to try it.

## What the preview does

- Discovers Xzense through Home Assistant Bluetooth/ESPHome Bluetooth Proxy.
- Prompts for the current four-character Xzense PIN during setup; no PIN such as `0000` is assumed.
- Automatically prompts for a new PIN through Home Assistant reauthentication if Xzense returns CONNECT/NACK.
- Performs the verified Xzense CONNECT/REQ → CONNECT/ACK login and stores the session ID.
- Polls the verified read-only STATUS/REQ every 10 seconds.
- Exposes normal entities for:
  - Chimney temperature
  - Inside temperature
  - Outside temperature
  - Fan speed
  - Authenticated Xzense connection
- Passively decodes known GLOBAL/DATA values.
- Exposes a separate diagnostic BLE-link binary sensor.
- Enables all diagnostic entities by default.
- Redacts the PIN-bearing CONNECT request from diagnostics and logs.

## What is intentionally not faked

The preview does **not** expose physical control of fan speed, boost, ventilation, timers or configuration. We know several relevant global IDs from the firmware, but we have not verified the complete safe write semantics on the real controller. A "finished" preview should not present guessed controls as working controls.

## Install

1. Copy `custom_components/xzense_preview` into `/config/custom_components/`.
2. Restart Home Assistant.
3. Add **Xzense Preview** from Settings → Devices & services.
4. Enter the PIN currently shown on the Xzense panel.
5. Disable/unload the regular Xzense integration before reloading/running Preview.

This project is reverse engineered and is not affiliated with Exodraft.
