from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

def test_release_version_and_pin_security():
    manifest = json.loads((ROOT / 'custom_components/xzense_preview/manifest.json').read_text())
    assert manifest['version'] == '0.3.0'
    assert manifest['domain'] == 'xzense_preview'
    flow = (ROOT / 'custom_components/xzense_preview/config_flow.py').read_text()
    assert 'default=entry.data.get(CONF_PIN' not in flow
    strings = json.loads((ROOT / 'custom_components/xzense_preview/strings.json').read_text())
    assert 'rejected the stored PIN' in strings['config']['step']['reauth_confirm']['description']
