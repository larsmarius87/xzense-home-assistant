# Xzense for Home Assistant — alpha 0.2.0

Experimental local Bluetooth integration for Exodraft Xzense, based on static analysis of the supplied Xzense 5.0.2 Android app.

## New in 0.2.0-alpha.1

- Setup now asks for the **four-character Xzense PIN** displayed on the control panel under **Network → Bluetooth**.
- PIN is normalized to uppercase and validated as four hexadecimal characters (`0-9`, `A-F`).
- Entries created with v0.1.x automatically trigger Home Assistant reauthentication after upgrade so the PIN can be added without deleting the device.
- A reconfigure flow allows the stored PIN to be changed later.
- Diagnostics only report whether a PIN is configured; the PIN itself is never included in diagnostics.

## Important protocol status

The PIN is now collected and available to the BLE client, but **the application-level PIN authentication packet is not transmitted yet**. Control writes also remain disabled. The APK proves that Xzense has PIN authentication, sequence numbers, ACK/NACK handling and CRC checking; the exact PIN frame and session semantics still need to be confirmed before the integration should write to a chimney-fan controller.

This build therefore remains a protocol-monitor/test build, but it has the correct Home Assistant configuration model for PIN-protected Xzense devices.

## Installation / upgrade

Copy `custom_components/xzense` to `/config/custom_components/xzense` and restart Home Assistant.

If upgrading from 0.1.x, Home Assistant should request reauthentication and ask for the Xzense PIN. If adding it as a new integration, the PIN is requested during setup.

## BLE transport

- Service: `0783b03e-8535-b5a0-7140-a304d2495cb7`
- Device → HA notify: `0783b03e-8535-b5a0-7140-a304d2495cb8`
- HA → device write: `0783b03e-8535-b5a0-7140-a304d2495cba`
