"""Bluetooth client for Xzense."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass, field
import logging

from bleak.backends.characteristic import BleakGATTCharacteristic
from bleak_retry_connector import BleakClientWithServiceCache, establish_connection

from homeassistant.components import bluetooth
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback

from .const import NOTIFY_UUID
from .protocol import XzenseFrame, XzenseFrameParser

_LOGGER = logging.getLogger(__name__)

Listener = Callable[[], None]


@dataclass(slots=True)
class XzenseState:
    """Runtime state exposed by the experimental read-only integration."""

    connected: bool = False
    packet_count: int = 0
    notification_count: int = 0
    last_notification: bytes = b""
    last_frame: XzenseFrame | None = None
    last_error: str | None = None
    discarded_bytes: int = 0
    invalid_frames: int = 0


class XzenseClient:
    """Maintain a BLE connection and parse Xzense notifications.

    No writes are performed in this alpha version. The Xzense PIN is retained
    for the application-protocol authentication layer, but the authentication
    packet itself is not sent until its framing/CRC/sequence semantics are proven.
    """

    def __init__(
        self,
        hass: HomeAssistant,
        entry: ConfigEntry,
        address: str,
        name: str,
        pin: str,
    ) -> None:
        self.hass = hass
        self.entry = entry
        self.address = address
        self.name = name
        self.pin = pin
        self.state = XzenseState()
        self._parser = XzenseFrameParser()
        self._listeners: set[Listener] = set()
        self._client: BleakClientWithServiceCache | None = None
        self._runner: asyncio.Task[None] | None = None
        self._wake = asyncio.Event()
        self._stopping = False

    @callback
    def async_add_listener(self, listener: Listener) -> Callable[[], None]:
        self._listeners.add(listener)

        @callback
        def remove_listener() -> None:
            self._listeners.discard(listener)

        return remove_listener

    @callback
    def _notify_listeners(self) -> None:
        for listener in tuple(self._listeners):
            listener()

    async def async_start(self) -> None:
        """Start the connection manager without blocking config-entry setup."""
        if self._runner and not self._runner.done():
            return
        self._stopping = False
        self._runner = self.entry.async_create_background_task(
            self.hass, self._connection_loop(), f"xzense-{self.address}"
        )

    async def async_stop(self) -> None:
        """Stop reconnects, notifications and the BLE connection."""
        self._stopping = True
        self._wake.set()

        runner = self._runner
        self._runner = None
        if runner:
            runner.cancel()
            try:
                await runner
            except asyncio.CancelledError:
                pass

        client = self._client
        self._client = None
        if client and client.is_connected:
            try:
                await client.stop_notify(NOTIFY_UUID)
            except Exception:  # best-effort during unload
                pass
            try:
                await client.disconnect()
            except Exception:  # best-effort during unload
                pass

        self.state.connected = False
        self._notify_listeners()

    async def _connection_loop(self) -> None:
        """Connect and reconnect while the config entry is loaded."""
        try:
            while not self._stopping:
                if not self._client or not self._client.is_connected:
                    await self._connect_once()

                self._wake.clear()
                try:
                    # A disconnect callback wakes this immediately.  The timeout also
                    # lets us retry when the device was initially out of range.
                    await asyncio.wait_for(self._wake.wait(), timeout=30.0)
                except TimeoutError:
                    pass
        except asyncio.CancelledError:
            raise

    async def _connect_once(self) -> None:
        ble_device = bluetooth.async_ble_device_from_address(
            self.hass, self.address, connectable=True
        )
        if ble_device is None:
            self._set_error("Device is not currently reachable by a connectable Bluetooth adapter")
            return

        try:
            client = await establish_connection(
                BleakClientWithServiceCache,
                ble_device,
                ble_device.name or self.name,
                self._disconnected,
                max_attempts=3,
            )
            await client.start_notify(NOTIFY_UUID, self._notification)
        except Exception as err:
            self._client = None
            self.state.connected = False
            self._set_error(f"{type(err).__name__}: {err}")
            _LOGGER.debug("Unable to connect to Xzense %s", self.address, exc_info=True)
            return

        self._client = client
        self.state.connected = True
        self.state.last_error = None
        _LOGGER.info("Connected read-only Xzense protocol monitor to %s", self.address)
        self._notify_listeners()

    def _disconnected(self, _client: BleakClientWithServiceCache) -> None:
        """Bleak disconnected callback."""
        self._client = None
        self.state.connected = False
        self._notify_listeners()
        self._wake.set()

    def _notification(
        self, _characteristic: BleakGATTCharacteristic, data: bytearray
    ) -> None:
        payload = bytes(data)
        self.state.notification_count += 1
        self.state.last_notification = payload

        frames = self._parser.feed(payload)
        self.state.discarded_bytes = self._parser.discarded_bytes
        self.state.invalid_frames = self._parser.invalid_frames

        for frame in frames:
            self.state.packet_count += 1
            self.state.last_frame = frame
            _LOGGER.debug(
                "Xzense RX frame #%d: %s payload=%s peer=%s checksum=%04x",
                self.state.packet_count,
                frame.hex,
                frame.payload_hex or "<empty>",
                frame.peer_id_hex,
                frame.checksum,
            )

        self._notify_listeners()

    def _set_error(self, message: str) -> None:
        if self.state.last_error != message:
            self.state.last_error = message
            self.state.connected = False
            self._notify_listeners()
