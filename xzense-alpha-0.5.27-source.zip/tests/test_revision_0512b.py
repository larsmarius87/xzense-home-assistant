"""Alpha 0.5.12b: conservative raw status and Refuel in Operating."""
from pathlib import Path
import ast
import json

ROOT = Path(__file__).resolve().parents[1]
COMPONENT = ROOT / "custom_components/xzense_full_preview"


def test_manifest_version_and_stable_domain():
    m = json.loads((COMPONENT / "manifest.json").read_text())
    assert m["version"] == "0.5.27"
    assert m["domain"] == "xzense_full_preview"


def test_refuel_available_states_and_unmodified_command():
    source = (COMPONENT / "button.py").read_text()
    assert 'return self.client.controls_available and state == 5' in source
    assert 'await self.client.async_control_feature(self.feature.key)' in source
    assert 'await self.async_set_boost(True)' in (COMPONENT / "client.py").read_text()
    assert 'state in {3, 7}' in (COMPONENT / "client.py").read_text()  # preserved


def test_status_titles_preserve_sensor_entity_ids_and_raw_values():
    s = (COMPONENT / "sensor.py").read_text()
    assert 'SensorDescription("battery", "Panel battery", lambda s: s.globals.get(0x04)' in s
    assert 'SensorDescription("signal_strength", "Radio link signal strength", lambda s: s.globals.get(0x05)' in s
    assert 'Unknown ({raw})' not in s
    assert 'f"{client.address}_{description.key}"' in s


def test_features_registry_titles_match_sensors():
    f = (COMPONENT / "features.py").read_text()
    assert '"signal_strength", "Radio link signal strength"' in f
    assert '"battery",\n        "Panel battery level",' in f
    assert 'global_id=0x04' in f
    assert 'global_id=0x05' in f
