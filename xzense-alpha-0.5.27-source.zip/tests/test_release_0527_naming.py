import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'custom_components'/'xzense_full_preview'
def test_027_titles():
    nb=json.loads((APP/'translations'/'nb.json').read_text())
    en=json.loads((APP/'translations'/'en.json').read_text())
    assert nb['entity']['sensor']['signal_strength']['name']=='Radiolink – signalstyrke'
    assert nb['entity']['switch']['rs009_41_motor']['name']=='Viftetype RS009-41'
    assert nb['entity']['button']['refuel']['name']=='Legg inn ved'
    assert nb['entity']['sensor']['device_state_localized']['state']['refueling']=='Vedpåfylling'
    assert en['entity']['sensor']['signal_strength']['name']=='Radio link signal strength'
    assert en['options']['step']['init']['data']['burnout_notification_target']=='Phones to notify'
    assert en['entity']['sensor']['last_data_at']['name']=='Last updated (Bluetooth)'
def test_027_mobile():
    assert 'multiple=True' in (APP/'config_flow.py').read_text()
    assert 'for target in valid:' in (APP/'burnout_notifications.py').read_text()
