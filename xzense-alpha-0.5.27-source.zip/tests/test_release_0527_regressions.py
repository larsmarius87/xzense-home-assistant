"""Regression tests: approved 0.5.25 final fixes in 0.5.27."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/"custom_components"/"xzense_full_preview"

def test_025_icons_restored():
    s=(ROOT/"switch.py").read_text()
    assert '_attr_icon = "mdi:engine-outline"' in s
    assert '"boost": "mdi:turbine"' in s
    assert '"boost": "mdi:fire"' not in s

def test_025_notification_message_multi_phone_preserved():
    s=(ROOT/"burnout_notifications.py").read_text()
    assert 'NOTIFY_TITLE = "Xzense: Legg i mer ved"' in s
    assert 'NOTIFY_MESSAGE = "Legg i mer ved."' in s
    assert 'for target in valid:' in s
    assert 'previous != 4 or state != 5' in s
    assert 'multiple=True' in (ROOT/"config_flow.py").read_text()

def test_025_registry_cleanup_exact_old_test_ids():
    s=(ROOT/"__init__.py").read_text()
    for suffix in ("raw_global_35","raw_global_50","raw_global_55",
                   "experimental_write_probes", "status_flags", "last_write_probe"):
        assert '"'+suffix+'"' in s
    assert 'entity_entry.unique_id in obsolete_unique_ids' in s
    assert 'er.async_entries_for_config_entry(registry, entry.entry_id)' in s
    assert 'reduced_diagnostics' in s

def test_027_refuel_restrictions_preserved():
    s=(ROOT/"button.py").read_text()
    assert 'return self.client.controls_available and state == 5' in s
    assert 'return getattr(self, "_attr_icon", None)' in (ROOT/"sensor.py").read_text()
