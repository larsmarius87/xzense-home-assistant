"""Firmware-derived Refueling regression checks (no Home Assistant imports)."""
from pathlib import Path
import ast

COMPONENT = Path(__file__).parents[1] / "custom_components" / "xzense_full_preview"
client = (COMPONENT / "client.py").read_text()
buttons = (COMPONENT / "button.py").read_text()
features = (COMPONENT / "features.py").read_text()
sensor = (COMPONENT / "sensor.py").read_text()
card = (COMPONENT / "www" / "xzense-card.js").read_text()

def test_refuel_is_not_a_normal_boost_from_operation():
    assert 'else {5}):' in client
    assert 'self.client.controls_available and state == 5' in buttons
    assert 'GLOBAL 0x59 seconds' in features
    assert 'await self.async_set_boost(True)' in client

def test_sensor_icon_unset_does_not_break_all_sensors():
    ast.parse(sensor)
    assert 'return getattr(self, "_attr_icon", None)' in sensor

def test_card_keeps_refueling_and_main_statuses():
    assert 'mdi:forest' in card
    assert 'mdi:turbine' in card
    assert "['chimney_temperature','fan_speed','fire_duration','inside_temperature','outside_temperature','pressure']" in card
    assert "Xzense-kort 0.5.27" in card
