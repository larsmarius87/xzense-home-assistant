# Xzense Alpha 0.5.27
Oppgrader ved å erstatte /config/custom_components/xzense_full_preview med katalogen i ZIP.
Kopier www/xzense-card.js til /config/www/xzense-card.js og bruk /local/xzense-card.js?v=0527.
Start Home Assistant på nytt. Test radiolink, viftetype, flervalgsvarsling og driftstatus 7.
0.5.25 RC1 er siste bekreftet fungerende test mot fysisk panel.
Eksisterende egendefinerte entitetsnavn i HA må eventuelt tilbakestilles manuelt.

### Korrigert 0.5.27
Gjenoppretter historiske ikoner, varslingstekst og registeropprydding.
Ta backup før oppdatering. Oppryddingen fjerner kun eksplisitt navngitte
foreldede entiteter i Xzense-integrasjonen. Egendefinerte entitetsnavn i
Home Assistant kan måtte tilbakestilles manuelt.
